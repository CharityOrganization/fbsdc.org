=== Benevolent Pro ===
Author: Rara Theme (https://rarathemes.com)
Requires at least: 4.7
Requires PHP: 5.6
Tested up to: 6.2
Stable tag: 1.4.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: Blog, two-columns, right-sidebar, footer-widgets, education, custom-background, custom-menu, featured-image-header, featured-images, post-formats, threaded-comments, translation-ready, full-width-template, theme-options


== Description ==

Benevolent Pro is an easy to use, clean modern and  flexible multipurpose theme.   Although the theme was designed with nonprofit organizations in mind , the theme is very versatile and can be used by any business websites, digital agency, consultancy, corporate business, freelancers, and bloggers. The theme is SEO friendly with optimized codes, which  make it easy for your site to rank on Google and other search engines. Benevolent Pro comes with several features to make user-friendly, interactive and visually stunning website. Such features include custom menu with Call to Action Button, advance full width slider,  community section, Stats counter,  Client Section, Banner with Call to Action Button  (CTA),  and social media. It has four footer area and a right sidebar and includes  four custom widgets for the recent posts, popular posts, social media and the featured post. The theme is rigorously tested and optimized for speed and faster page load time and has a secure and clean code. The theme is also translation ready. Designed with visitor engagement in mind, Benevolent Pro helps you to easily and intuitively create professional and appealing websites. You can get free support in https://rarathemes.com/support-forum/, Documentation: https://docs.rarathemes.com/docs/benevolent-pro/ and check the demo at https://rarathemes.com/previews/?theme=benevolent-pro.


== Installation ==
        
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyrights and License ==

Unless otherwise specified, all the theme files, scripts and images are licensed under GPLv2 or later


External resources linked to the theme.
* Raleway Font by through Google Font 
https://www.google.com/fonts/specimen/Raleway
*Font Awesome
https://fortawesome.github.io/Font-Awesome/

# Images
All images are under Creative Commons Public Domain deed CC0.

https://pixabay.com/en/boys-poor-person-children-happy-60680/

Other images are self taken or self created and are GPL compatible.

# JS
All the JS are licensed under GPLv2 or later
https://jqueryui.com/tabs/
http://flexslider.woothemes.com/
https://www.berriart.com/sidr/
https://github.com/bfintal/Counter-Up/blob/master/LICENSE
https://github.com/imakewebthings/waypoints/blob/master/licenses.txt

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)


* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)


All other resources and theme elements are licensed under the GPLv2 or later


Benevolent WordPress Theme, Copyright Rara Theme 2015, rarathemes.com
Benevolent WordPress Theme is distributed under the terms of the GPLv2 or later


*  This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   
== Changelog ==

    1.4.6 - May 05, 2023
    * Fix: Added alt tag to custom banner slider images.
    * New Feature: Added two new Elementor templates, namely Empower and Giving Heart.
    * Update: Google Fonts library updated

    1.4.5 - January 03, 2023
    * New Feature: Added two new Elementor Templates ready to import from Demo Importer Plus plugin.

    1.4.4 - December 01, 2022
    * New Feature: Added compatibility with Demo Importer Plus plugin.
    * New Feature: Added new Elementor Templates ready to import.
    * Fixes: TGMPA warning issue in PHP 8 is fixed. 
    * Fixes: Elementor deprecated warnings is fixed. 

    1.4.3 - June 08, 2022
    * Update: Fontawesome is updated to 6.1.1 to make compatible with latest icons.
    * Fix: Dynamic color issue in single donation page is fixed.

    1.4.2 - March 23, 2022
    * New Feature: Added Revive Charity child theme Style.
    * New Feature: Added settings to change background image of Intro section.
    * Fix : Typography issue.

    1.4.1 - July 22, 2021
    * Fixed jQuery deprecated warnings
    * Fixed hover issues
    * Fixed design issue of give section of homepage
    * Fixed stat counter issue in about page
    * Fixed theme updater issue for php 8
    * Recommended BlossomThemes Social Feed plugin
    * Updated google fonts
    * Removed widget block editor for WordPress 5.8
    * Removed equalheight js
    * Removed Kirki with custom control

    1.4.0 - January 06, 2021
    * Added snapchat 
    * Updated theme updater

    1.3.9 - October 01, 2020
    * Added theme migration feature

    1.3.8 - August 20, 2020
    * Fixed back to top button z-index issue
    * Conditionally loaded js and css
    * Added download id
    * Fixed wp-color-picker-alpha.js error for WordPress 5.5

    1.3.7 - June 24, 2020
    * Fixed breadcrumb issue
    * Fixed schema issue
    * Made donation currency dynamic
    * Changed demo link
    * Updated theme updater

    1.3.6 - April 22, 2020
    * Fixed menu accessibility issue
    * Fixed undefined index error
    * Fixed instagram widget issue
    * Fixed design issue of calendar widget in WordPresss 5.4
    * Added google font locally
    * Added viber in social allowed protocol
    * Added link field in icon text widget
    * Added feature to disable auto cropping of image
    * Added google analytics
    * Replaced content excerpt character by content excerpt words
    * Modified theme updater

    1.3.5 - February 17, 2020
    * Renamed plugin label in plugins panel.
    * Updated preg replace for telephone to add + sign.
    * Updated fancybox to 3.5.7.
    * Added archive description in archive page.
    * Added hide prefix option in archive page.
    * Added edit option of shop page description.
    * Added fallback svg.
    * Added comment fields as required.
    * Added jetpack compatibility for post gallery and lazy load.
    * Recommended customizer search plugin.

    1.3.4 - December 16, 2019
    * Updated Theme Club tab with ajax call and transient.
    * Removed posts from excluded category in single post navigation.

    1.3.3 - October 22, 2019
    * Breadcrumb updated for Google Schema.
    * Elementor Compatible.
    
    1.3.2 - Septembar 02, 2019
    * Added Gettting started page.
    * Added url support in video iframe.
    * Changed documentation links.    
    * Changed http to https in flickr plugin.
    * Fixed responsive design issue of banner for charity care.
    * Made Dynamic CSS pluggable. 
    
    1.3.1 - July 10, 2019
    * Changed raratheme.com to rarathemes.com.
    * Added wp_body_open action hook.

    1.3.0 - April 28, 2019
    * Made footer link no-follow

    1.2.9 - April 19, 2019
    * Added open Donate Button Link in new tab feature.
    * Charity Care Child theme design issue fixed in Pro Theme.
    * Blog Section matchheight issue fixed.

    1.2.8 - March 08, 2019
    * Added feature to open link on new tab in homepage intro section.
    * Added google map iframe option.
    * Typography issue for the Intro Section fixed.
    * Client Logo section issue of duplicating logos fixed.
    * Updated fancybox to version 3.5.6.

    1.2.7 - January 24, 2019
    * Fontawesome updated to 5.6.3
    * Responsive header layout improved.

    1.2.6 - January 16, 2019
    * Secondary color issue fix for header layout four.
    * Fixed icon text widget issue. 
    * Added fallback image in frontpage blog section.
    * Added scroll to section feature.

    1.2.5 - October 02, 2018
    * Font Awesome updated to 5.3.1.
    * Update Blog Section excerpt issue.
    * Donate section design issue fix.
    * Current menu color issue fix.
    * Dynamic color issue fix on menu.

    1.2.4
    * Add Charity Care child theme Style.

    1.2.3
    * Header Five issue fixed.
 
    1.2.2
    * Site Title issue fixed.
    * Demo URL link updated.

    1.2.1
    * CTA issue fixed.
    * remove enable/disable kirki google fonts option.
    
    1.2.0
    * Font awesome updated to 4.7.
    * Icon text widget issue fixed.
    * Post type order in team and testimonial.

    1.1.9
    * Removed demo files from theme and updated imported hooks.
    
    1.1.8
    * Privacy Policy link and WP Comment Cookies Consent features were added after 4.9.6 wp installation.
    
    1.1.7
    * Added performance features
    * Replaced lightslider with owl-carousel for slider
    * Added minified files for all js and css
    * Added schema for SEO
    * Added medium social-icon

    1.1.6
    * Google map issue fixed again.

    1.1.5
    * Customizer Safari Compatible.
    * Kirki framework issue fixed.
    * Instagram issue fixed.

    1.1.4
    * Li were removed from the slider.
    * Active callback updated.
    * Added new functionality for mobile devices to display the button as in free theme.
    * Minor issues fixed.

    1.1.3
    * Google map issue fixed.
    * Slider issue fixed.

    1.1.2
    * Removed kirki zip file.
    * Replaced light slider with owl carousel slider for some compatibility issue.
    * Added animate.css for some animation within owl carousel.
    * Background Color Issue fixed.
    * Instagram Widget Issue fixed.
    * Minor Issue fixed.
    * TGMPA woocommerce added.

    1.1.1
    * Homepage setting label changed to static front page for wp 4.9
    * Typography content size,color, line height issue fixed. 

    1.1.0
    * color customization issue on latest WordPress update to version 4.9 fixed.
    * Kirki framework updated.
    * Theme Updater issue fixed.
    * Footer current year and site title link shortcode added.

    1.0.9
    * Made theme RTL.
    
    1.0.8
    * Updated customizer file for demo import.
    
    1.0.7
    * Fix: Added page in slider selecting post/page option.
    
    1.0.6
    * Fixed the demo import using .org hosted "Rara One Click Demo Import" plugin.
    * Removed bundled "Rara One Click Demo Import" plugin.
    
    1.0.5
    * New: Added OK, VK and Xing social icons.
    * Fix: Added missing key for loadmore and loading pagination.
    * Added Information Links in customizer.
    
    1.0.4
    * New: Made theme WPML and Polylang compatible.
    * Updated "Rara One Click Demo Import" plugin.
    * Added snippet to migrate custom css to core custom css for WP ver > 4.7.
    * Fixed js error in infinite scroll.
    * Fixed unbalanced tags.
    * Fixed default value issue for contatiner option in facebook widget.
    * Fixed grey area in responsive header.
    
    1.0.3
    * New: Demo Import is implemented through "Rara One Click Demo Import".
    * Fixed random no. of post in default recent post widget.
    
    1.0.2
    * Added pages in dropdown menu of Community section of home page settings.
    * Added background color option for Community and Give section of home page settings.
    
    1.0.1
    * Fix + sign issue in google plus link.
    * Added Import Demo in Customizer.
            
    1.0.0
    * Initial Release
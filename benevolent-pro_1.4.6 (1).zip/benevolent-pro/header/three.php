<?php
/**
 * Header Three
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer
$ed_search_form = get_theme_mod( 'benevolent_pro_ed_search_form', '1' ); // From customizer
$ed_donate_btn  = get_theme_mod( 'benevolent_pro_ed_donate_button' );
$ed_donate_form = get_theme_mod( 'benevolent_pro_ed_donate_form' );
$donate_form    = get_theme_mod( 'benevolent_pro_donate_form' );
$button_text    = get_theme_mod( 'benevolent_pro_donate_button_label', __( 'Donate Now', 'benevolent-pro' ) );
$button_url     = get_theme_mod( 'benevolent_pro_donate_button_url' );

$donate_button = ''; //From customizer

?>

<header id="masthead" class="site-header header-three" role="banner" itemscope itemtype="https://schema.org/WPHeader">
	
    <?php benevolent_pro_site_branding(); ?>
	
    <div class="header-holder">
		
        <?php if( has_nav_menu( 'secondary' ) || $ed_donate_btn || $ed_social_link ){ ?>
            <div class="header-top">
    		    
                <?php 
                    benevolent_pro_navigation_menu_secondary();

                    if( $ed_donate_btn || $ed_social_link ){ ?>
                        <div class="right-panel">
            				
                            <?php if( is_give_activated() && $ed_donate_btn && ( $ed_donate_form && $donate_form && $button_text ) ){ ?>
                                <div class="btn-holder">
                					<a href="<?php echo esc_url( get_permalink( $donate_form ) ); ?>" class="btn-donate"><?php echo esc_html( $button_text ); ?></a>					
                				</div>
                            <?php }elseif( $ed_donate_btn && $button_text && $button_url ){ ?>
                                <div class="btn-holder">
                					<a href="<?php echo esc_url( $button_url ); ?>" class="btn-donate"><?php echo esc_html( $button_text ); ?></a>					
                				</div>
                            <?php } ?>
            		        
                            <?php if( $ed_social_link ) benevolent_pro_get_social_links(); ?>
                            
            			</div>
                    <?php } 
                ?>
                
    		</div><!-- .header-top -->
        <?php } ?>
		
        <div class="header-bottom">
			
            <?php 
                benevolent_pro_navigation_menu_primary(); 

                if( $ed_search_form ) benevolent_pro_header_search(); 
            ?>
            
		</div><!-- .header-bottom -->
        
	</div><!-- .header-holder -->    
    
</header>
<?php
/**
 * Header Two
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer

?>

<header id="masthead" class="site-header header-two" role="banner" itemscope itemtype="https://schema.org/WPHeader">

<?php 
    
    if( $ed_social_link || has_nav_menu( 'secondary' ) ){ ?>
    
        <div class="header-top">
            <div class="container">
                <?php 
                    benevolent_pro_navigation_menu_secondary(); 
                    
                    if( $ed_social_link ) benevolent_pro_get_social_links(); 
                ?>
            </div>
        </div><!-- .header-top -->
        
        <?php
    }
    
    ?>	
    
    <div class="header-bottom">
            
        <div class="container">
    	
            <?php 
                benevolent_pro_site_branding();
                benevolent_pro_navigation_menu_primary(); 
            ?>
        </div>
        
    </div><!-- .header-bottom -->
    
</header>
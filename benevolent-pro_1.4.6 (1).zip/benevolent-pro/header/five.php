<?php
/**
 * Header Five
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer
$ed_search_form = get_theme_mod( 'benevolent_pro_ed_search_form', '1' ); // From customizer

?>

<header id="masthead" class="site-header header-five" role="banner" itemscope itemtype="https://schema.org/WPHeader">
	
    <?php if( has_nav_menu( 'secondary' ) || $ed_social_link ) { ?>
    <div class="header-top">
		<div class="container">
			
            <?php 
                benevolent_pro_navigation_menu_secondary();

                if( $ed_social_link ) benevolent_pro_get_social_links(); 
            ?>
            
		</div>
	</div><!-- .header-top -->
    <?php } ?>
    
	<div class="container">
		<?php benevolent_pro_site_branding(); ?>
	</div>
    
	<div class="header-bottom">
		<div class="container">
			
            <?php 
                benevolent_pro_navigation_menu_primary(); 
                
                if( $ed_search_form ) benevolent_pro_header_search(); 
            ?>
            
		</div>
	</div><!-- .header-bottom -->
</header>
<?php
/**
 * Header Four
 * 
 * @package Benevolent_Pro
*/

$ed_social_link = get_theme_mod( 'benevolent_pro_ed_social_header' ); // From customizer
$ed_search_form = get_theme_mod( 'benevolent_pro_ed_search_form', '1' ); // From customizer

?>

<header id="masthead" class="site-header header-four" role="banner" itemscope itemtype="https://schema.org/WPHeader">
	
    <div class="header-top">
		<div class="container">
			
            <?php 
                benevolent_pro_site_branding(); 

                if( has_nav_menu( 'secondary' ) ){ ?>            
                <div id="secondary-mobile-header">
    			    <a id="responsive-secondary-menu-button" href="#sidr-main2"><?php esc_html_e( 'Menu', 'benevolent-pro' ); ?></a>
    			</div> 
            <?php } ?>
			
            <?php if( has_nav_menu( 'secondary' ) || $ed_social_link ){ ?>
                <div class="right-panel">
                
    				<?php 
                        benevolent_pro_navigation_menu_secondary();

                        if( $ed_social_link ) benevolent_pro_get_social_links(); 
                    ?>
                    
    			</div><!-- .right-panel -->
            <?php } ?>
            
		</div>
	</div><!-- .header-top -->
    
	<div class="header-bottom">
		<div class="container">
			
            <?php 
                benevolent_pro_navigation_menu_primary(); 
                
                if( $ed_search_form ) benevolent_pro_header_search(); 
            ?>
            			
		</div>
	</div><!-- .header-bottom -->
</header>
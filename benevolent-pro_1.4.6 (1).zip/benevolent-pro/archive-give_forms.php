<?php
/**
 *  Used to display an archive page of Give Donation forms.
 *
 * @package Benevolent_Pro
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main give-archive" role="main">
			
            <?php
    		if ( have_posts() ) : 
            
    			/* Start the Loop */
    			while ( have_posts() ) : the_post();
    				
    				get_template_part( 'template-parts/content', 'give' );
    
    			endwhile;
    
    			benevolent_pro_pagination(); //Pagination
    
    		else :
    
    			get_template_part( 'template-parts/content', 'none' );
    
    		endif; ?>
            
		</main>

	</div>

<?php 
get_sidebar();
get_footer();
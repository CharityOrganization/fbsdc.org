<?php
/**
 * Template Name: Contact Page
 *
 * @package Benevolent
 */

get_header(); ?>

    <div class="site-content" id="content">
        <div class="row">
        	
            <div id="primary" class="content-area">
        		<main id="main" class="site-main" role="main">
        
        			<?php
        			while ( have_posts() ) : the_post();
        
        				get_template_part( 'template-parts/content', 'page' );
        
        			endwhile; // End of the loop.
                    
        			?>
        
        		</main><!-- #main -->
        	</div><!-- #primary -->
            
            <?php get_sidebar(); ?>
            
            
        </div><!-- .row -->
        <?php 
            $ed_google_map = get_theme_mod( 'benevolent_pro_ed_google_map' );
            $map_option    = get_theme_mod( 'benevolent_pro_google_map_option', 'google_map_api' );
            $map_iframe    = get_theme_mod( 'benevolent_pro_map_iframe', '' );

            if( $ed_google_map && 'google_map_api' == $map_option ){
                echo '<div id="map" class="map-holder"></div> <!-- GOOGLE MAP HOLDER -->';
            }elseif( $ed_google_map && 'google_map_iframe' == $map_option ){ 
                echo '<div id="map" class="map-holder">';
                echo wp_specialchars_decode( $map_iframe );
                echo '</div><!-- GOOGLE MAP HOLDER -->';
            }
        ?>
    </div><!-- .site-content -->
    
<?php
get_footer();
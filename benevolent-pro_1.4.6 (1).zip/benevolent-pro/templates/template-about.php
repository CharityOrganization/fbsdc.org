<?php
/**
 * Template Name: About Page
 *
 * @package Benevolent
 */

get_header(); 
?>

<div class="inner-page">

    <?php
    while ( have_posts() ) : the_post();
    
        $sections = get_theme_mod( 'benevolent_pro_sort_aboutpage', array( 'intro', 'profile', 'stat', 'believe', 'current' ) );
                       
        foreach( $sections as $section ){
            get_template_part( 'sections/about/' . esc_attr( $section ) );    
        }    
    
    endwhile;
    ?>    

</div>

<?php     
get_footer();
<?php
/**
 * Template Name: Home Page
 *
 * @package Benevolent
 */
$ed_elementor = get_theme_mod( 'ed_elementor' );
get_header(); 

	if( benevolent_pro_is_elementor_activated_post() && $ed_elementor ){ 
        get_template_part( 'template-parts/content-elementor' );
    }else{
    	$sections = get_theme_mod( 'benevolent_pro_sort_homepage', array( 'intro', 'community', 'stat', 'give', 'blog', 'sponsor', 'cta' ) );
	    foreach( $sections as $section ){
	        if( $section == 'give' ){
	            if( is_give_activated() ) get_template_part( 'sections/home/' . esc_attr( $section ) );
	        }else{
	            get_template_part( 'sections/home/' . esc_attr( $section ) );    
	        }                
	    }
    }
    
get_footer();
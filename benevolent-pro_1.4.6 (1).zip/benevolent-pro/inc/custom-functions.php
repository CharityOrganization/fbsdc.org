<?php
/**
 * Benevolent Pro functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Benevolent_Pro 
 */

if( get_theme_mod( 'benevolent_pro_ed_adminbar' ) ) add_filter( 'show_admin_bar', '__return_false' );

if ( ! function_exists( 'benevolent_pro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function benevolent_pro_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Benevolent Pro, use a find and replace
	 * to change 'benevolent-pro' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'benevolent-pro', get_template_directory() . '/languages' );
    
    // Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary'   => esc_html__( 'Primary', 'benevolent-pro' ),
        'secondary' => esc_html__( 'Secondary', 'benevolent-pro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See https://developer.wordpress.org/themes/functionality/post-formats/
	 */
	add_theme_support( 'post-formats', array(
		'aside',        
		'image',
		'video',
		'quote',
		'link',
        'gallery',
        'status',
        'audio', 
        'chat'
	) );
    
    // Custom Image Size
    add_image_size( 'benevolent-pro-slider', 1920, 967, true );
    add_image_size( 'benevolent-pro-community', 960, 450, true );
    add_image_size( 'benevolent-pro-blog', 350, 196, true );
    add_image_size( 'benevolent-pro-with-sidebar', 780, 437, true );
    add_image_size( 'benevolent-pro-without-sidebar', 1180, 437, true );
    add_image_size( 'benevolent-pro-featured-post', 275, 275, true );
    add_image_size( 'benevolent-pro-recent-post', 75, 75, true );
    add_image_size( 'benevolent-pro-testimonial', 228, 337, true );
    add_image_size( 'benevolent-pro-team', 350, 235, true );
    add_image_size( 'benevolent-pro-give', 768, 400, true );
    add_image_size( 'benevolent-pro-schema', 600, 60, true );
    
    /* Custom Logo */
    add_theme_support( 'custom-logo', array(
    	'header-text' => array( 'site-title', 'site-description' ),
    ) );
    
    /** remove widget block editor */
    remove_theme_support( 'widgets-block-editor' );
}
endif;
add_action( 'after_setup_theme', 'benevolent_pro_setup' );

if( ! function_exists( 'benevolent_pro_content_width' ) ) :
/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function benevolent_pro_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'benevolent_pro_content_width', 780 );
}
endif;
add_action( 'after_setup_theme', 'benevolent_pro_content_width', 0 );

if( ! function_exists( 'benevolent_pro_scripts' ) ) :
/**
 * Enqueue scripts and styles.
 */
function benevolent_pro_scripts() {
	
    $map_api      = get_theme_mod( 'benevolent_pro_map_api' );
    $key          = $map_api ? '?key='.esc_attr( $map_api ) : '' ;
    $build        = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '/build' : '';
    $suffix       = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
    $ed_elementor = get_theme_mod( 'ed_elementor' );
    $ed_googlefont_local = get_theme_mod( 'ed_googlefont_local' );

    if( ! $ed_googlefont_local )
    wp_enqueue_style( 'benevolent-pro-google-fonts', benevolent_pro_fonts_url(), array(), null );
    
    wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/css' . $build . '/owl.carousel' . $suffix . '.css', '', '2.2.1' );
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/css' . $build . '/animate' . $suffix . '.css', array(), '3.5.2' );

    wp_enqueue_style( 'benevolent-pro-style', get_stylesheet_uri(), array(), BENEVOLENT_PRO_THEME_VERSION );
    
    if( benevolent_pro_is_elementor_activated() && $ed_elementor ){
        wp_enqueue_style( 'benevolent-pro-elementor', get_template_directory_uri(). '/css/' . $build . '/elementor' . $suffix . '.css', array(), BENEVOLENT_PRO_THEME_VERSION );
    }
    // woocommerce css	
    if( benevolent_pro_is_woocommerce_activated() )
    wp_enqueue_style( 'benevolent-pro-woocommerce-style', get_template_directory_uri(). '/css' . $build . '/woocommerce' . $suffix . '.css', BENEVOLENT_PRO_THEME_VERSION );
    
    // FontAwesome
    wp_enqueue_script( 'all', get_template_directory_uri() . '/js' . $build . '/all' . $suffix . '.js', array('jquery'), '6.1.1', true );
    wp_enqueue_script( 'v4-shims', get_template_directory_uri() . '/js' . $build . '/v4-shims' . $suffix . '.js', array('jquery'), '6.1.1', true );

    //Fancy Box
    if( get_theme_mod( 'benevolent_pro_ed_lightbox') ){
        wp_enqueue_style( 'jquery-fancybox', get_template_directory_uri() . '/css' . $build . '/jquery.fancybox' . $suffix . '.css', '', '3.5.7' );
        wp_enqueue_script( 'jquery-fancybox', get_template_directory_uri() . '/js' . $build . '/jquery.fancybox' . $suffix . '.js', array('jquery'), '3.5.7', true );
    }
    
    if( is_page_template( 'templates/template-contact.php' ) )
    wp_enqueue_script( 'benevolent-pro-googlemap', '//maps.googleapis.com/maps/api/js'.$key, array('jquery'), '3.0', false );
    
    if( is_page_template( array( 'templates/template-team.php', 'templates/template-about.php', 'templates/template-service.php' ) ) )
    wp_enqueue_script( 'masonry' );
    
    if( is_active_widget( false, false, 'benevolent_pro_flickr_widget' ) )
    wp_enqueue_script( 'jflickrfeed', get_template_directory_uri() . '/js' . $build . '/jflickrfeed' . $suffix . '.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    
    if( get_theme_mod( 'ed_lazy_load', false ) || get_theme_mod( 'ed_lazy_load_cimage', false ) ) {
        wp_enqueue_script( 'layzr', get_template_directory_uri() . '/js' . $build . '/layzr' . $suffix . '.js', array('jquery'), '2.0.4', true );
    }
    
    wp_enqueue_script( 'waypoint', get_template_directory_uri() . '/js' . $build . '/waypoint' . $suffix . '.js', array('jquery'), '2.0.3', true );
    wp_enqueue_script( 'jquery.fitvids', get_template_directory_uri() . '/js' . $build . '/jquery.fitvids' . $suffix . '.js', array('jquery'), '1.1', true );

    if ( is_front_page() || is_page_template( 'templates/template-about.php' ) ){
        wp_enqueue_script( 'jquery.counterup', get_template_directory_uri() . '/js' . $build . '/jquery.counterup' . $suffix . '.js', array('jquery', 'waypoint'), '1.0', true );
    }

    wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js' . $build . '/owl.carousel' . $suffix . '.js', array('jquery'), '2.2.1', true );

    wp_register_script( 'benevolent-pro-custom', get_template_directory_uri() . '/js' . $build . '/custom' . $suffix . '.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    wp_register_script( 'benevolent-pro-ajax', get_template_directory_uri() . '/js' . $build . '/ajax' . $suffix . '.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true );
    
    $slider_auto      = get_theme_mod( 'benevolent_pro_slider_auto', '1' );
    $slider_loop      = get_theme_mod( 'benevolent_pro_slider_loop', '1' );
    $sponsor_loop     = get_theme_mod( 'benevolent_pro_ed_sponsor_loop', '1' );
    $slider_pager     = get_theme_mod( 'benevolent_pro_slider_pager', '1' );    
    $slider_animation = get_theme_mod( 'benevolent_pro_slider_animation', 'slide' );
    $slider_speed     = get_theme_mod( 'benevolent_pro_slider_speed', '400' );
    $slider_pause     = get_theme_mod( 'benevolent_pro_slider_pause', '6000' );
    $sticky_header    = get_theme_mod( 'benevolent_pro_ed_sticky_header' );
    $header_style     = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
    
    $array = array(
        'auto'               => esc_attr( $slider_auto ),
        'loop'               => esc_attr( $slider_loop ),
        'sponsor_loop'       => esc_attr( $sponsor_loop ),
        'pager'              => esc_attr( $slider_pager ),
        'animation'          => esc_attr( $slider_animation ),
        'speed'              => absint( $slider_speed ),
        'pause'              => absint( $slider_pause ),  
        'lightbox'           => esc_attr( get_theme_mod( 'benevolent_pro_ed_lightbox') ),      
        'rtl'                => is_rtl(),
        'sticky'             => $sticky_header,
        'header'             => $header_style,
        'charity_care_style' => esc_attr( get_theme_mod('benevolent_pro_ed_child_style',false) ),
    );
    
    wp_localize_script( 'benevolent-pro-custom', 'benevolent_pro_data', $array );
    wp_enqueue_script( 'benevolent-pro-custom' );
    
    $pagination = get_theme_mod( 'benevolent_pro_pagination_type', 'default' );
    $loadmore   = get_theme_mod( 'benevolent_pro_load_more_label', __( 'Load More Posts', 'benevolent-pro' ) );
    $loading    = get_theme_mod( 'benevolent_pro_loading_label', __( 'Loading...', 'benevolent-pro' ) );
    
    if( get_theme_mod( 'benevolent_pro_ed_ajax_search' ) || $pagination == 'load_more' || $pagination == 'infinite_scroll' ){
        
        // Add parameters for the JS
        global $wp_query;
        $max = $wp_query->max_num_pages;
        $paged = ( get_query_var( 'paged' ) > 1 ) ? get_query_var( 'paged' ) : 1;
        
        wp_enqueue_script( 'benevolent-pro-ajax' );
        
        wp_localize_script( 
            'benevolent-pro-ajax', 
            'benevolent_pro_ajax',
            array(
                'url'           => admin_url( 'admin-ajax.php' ),
                'startPage'     => $paged,
                'maxPages'      => $max,
                'nextLink'      => next_posts( $max, false ),
                'autoLoad'      => $pagination,
                'loadmore'      => $loadmore,
                'loading'       => $loading,
                'nomore'        => __( 'No more posts.', 'benevolent-pro' ),
                'plugin_url'    => plugins_url()
             )
        );
        
        if ( is_jetpack_activated( true ) ) {
            wp_enqueue_style( 'tiled-gallery', plugins_url() . '/jetpack/modules/tiled-gallery/tiled-gallery/tiled-gallery.css' );            
        }
    }
    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
endif;
add_action( 'wp_enqueue_scripts', 'benevolent_pro_scripts' );

if( ! function_exists( 'benevolent_pro_admin_scripts' ) ) :
/**
 * Enqueue admin scripts and styles.
 */
function benevolent_pro_admin_scripts(){
    
    if( function_exists( 'wp_enqueue_media' ) )
    wp_enqueue_media();
    
    wp_enqueue_style( 'wp-color-picker' );  
    // FontAwesome
    wp_enqueue_script( 'all', get_template_directory_uri() . '/js/all.min.js', array('jquery'), '6.1.1', true );
    wp_enqueue_script( 'v4-shims', get_template_directory_uri() . '/js/v4-shims.min.js', array('jquery'), '6.1.1', true );

    wp_enqueue_style( 'benevolent-pro-admin-style', get_template_directory_uri() . '/inc/css/admin.css', array(), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_register_script( 'benevolent-pro-media-uploader', get_template_directory_uri() . '/inc/js/media-uploader.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION );
    wp_register_script( 'benevolent-pro-admin-js', get_template_directory_uri() . '/inc/js/admin.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_localize_script( 'benevolent-pro-media-uploader', 'benevolent_pro_uploader', array(
        'upload' => __( 'Upload', 'benevolent-pro' ),
        'change' => __( 'Change', 'benevolent-pro' ),
        'msg'    => __( 'Please upload valid image file.', 'benevolent-pro' )
    ));
    
    wp_localize_script( 'benevolent-pro-admin-js', 'benevolent_pro_admin', array(
        'import_true' => __( 'Are you sure to import dummy content?', 'benevolent-pro' ),
        'demo_msg'    => __( 'The Demo Contents are Loading. It might take a while. Please keep patience.', 'benevolent-pro' ),
        'success_msg' => __( 'Demo Contents Successfully Imported.', 'benevolent-pro' ),
    ));
    
    wp_enqueue_script( 'benevolent-pro-media-uploader' );
    
    //For Color Picker
    wp_enqueue_script('benevolent-pro-color-picker', get_template_directory_uri() . '/inc/js/color-picker.js', array( 'wp-color-picker' ), BENEVOLENT_PRO_THEME_VERSION );
    
    wp_enqueue_script( 'benevolent-pro-admin-js' );
    
}
endif;
add_action( 'admin_enqueue_scripts', 'benevolent_pro_admin_scripts' );
add_action( 'elementor/editor/before_enqueue_scripts', 'benevolent_pro_admin_scripts' );

if( ! function_exists( 'benevolent_pro_customizer_js' ) ) :
/** 
 * Registering and enqueuing scripts/stylesheets for Customizer controls.
 */ 
function benevolent_pro_customizer_js() {
    wp_enqueue_style( 'benevolent-pro-customizer-css', get_template_directory_uri() . '/inc/css/customizer.css', array(), BENEVOLENT_PRO_THEME_VERSION );
	wp_enqueue_script( 'benevolent-pro-customizer-js', get_template_directory_uri() . '/inc/js/customizer.js', array('jquery'), BENEVOLENT_PRO_THEME_VERSION, true  );

    $array = array(
        'home'     => get_home_url(),
        'about'    => benevolent_pro_get_page_template_url( 'templates/template-about.php' ),
        'service'  => benevolent_pro_get_page_template_url( 'templates/template-service.php' ),
        'blog'     => benevolent_pro_get_blog_page_url(),
    );

    wp_localize_script( 'benevolent-pro-customizer-js', 'bp_cdata', $array );
}
endif;
add_action( 'customize_controls_enqueue_scripts', 'benevolent_pro_customizer_js' );

if( ! function_exists( 'benevolent_pro_body_classes' ) ) :
/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function benevolent_pro_body_classes( $classes ) {
	
    $blog_layout = get_theme_mod( 'benevolent_pro_blog_layout', 'default' ); //From Customizer
    $bg_color    = get_theme_mod( 'benevolent_pro_bg_color', '#ffffff' );
    $bg_image    = get_theme_mod( 'benevolent_pro_bg_image' );
    $bg_pattern  = get_theme_mod( 'benevolent_pro_bg_pattern', 'nobg' );
    $bg          = get_theme_mod( 'benevolent_pro_body_bg', 'image' );
    
    // Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}
    
    // Adds a class for custom background Color
    if( $bg_color != '#ffffff' ){
        $classes[] = 'custom-background-color';
    }
    
    // Adds a class for custom background Color
    if( ( $bg == 'image' && $bg_image ) || (  $bg == 'pattern' && $bg_pattern != 'nobg' ) ){
        $classes[] = 'custom-background-image';
    }
    
    if( get_theme_mod( 'benevolent_pro_ed_slider' ) ){
        $classes[] = 'has-slider';
	}
    
    if( $blog_layout === 'round' ){
        $classes[] = 'blog-round';
    }
    
    if( $blog_layout === 'square' ){
        $classes[] = 'blog-medium';
    }
    
    if( get_theme_mod('benevolent_pro_ed_child_style') == "charity-care" ){ 
        $classes[] = 'chariti-care-style';
    }elseif( get_theme_mod('benevolent_pro_ed_child_style') == "revive-charity" ){ 
        $classes[] = 'revive-charity-style';
    }

    if( benevolent_pro_is_woocommerce_activated() && ( is_shop() || is_product_category() || is_product_tag() || 'product' === get_post_type() ) && ! is_active_sidebar( 'shop-sidebar' ) ){
        $classes[] = 'full-width';
    }
    
    $classes[] = benevolent_pro_sidebar( false, true );
    
	return $classes;
}
endif;
add_filter( 'body_class', 'benevolent_pro_body_classes' );

if( ! function_exists( 'benevolent_pro_post_classes' ) ) :
/**
 * Adds custom classes to the array of post classes.
 *
 * @param array $classes Classes for the post element.
 * @return array
 */
function benevolent_pro_post_classes( $classes ) {
    
    $classes[] = 'latest_post';
    
    if( is_post_type_archive( 'give_forms' ) || ( is_give_activated() && ( is_give_taxonomy() || is_singular( 'give_forms' ) ) ) ){
        $classes[] = 'post';
    }
    
    return $classes;
}
endif;
add_filter( 'post_class', 'benevolent_pro_post_classes' );

/**
 * Flush out the transients used in benevolent_pro_categorized_blog.
 */
function benevolent_pro_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'benevolent_pro_categories' );
}
add_action( 'edit_category', 'benevolent_pro_category_transient_flusher' );
add_action( 'save_post',     'benevolent_pro_category_transient_flusher' );

if( ! function_exists( 'benevolent_pro_custom_js' ) ) :
/**
 * Custom JS
*/
function benevolent_pro_custom_js(){
    $custom_script = get_theme_mod( 'benevolent_pro_custom_script' );
    if( $custom_script ){
        echo '<script type="text/javascript">';
		echo wp_strip_all_tags( $custom_script );
		echo '</script>';
    }
}
endif;
add_action( 'wp_footer', 'benevolent_pro_custom_js' );

if( ! function_exists( 'benevolent_pro_excerpt_more' ) ) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... * 
 */
function benevolent_pro_excerpt_more( $more ) {
	return is_admin() ? $more : ' &hellip; ';
}
endif;
add_filter( 'excerpt_more', 'benevolent_pro_excerpt_more' );

if( ! function_exists( 'benevolent_pro_excerpt_length' ) ) :
/**
 * Changes the default 55 character in excerpt 
*/
function benevolent_pro_excerpt_length( $length ) {
	return is_admin() ? $length : 60;
}
endif;
add_filter( 'excerpt_length', 'benevolent_pro_excerpt_length', 999 );

if( ! function_exists( 'benevolent_pro_logo_metabox' ) ) :
/**
 * Function that removes the default thumbnail and add custom thumbnail meta box 
 */
function benevolent_pro_logo_metabox(){
   remove_meta_box( 'postimagediv', 'logo', 'side' );
   add_meta_box( 'postimagediv', __( 'Featured Image', 'benevolent-pro' ), 'post_thumbnail_meta_box', 'logo', 'normal', 'high' );
}
endif;
add_action( 'do_meta_boxes', 'benevolent_pro_logo_metabox' );

if( ! function_exists( 'benevolent_pro_excerpts_in_pages' ) ) :
/**
 * Function to add excerpt field in pages
*/
function benevolent_pro_excerpts_in_pages() {
     add_post_type_support( 'page', 'excerpt' );
}
endif;
add_action( 'init', 'benevolent_pro_excerpts_in_pages' );

if( ! function_exists( 'benevolent_pro_google_map' ) ) :
/**
 * Callback Function for Google Map 
*/
function benevolent_pro_google_map(){

    $ed_google_map   = get_theme_mod( 'benevolent_pro_ed_google_map' );
    $map_option      = get_theme_mod( 'benevolent_pro_google_map_option', 'google_map_api' );

    if( is_page_template( 'templates/template-contact.php' ) && $ed_google_map && 'google_map_api' == $map_option ){
        
        $lattitude       = get_theme_mod( 'benevolent_pro_lattitude', '27.7304135' );
        $longitude       = get_theme_mod( 'benevolent_pro_longitude', '85.3304937' );
        $map_height      = get_theme_mod( 'benevolent_pro_map_height', '320' );
        $map_zoom        = get_theme_mod( 'benevolent_pro_map_zoom', '17' );
        $map_type        = get_theme_mod( 'benevolent_pro_map_type', 'ROADMAP' );
        $map_scroll      = ( get_theme_mod( 'benevolent_pro_ed_map_scroll', '1' ) == 1 ) ? 'true' : 'false';
        $map_control     = ( get_theme_mod( 'benevolent_pro_ed_map_controls', '1' ) != 1 ) ? 'true' : 'false';
        $map_control_inv = ( get_theme_mod( 'benevolent_pro_ed_map_controls', '1' ) == 1 ) ? 'true' : 'false';
        $ed_map_marker   = get_theme_mod( 'benevolent_pro_ed_map_marker' );
        $marker_title    = get_theme_mod( 'benevolent_pro_marker_title' );
        ?>
        <style>
          #map {
            width: 100%;
            height: <?php echo $map_height; ?>px;
          }
        </style>
        <script type="text/javascript">
        
            var map;
            var myLatLng = {lat: <?php echo $lattitude;?>, lng: <?php echo $longitude;?>};
            
            function initialize() {
                var mapOptions = {
                    zoom: <?php echo $map_zoom; ?>,
                    center: new google.maps.LatLng(<?php echo $lattitude;?>, <?php echo $longitude;?> ),
                    mapTypeId: google.maps.MapTypeId.<?php echo $map_type; ?>,
                    scrollwheel: <?php echo $map_scroll ?>,
                    zoomControl: <?php echo $map_control_inv ?>,
                    zoomControlOptions: {
                        style: google.maps.ZoomControlStyle.SMALL
                    },
                    mapTypeControl: <?php echo $map_control_inv ?>,
                    mapTypeControlOptions: {
                        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
                    },
                    disableDefaultUI: <?php echo $map_control ?>,
                };
                map = new google.maps.Map(document.getElementById('map'), mapOptions);
                
                <?php if( $ed_map_marker ){ ?>
                var marker = new google.maps.Marker({
                  position: myLatLng,
                  map: map,
                  <?php if( $marker_title ) echo 'title: "' . esc_html( $marker_title ) . '"' ?>
                });
                <?php } ?>
                
            }
            google.maps.event.addDomListener(window, 'load', initialize); 
          
        </script>
    <?php
    }    
}
endif;
add_action( 'wp_head', 'benevolent_pro_google_map' );

if( ! function_exists( 'benevolent_pro_donate_button_link' ) ) :
/**
* Filter wp_nav_menu() to add profile link
* 
* @link http://www.wpbeginner.com/wp-themes/how-to-add-custom-items-to-specific-wordpress-menus/
*/
function benevolent_pro_donate_button_link( $menu, $args ) {
    
    $button              = '';
    $ed_donate_btn       = get_theme_mod( 'benevolent_pro_ed_donate_button' );
    $ed_donate_form      = get_theme_mod( 'benevolent_pro_ed_donate_form' );
    $donate_form         = get_theme_mod( 'benevolent_pro_donate_form' );
    $button_text         = get_theme_mod( 'benevolent_pro_donate_button_label', __( 'Donate Now', 'benevolent-pro' ) );
    $button_url          = get_theme_mod( 'benevolent_pro_donate_button_url' );
    $header_layout       = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
    $button_menu_outside = get_theme_mod( 'benevolent_pro_ed_donate_btn_outside_menu' );
    $new_tab = get_theme_mod( 'benevolent_pro_ed_donate_in_new_tab' );
    $target = $new_tab ? 'target="_blank"' : 'target="_self"';

    if( ( ! wp_is_mobile() || ! $button_menu_outside ) && $ed_donate_btn && $args->theme_location == 'primary' && $header_layout !== 'three' ){
        if( is_give_activated() && ( $ed_donate_form && $donate_form && $button_text ) ){
            $button = '<li><a href="' . esc_url( get_permalink( $donate_form ) ). '" class="btn-donate" '. $target .'>' . esc_html( $button_text ) . '</a></li>';
        }elseif( $button_text && $button_url ){ 
            $button = '<li><a href="' . esc_url( $button_url ). '" class="btn-donate" '. $target .'>' . esc_html( $button_text ) . '</a></li>';
        }
        
        $menu = $menu . $button;               
    }
       
    return $menu; 
}
endif;
add_filter( 'wp_nav_menu_items', 'benevolent_pro_donate_button_link', 10, 2 );

if( ! function_exists( 'benevolent_pro_ajax_search' ) ) :
/**
 * AJAX Search results
 */ 
function benevolent_pro_ajax_search() {
    $query = $_REQUEST['q']; // It goes through esc_sql() in WP_Query
    $search_query = new WP_Query( array( 's' => $query, 'posts_per_page' => 3, 'post_status' => 'publish' )); 
    $search_count = new WP_Query( array( 's' => $query, 'posts_per_page' => -1, 'post_status' => 'publish' ));
    $search_count = $search_count->post_count;
    if ( !empty( $query ) && $search_query->have_posts() ) : 
        
        echo '<ul class="ajax-search-results">';
        while ( $search_query->have_posts() ) : $search_query->the_post(); ?>
        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>   
        <?php
        endwhile;
        echo '</ul>';
        
        echo '<div class="ajax-search-meta"><span class="results-count">'.$search_count.' '.__( 'Results', 'benevolent-pro' ).'</span><a href="'.get_search_link( $query ).'" class="results-link">'.__( 'Show all results.', 'benevolent-pro' ).'</a></div>';
    else:
        echo '<div class="no-results">'.__( 'No results found.', 'benevolent-pro' ).'</div>';
    endif;
    
    wp_die(); // this is required to terminate immediately and return a proper response
}
endif;
if( get_theme_mod( 'benevolent_pro_ed_ajax_search' ) ) {
    add_action( 'wp_ajax_benevolent_pro_search', 'benevolent_pro_ajax_search' );
    add_action( 'wp_ajax_nopriv_benevolent_pro_search', 'benevolent_pro_ajax_search' );
}

if( ! function_exists( 'benevolent_pro_exclude_cat' ) ) :
/**
 * Exclude post with Category from blog and archive page. 
*/
function benevolent_pro_exclude_cat( $query ){
    $cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
    
    if( $cat && ! is_admin() && $query->is_main_query() ){
        $cat = array_diff( array_unique( $cat ), array('') );
        if( $query->is_home() || $query->is_archive() ) {
			$query->set( 'category__not_in', $cat );
		}
    }    
}
endif;
add_filter( 'pre_get_posts', 'benevolent_pro_exclude_cat' );

if( ! function_exists( 'benevolent_pro_custom_category_widget' ) ) :
/** 
 * Exclude Categories from Category Widget 
*/ 
function benevolent_pro_custom_category_widget( $arg ) {
	$cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
    
    if( $cat ){
        $cat = array_diff( array_unique( $cat ), array('') );
        $arg["exclude"] = $cat;
    }
	return $arg;
}
endif;
add_filter( "widget_categories_args", "benevolent_pro_custom_category_widget" );
add_filter( "widget_categories_dropdown_args", "benevolent_pro_custom_category_widget" );

if( ! function_exists( 'benevolent_pro_exclude_posts_from_recentPostWidget_by_cat' ) ) :
/**
 * Exclude post from recent post widget of excluded catergory
 * 
 * @link http://blog.grokdd.com/exclude-recent-posts-by-category/
*/
function benevolent_pro_exclude_posts_from_recentPostWidget_by_cat( $arg ){
    
    $cat = get_theme_mod( 'benevolent_pro_exclude_categories' );
   
    if( $cat ){
        $cat = array_diff( array_unique( $cat ), array('') );
        $arg["category__not_in"] = $cat;
    }
    
    return $arg;   
}
endif;
add_filter( "widget_posts_args", "benevolent_pro_exclude_posts_from_recentPostWidget_by_cat" );

if( ! function_exists( 'benevolent_pro_allowed_social_protocols' ) ) :
/**
 * List of allowed social protocols in HTML attributes.
 * @param  array $protocols Array of allowed protocols.
 * @return array
 */
function benevolent_pro_allowed_social_protocols( $protocols ) {
    $social_protocols = array(
        'skype',
        'viber'
    );
    return array_merge( $protocols, $social_protocols );    
}
endif;
add_filter( 'kses_allowed_protocols' , 'benevolent_pro_allowed_social_protocols' );

/**
 * Load theme updater functions.
 * Action is used so that child themes can easily disable.
 */
function benevolent_pro_theme_updater() {
    require( get_template_directory() . '/updater/theme-updater.php' );
}
add_action( 'after_setup_theme', 'benevolent_pro_theme_updater' );

if( ! function_exists( 'benevolent_pro_single_post_schema' ) ) :
/**
 * Single Post Schema
 *
 * @return string
 */
function benevolent_pro_single_post_schema() {
    if ( is_singular( 'post' ) ) {
        global $post;
        $custom_logo_id = get_theme_mod( 'custom_logo' );

        $site_logo   = wp_get_attachment_image_src( $custom_logo_id , 'benevolent-pro-schema' );
        $images      = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
        $excerpt     = benevolent_pro_escape_text_tags( $post->post_excerpt );
        $content     = $excerpt === "" ? mb_substr( benevolent_pro_escape_text_tags( $post->post_content ), 0, 110 ) : $excerpt;
        $schema_type = ! empty( $custom_logo_id ) && has_post_thumbnail( $post->ID ) ? "BlogPosting" : "Blog";

        $args = array(
            "@context"  => "https://schema.org",
            "@type"     => $schema_type,
            "mainEntityOfPage" => array(
                "@type" => "WebPage",
                "@id"   => get_permalink( $post->ID )
            ),
            "headline"  => get_the_title( $post->ID ),
            "datePublished" => get_the_time( DATE_ISO8601, $post->ID ),
            "dateModified"  => get_post_modified_time(  DATE_ISO8601, __return_false(), $post->ID ),
            "author"        => array(
                "@type"     => "Person",
                "name"      => benevolent_pro_escape_text_tags( get_the_author_meta( 'display_name', $post->post_author ) )
            ),
            "description" => ( class_exists('WPSEO_Meta') ? WPSEO_Meta::get_value( 'metadesc' ) : $content )
        );

        if ( has_post_thumbnail( $post->ID ) ) :
            $args['image'] = array(
                "@type"  => "ImageObject",
                "url"    => $images[0],
                "width"  => $images[1],
                "height" => $images[2]
            );
        endif;

        if ( ! empty( $custom_logo_id ) ) :
            $args['publisher'] = array(
                "@type"       => "Organization",
                "name"        => get_bloginfo( 'name' ),
                "description" => get_bloginfo( 'description' ),
                "logo"        => array(
                    "@type"   => "ImageObject",
                    "url"     => $site_logo[0],
                    "width"   => $site_logo[1],
                    "height"  => $site_logo[2]
                )
            );
        endif;

        echo '<script type="application/ld+json">' , PHP_EOL;
        if ( version_compare( PHP_VERSION, '5.4.0' , '>=' ) ) {
            echo wp_json_encode( $args, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) , PHP_EOL;
        } else {
            echo wp_json_encode( $args ) , PHP_EOL;
        }
        echo '</script>' , PHP_EOL;
    }
}
endif;
add_action( 'wp_head', 'benevolent_pro_single_post_schema' );

if( ! function_exists( 'benevolent_pro_page_attribute_post' ) ):
    /**
     * Add Page attribute in post for post ordering
    */
    function benevolent_pro_page_attribute_post(){
        add_post_type_support( 'team', 'page-attributes' );
        add_post_type_support( 'testimonial', 'page-attributes' );
    }
endif;
add_action( 'init', 'benevolent_pro_page_attribute_post' );

if( ! function_exists( 'benevolent_pro_columns_head' ) ) :
    /**
     * Adds a Order column header in the item list admin page.
     *
     * @param array $defaults
     * @return array
     */
    function benevolent_pro_columns_head( $defaults ){
           
        if( get_post_type() === 'team' ){
            $defaults['team_order'] = __( 'Order', 'benevolent-pro' );
        }
        if( get_post_type() === 'testimonial' ){
            $defaults['testimonial_order'] = __( 'Order', 'benevolent-pro' );
        }
        
        return $defaults;
    }
endif;
add_filter( 'manage_posts_columns', 'benevolent_pro_columns_head' );

if( ! function_exists( 'benevolent_pro_columns_content' ) ) :
    /**
     * @param string $column_name The name of the column to display.
     * @param int $post_ID The ID of the current post.
     */
    function benevolent_pro_columns_content( $column_name, $post_ID ){
        global $post;

        if( $column_name == 'team_order' ){
            echo $post->menu_order;
        } 
        if( $column_name == 'testimonial_order' ){
            echo $post->menu_order;
        }
    }
endif;
add_action( 'manage_posts_custom_column', 'benevolent_pro_columns_content', 10, 2 );

if( ! function_exists( 'benevolent_pro_team_order_column_sortable' ) ) :
    /**
    * make column sortable
    */
    function benevolent_pro_team_order_column_sortable( $columns ){
        $columns['team_order'] = 'menu_order';
        return $columns;
    }
endif;
add_filter( 'manage_edit-team_sortable_columns', 'benevolent_pro_team_order_column_sortable' );

if( ! function_exists( 'benevolent_pro_testimonial_order_column_sortable' ) ) :
    /**
    * make column sortable
    */
    function benevolent_pro_testimonial_order_column_sortable( $columns ){
        $columns['testimonial_order'] = 'menu_order';
        return $columns;
    }
endif;
add_filter( 'manage_edit-testimonial_sortable_columns', 'benevolent_pro_testimonial_order_column_sortable' );

if( ! function_exists( 'benevolent_pro_filter_post_gallery' ) ) :
    /**
     * Filter the output of the gallery. 
    */ 
    function benevolent_pro_filter_post_gallery( $output, $attr, $instance ){
        global $post, $wp_locale;

        $html5 = current_theme_supports( 'html5', 'gallery' );
        $atts = shortcode_atts( array(
            'order'      => 'ASC',
            'orderby'    => 'menu_order ID',
            'id'         => $post ? $post->ID : 0,
            'itemtag'    => $html5 ? 'figure'     : 'dl',
            'icontag'    => $html5 ? 'div'        : 'dt',
            'captiontag' => $html5 ? 'figcaption' : 'dd',
            'columns'    => 3,
            'size'       => 'thumbnail',
            'include'    => '',
            'exclude'    => '',
            'link'       => ''
        ), $attr, 'gallery' );
        
        $id = intval( $atts['id'] );
        
        if ( ! empty( $atts['include'] ) ) {
            $_attachments = get_posts( array( 'include' => $atts['include'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
        
            $attachments = array();
            foreach ( $_attachments as $key => $val ) {
                $attachments[$val->ID] = $_attachments[$key];
            }
        } elseif ( ! empty( $atts['exclude'] ) ) {
            $attachments = get_children( array( 'post_parent' => $id, 'exclude' => $atts['exclude'], 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
        } else {
            $attachments = get_children( array( 'post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $atts['order'], 'orderby' => $atts['orderby'] ) );
        }
        
        if ( empty( $attachments ) ) {
            return '';
        }
        
        if ( is_feed() ) {
            $output = "\n";
            foreach ( $attachments as $att_id => $attachment ) {
                $output .= wp_get_attachment_link( $att_id, $atts['size'], true ) . "\n";
            }
            return $output;
        }
        
        $itemtag = tag_escape( $atts['itemtag'] );
        $captiontag = tag_escape( $atts['captiontag'] );
        $icontag = tag_escape( $atts['icontag'] );
        $valid_tags = wp_kses_allowed_html( 'post' );
        if ( ! isset( $valid_tags[ $itemtag ] ) ) {
            $itemtag = 'dl';
        }
        if ( ! isset( $valid_tags[ $captiontag ] ) ) {
            $captiontag = 'dd';
        }
        if ( ! isset( $valid_tags[ $icontag ] ) ) {
            $icontag = 'dt';
        }
        
        $columns = intval( $atts['columns'] );
        $itemwidth = $columns > 0 ? floor(100/$columns) : 100;
        $float = is_rtl() ? 'right' : 'left';
        
        $selector = "gallery-{$instance}";
        
        $gallery_style = '';
        
        /**
         * Filter whether to print default gallery styles.
         *
         * @since 3.1.0
         *
         * @param bool $print Whether to print default gallery styles.
         *                    Defaults to false if the theme supports HTML5 galleries.
         *                    Otherwise, defaults to true.
         */
        if ( apply_filters( 'use_default_gallery_style', ! $html5 ) ) {
            $gallery_style = "
            <style type='text/css'>
                #{$selector} {
                    margin: auto;
                }
                #{$selector} .gallery-item {
                    float: {$float};
                    margin-top: 10px;
                    text-align: center;
                    width: {$itemwidth}%;
                }
                #{$selector} img {
                    border: 2px solid #cfcfcf;
                }
                #{$selector} .gallery-caption {
                    margin-left: 0;
                }
                /* see gallery_shortcode() in wp-includes/media.php */
            </style>\n\t\t";
        }
        
        $size_class = sanitize_html_class( $atts['size'] );
        $gallery_div = "<div id='$selector' class='gallery galleryid-{$id} gallery-columns-{$columns} gallery-size-{$size_class}'>";
        
        /**
         * Filter the default gallery shortcode CSS styles.
         *
         * @since 2.5.0
         *
         * @param string $gallery_style Default CSS styles and opening HTML div container
         *                              for the gallery shortcode output.
         */
        $output = apply_filters( 'gallery_style', $gallery_style . $gallery_div );
        
        $i = 0; 
        foreach ( $attachments as $id => $attachment ) {
                
            $attr = ( trim( $attachment->post_excerpt ) ) ? array( 'aria-describedby' => "$selector-$id" ) : '';
            if ( ! empty( $atts['link'] ) && 'file' === $atts['link'] ) {
                //$image_output = wp_get_attachment_link( $id, $atts['size'], false, false, false, $attr ); // for attachment url 
                $image_output = "<a href='" . wp_get_attachment_url( $id ) . "' data-fancybox='group{$columns}' data-caption='" . esc_attr( $attachment->post_excerpt ) . "'>";
                $image_output .= wp_get_attachment_image( $id, $atts['size'], false, $attr );
                $image_output .= "</a>";
            } elseif ( ! empty( $atts['link'] ) && 'none' === $atts['link'] ) {
                $image_output = wp_get_attachment_image( $id, $atts['size'], false, $attr );
            } else {
                $image_output = wp_get_attachment_link( $id, $atts['size'], true, false, false, $attr ); //for attachment page
            }
            $image_meta  = wp_get_attachment_metadata( $id );
        
            $orientation = '';
            if ( isset( $image_meta['height'], $image_meta['width'] ) ) {
                $orientation = ( $image_meta['height'] > $image_meta['width'] ) ? 'portrait' : 'landscape';
            }
            $output .= "<{$itemtag} class='gallery-item'>";
            $output .= "
                <{$icontag} class='gallery-icon {$orientation}'>
                    $image_output
                </{$icontag}>";
            if ( $captiontag && trim($attachment->post_excerpt) ) {
                $output .= "
                    <{$captiontag} class='wp-caption-text gallery-caption' id='$selector-$id'>
                    " . wptexturize($attachment->post_excerpt) . "
                    </{$captiontag}>";
            }
            $output .= "</{$itemtag}>";
            if ( ! $html5 && $columns > 0 && ++$i % $columns == 0 ) {
                $output .= '<br style="clear: both" />';
            }
        }
        
        if ( ! $html5 && $columns > 0 && $i % $columns !== 0 ) {
            $output .= "
                <br style='clear: both' />";
        }
        
        $output .= "
            </div>\n";
        
        return $output;
    }
endif;
if( class_exists( 'Jetpack' ) ){
    if( !Jetpack::is_module_active( 'carousel' ) ){
        add_filter( 'post_gallery', 'benevolent_pro_filter_post_gallery', 10, 3 );
    }
}else{
    add_filter( 'post_gallery', 'benevolent_pro_filter_post_gallery', 10, 3 );
}

/** Remove issues with prefetching adding extra views */
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

/** Enable shortcodes in text widgets */
add_filter( 'widget_text', 'do_shortcode' );

if( ! function_exists( 'benevolent_pro_google_analytics' ) ) :
/**
 * Place to add Google Analytics Code
 */
function benevolent_pro_google_analytics() {
    $google_ad_code = get_theme_mod( 'google_analytics_ad_code' );

    echo $google_ad_code;
}
endif;
add_action( 'wp_head' , 'benevolent_pro_google_analytics' );

if( ! function_exists( 'benevolent_pro_update_customizer_search_template' ) ) :
/**
 * Overwrite Customizer Search Template
 **/    
function benevolent_pro_update_customizer_search_template(){
    if( class_exists( 'Customizer_Search' ) ){
        remove_action( 'customize_controls_print_footer_scripts', array( Customizer_Search::instance(), 'footer_scripts' ) );
        add_action( 'customize_controls_print_footer_scripts', function(){ ?>
            <script type="text/html" id="tmpl-search-button">
                <button type="button" class="customize-search-toggle dashicons dashicons-search" aria-expanded="false"><span class="screen-reader-text"><?php _e( 'Search', 'benevolent-pro' ); ?></span></button>
            </script>

            <script type="text/html" id="tmpl-search-form">
                <div id="accordion-section-customizer-search" class="open">
                    <h4 class="customizer-search-section accordion-section-title">
                        <span class="search-input"><?php _e( 'Search', 'benevolent-pro' ); ?></span>
                        <span class="search-field-wrapper">
                            <input type="text" placeholder="<?php _e( 'Search...', 'benevolent-pro' ); ?>" name="customizer-search-input" autofocus="autofocus" id="customizer-search-input" class="customizer-search-input">
                            <button type="button" class="button clear-search" tabindex="0"><?php _e( 'Clear', 'benevolent-pro' ); ?></button>
                        </span>
                    </h4>
                </div>
            </script>
            <?php
        });
    }
}
endif;
add_action( 'init', 'benevolent_pro_update_customizer_search_template' );

if( ! function_exists( 'benevolent_pro_get_the_archive_title' ) ) :
/**
 * Filter Archive Title
*/
function benevolent_pro_get_the_archive_title( $title ){
    
    $ed_prefix = get_theme_mod( 'benevolent_pro_ed_prefix_archive');
        
    if( is_category() ){
        if( $ed_prefix ) $title = single_cat_title( '', false );   
    }elseif( is_tag() ){
        if( $ed_prefix ) $title = single_tag_title( '', false );
    }elseif( is_tax() ){
        if( $ed_prefix ) $title = single_term_title( '', false );
    }elseif( is_year() ) {
        if( $ed_prefix ) $title = get_the_date( _x( 'Y', 'yearly archives date format', 'benevolent-pro' ) );
    }elseif( is_month() ) {
        if( $ed_prefix ) $title = get_the_date( _x( 'F Y', 'monthly archives date format', 'benevolent-pro' ) );
    }elseif( is_day() ) {
        if( $ed_prefix ) $title = get_the_date( _x( 'F j, Y', 'daily archives date format', 'benevolent-pro' ) );
    }elseif( is_author() ){
        if( $ed_prefix ) $title = get_the_author();  
    }elseif( is_post_type_archive( 'product' ) ){
        if( $ed_prefix ){
            $title = get_the_title( get_option( 'woocommerce_shop_page_id' ) );
        }else{
            /* translators: Post type archive title. 1: Post type name */
            $title = __( 'Archives: ', 'benevolent-pro') . get_the_title( get_option( 'woocommerce_shop_page_id' ) );
        }
    }
    return $title;    
}
endif;
add_filter( 'get_the_archive_title', 'benevolent_pro_get_the_archive_title' );

if( ! function_exists( 'benevolent_pro_remove_archive_description' ) ) :
/**
 * filter the_archive_description & get_the_archive_description to show post type archive
 * @param  string $description original description
 * @return string post type description if on post type archive
 */
function benevolent_pro_remove_archive_description( $description ){
    $ed_shop_archive_description = get_theme_mod( 'ed_shop_archive_description' );
    $shop_archive_description    = get_theme_mod( 'shop_archive_description',__( 'This is where you can add new products to your store.','benevolent-pro' ) );
    if( is_post_type_archive( 'product' ) ){
        if( $ed_shop_archive_description && $shop_archive_description ){
            $description = $shop_archive_description;
        }else{
            $description = '';
        }
    }
    return wpautop( wp_kses_post( $description ) );
}
endif;
add_filter( 'get_the_archive_description', 'benevolent_pro_remove_archive_description' );
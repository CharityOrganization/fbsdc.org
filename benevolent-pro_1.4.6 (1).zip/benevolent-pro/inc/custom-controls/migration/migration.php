<?php
/**
 * Benevolent Pro Theme Migration
 *
 * @package Benevolent_Pro
 */

if( ! class_exists( 'Benevolent_Pro_Option_Migration' ) ){
    
    final class Benevolent_Pro_Option_Migration{
        
        private static $instance = null;

		private $migrated;
        
        private $choices;

		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
        
        private function __construct() {			
			add_action( 'wp_ajax_customizer_migration', array( $this, 'ajax_customizer_migration' ) );
			add_action( 'customize_register', array( $this, 'customize_register' ) );
            $this->is_migration_completed();
            $this->migration_choices();
		}
        
        public function customize_register( $wp_customize ){
            $migrated = $this->migrated;
            
            $wp_customize->add_section( 
                'theme_migration', 
                array(
                    'title'    => __( 'Theme Options Migration', 'benevolent-pro' ),
                    'priority' => 500,
        		)
            );
            
            if( $migrated ){
                $wp_customize->add_setting( 
                    'migration_info',
                    array(
                        'default' => '',
                        'sanitize_callback' => 'wp_kses_post',
                    )
                );
        
                $theme_info = sprintf( __( 'You have successfully migrated options from %1$s.', 'benevolent-pro' ),  $migrated );
        
                $wp_customize->add_control( 
                    new Benevolent_Pro_Note_Control( 
                        $wp_customize,
                        'migration_info',
                        array(
                            'label'       => __( 'Migration Completed' , 'benevolent-pro' ),
                            'section'     => 'theme_migration',
                            'description' => $theme_info
                        )
                    )
                );
        
            }else{
                /** Important Links */
            	$wp_customize->add_setting( 
                    'theme_migration',
                    array(
                        'default'           => 'benevolent',
                        'sanitize_callback' => 'wp_kses_post',
                    )
                );
        
                $description = __( '<p><span class="highlight">ATTENTION!!!</span></p>', 'benevolent-pro' );
                $description .= __( '<p>Please read carefully before you proceed. This setting is used to migrate the theme options saved in Benevolent, & Charity Care. Please <strong>DO NOT</strong> use this option on <strong>LIVE site</strong>.</p>', 'benevolent-pro' );
                $description .= __( '<p>Use this option to migrate the settings you have saved in Free (Benevolent) and its respective Child themes (Charity Care) after purchasing this PRO theme. Click on the respective button below of the theme to migrate the theme options that you have used before purchasing this PRO theme.</p>', 'benevolent-pro' );
                $description .= __( '<p>This process is <strong>IRREVERSIBLE</strong> and will remove all customizations ever made via customizer till now.</p>', 'benevolent-pro' );
                
            	$wp_customize->add_control( 
                    new Rara_Controls_Migration_Control( 
                    $wp_customize,
                    'theme_migration',
                        array(
                            'label'           => __( 'Migration of Theme Options', 'benevolent-pro' ),
                            'section'         => 'theme_migration',
                            'description'     => $description,
                            'choices'         => $this->choices,
                            'active_callback' => array( $this, 'migration_ac' )
                		)
                    )
                );
            }
            
        }
        
        public function migration_choices(){
            $choices      = array();
            $benevolent   = get_option( 'theme_mods_benevolent' );
            $charity_care = get_option( 'theme_mods_charity-care' );
            $revive_charity = get_option( 'theme_mods_revive-charity' );
        
            if( $benevolent ){
                $choices['benevolent'] = __( 'Benevolent', 'benevolent-pro' );
            }
            if( $charity_care ){
                $choices['charity-care'] = __( 'Charity Care', 'benevolent-pro' );
            }           
            if( $revive_charity ){
                $choices['revive-charity'] = __( 'Revive Charity', 'benevolent-pro' );
            }
        
            $this->choices = $choices;
        }
        
        public function migration_ac(){
            $benevolent   = get_option( 'theme_mods_benevolent' );
            $charity_care = get_option( 'theme_mods_charity-care' );
            $revive_charity = get_option( 'theme_mods_revive-charity' );
        
            if( $benevolent || $charity_care || $revive_charity ) return true;
        
            return false;
        }
        
        public function is_migration_completed(){
            $migrated      = get_option( '_benevolent_pro_fresh_migrate' );
            $migrated_form = get_option( '_benevolent_pro_migrated_from' );
            if( $migrated ){
                $this->migrated = $migrated_form;
            }else{
                $this->migrated = false;
            }
        }
        
        public function ajax_customizer_migration(){
            $fresh        = get_option( '_benevolent_pro_fresh_migrate' ); //flag to check if it is first switch
            $id           = $_POST['id'];
            $social_array = array();
            $promotional_cta   = array();
            $cta_promotional   = array();
            $cta_counter       = array();
            $cta               = array();
            $counter_cta       = array();
            $counter_sidebar   = array();
            $final_cta_counter = array();
            $j  = 1;
            $i  = 1;
            
            $pages = array(
                'home' => array( 
                    'page_name'     => esc_html__( 'Home', 'benevolent-pro' ),
                    'page_template' => 'templates/template-home.php'
                ),
            );

            if ( ! check_ajax_referer( 'rara-migration', 'nonce', false ) ) {
                wp_send_json_error( 'invalid_nonce' );
            }
            
            if( ! $fresh && $id ){        
                switch( $id ){
                    case 'benevolent':
                    update_option( '_benevolent_pro_migrated_from', 'Benevolent' );
                    $theme_mod = 'theme_mods_benevolent';
                    break;
                    case 'charity-care':
                    update_option( '_benevolent_pro_migrated_from', 'Charity Care' );
                    $theme_mod = 'theme_mods_charity-care';
                    set_theme_mod( 'benevolent_pro_ed_child_style', 'charity-care' );
                    break;
                    case 'revive-charity':
                    update_option( '_benevolent_pro_migrated_from', 'Revive Charity' );
                    $theme_mod = 'theme_mods_revive-charity';
                    set_theme_mod( 'benevolent_pro_ed_child_style', 'revive-charity' );
                    break;
                }
        
                $options         = get_option( $theme_mod );
                $sidebar_options = get_option( 'sidebars_widgets' );
                $front_page      = get_option( 'page_on_front' );

                if( $options ){
            
                    //migrate free theme option to pro
                    foreach( $options as $option => $value ){
                        if( $option == 'benevolent_button_text' ){
                            set_theme_mod( 'benevolent_pro_ed_donate_button', '1' );
                            if( $value ) set_theme_mod( 'benevolent_pro_donate_button_label', $value );
                        }elseif( $option == 'benevolent_button_url' ){
                            if( $value )set_theme_mod( 'benevolent_pro_donate_button_url', $value );
                        }elseif( $option == 'benevolent_ed_slider' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_slider', $value );
                        }elseif( $option == 'benevolent_slider_auto' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_auto', $value );
                        }elseif( $option == 'benevolent_slider_loop' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_loop', $value );
                        }elseif( $option == 'benevolent_slider_pager' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_pager', $value );
                        }elseif( $option == 'benevolent_slider_caption' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_caption', $value );
                        }elseif( $option == 'benevolent_slider_animation' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_animation', $value );
                        }elseif( $option == 'benevolent_slider_speed' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_speed', $value );
                        }elseif( $option == 'benevolent_slider_readmore' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_slider_readmore', $value );
                        }elseif( $option == 'benevolent_slider_cat' ){
                            if( $value ){
                                set_theme_mod( 'benevolent_pro_slider_type', 'cat' );
                                set_theme_mod( 'benevolent_pro_slider_cat', $value );
                            }
                        }elseif( $option == 'benevolent_intro_section_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_section_title', $value );
                        }elseif( $option == 'benevolent_intro_section_content' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_section_content', $value );
                        }elseif( $option == 'benevolent_intro_section_new_tab' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_intro_new_tab', $value );
                        }elseif( $option == 'benevolent_intro_one_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_one_title', $value );
                        }elseif( $option == 'benevolent_intro_one_link' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_one_link_label', $value );
                        }elseif( $option == 'benevolent_intro_one_url' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_one_url', $value );
                        }elseif( $option == 'benevolent_intro_one_logo' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_one_logo', $value );
                        }elseif( $option == 'benevolent_intro_one_image' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_one_image', $value );
                        }elseif( $option == 'benevolent_intro_two_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_two_title', $value );
                        }elseif( $option == 'benevolent_intro_two_link' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_two_link_label', $value );
                        }elseif( $option == 'benevolent_intro_two_url' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_two_url', $value );
                        }elseif( $option == 'benevolent_intro_two_logo' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_two_logo', $value );
                        }elseif( $option == 'benevolent_intro_two_image' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_two_image', $value );
                        }elseif( $option == 'benevolent_intro_three_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_three_title', $value );
                        }elseif( $option == 'benevolent_intro_three_link' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_three_link_label', $value );
                        }elseif( $option == 'benevolent_intro_three_url' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_three_url', $value );
                        }elseif( $option == 'benevolent_intro_three_logo' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_three_logo', $value );
                        }elseif( $option == 'benevolent_intro_three_image' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_intro_three_image', $value );
                        }elseif( $option == 'benevolent_community_section_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_community_section_title', $value );
                        }elseif( $option == 'benevolent_community_post_one' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_community_post_one', $value );
                        }elseif( $option == 'benevolent_community_post_two' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_community_post_two', $value );
                        }elseif( $option == 'benevolent_community_post_three' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_community_post_three', $value );
                        }elseif( $option == 'benevolent_community_post_four' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_community_post_four', $value );
                        }elseif( $option == 'benevolent_first_stats_number' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_first_stats_title' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_second_stats_number' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_second_stats_title' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_third_stats_number' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_third_stats_title' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_fourth_stats_number' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_fourth_stats_title' ){                
                            if( $value ) array_push( $cta_counter, $value );               
                        }elseif( $option == 'benevolent_ed_blog_date' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_blog_date', $value );
                        }elseif( $option == 'benevolent_blog_section_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_blog_section_title', $value );
                        }elseif( $option == 'benevolent_blog_section_content' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_blog_section_content', $value );
                        }elseif( $option == 'benevolent_blog_section_readmore' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_blog_section_readmore', $value );
                        }elseif( $option == 'benevolent_sponsor_section_title' ){                
                            if( $value ) set_theme_mod( 'benevolent_pro_sponsor_section_title', $value );               
                        }elseif( $option == 'benevolent_sponsor_logo_one' || $option == 'benevolent_sponsor_logo_two' || $option == 'benevolent_sponsor_logo_three' || $option == 'benevolent_sponsor_logo_four' || $option == 'benevolent_sponsor_logo_five' ||  $option == 'benevolent_sponsor_logo_one_url' || $option == 'benevolent_sponsor_logo_two_url' || $option == 'benevolent_sponsor_logo_three_url' || $option == 'benevolent_sponsor_logo_four_url' || $option == 'benevolent_sponsor_logo_five_url' ){ 

                            $term_id = get_term_by( 'slug', 'donor', 'logo-category' );
                            if ( $term_id ) set_theme_mod( 'benevolent_pro_sponsor_cat', $term_id->term_id );

                            if( $option == 'benevolent_sponsor_logo_one' || $option == 'benevolent_sponsor_logo_one_url' ){
                                if ( $option == 'benevolent_sponsor_logo_one' ){
                                    if( $value ){ 
                                        $logos = explode( ',', $value );
                                        foreach( $logos as $logo ){
                                            $logo_id = benevolent_pro_get_attachment_id( $logo );
                                            if( $logo_id ) benevolent_pro_duplicate_post_logo( $logo_id, 'logo', true );
                                        }
                                    } 
                                }

                                if ( $option == 'benevolent_sponsor_logo_one_url' ){
                                    if( $value ){
                                        $meta_urls = explode( ',', $value );
                                        foreach( $meta_urls as $meta_url ){
                                            $logo_posts = get_posts( 
                                                array(
                                                  'post_type'   => 'logo'
                                                )
                                            );
                                            foreach( $logo_posts as $logos ){
                                                add_post_meta( $logos->ID,'_benevolent_pro_logo_link',$meta_url );
                                            }
                                        }
                                    }
                                }
                            }elseif( $option == 'benevolent_sponsor_logo_two' || $option == 'benevolent_sponsor_logo_two_url' ){
                                if ( $option == 'benevolent_sponsor_logo_two' ){
                                    if( $value ){ 
                                        $logos = explode( ',', $value );
                                        foreach( $logos as $logo ){
                                            $logo_id = benevolent_pro_get_attachment_id( $logo );
                                            if( $logo_id ) benevolent_pro_duplicate_post_logo( $logo_id, 'logo', true );
                                        }
                                    } 
                                }

                                if ( $option == 'benevolent_sponsor_logo_two_url' ){
                                    if( $value ){
                                        $meta_urls = explode( ',', $value );
                                        foreach( $meta_urls as $meta_url ){
                                            $logo_posts = get_posts( 
                                                array(
                                                  'post_type'   => 'logo'
                                                )
                                            );
                                            foreach( $logo_posts as $logos ){
                                                add_post_meta( $logos->ID,'_benevolent_pro_logo_link',$meta_url );
                                            }
                                        }
                                    }
                                }
                            }elseif( $option == 'benevolent_sponsor_logo_three' || $option == 'benevolent_sponsor_logo_three_url' ){
                                if ( $option == 'benevolent_sponsor_logo_three' ){
                                    if( $value ){ 
                                        $logos = explode( ',', $value );
                                        foreach( $logos as $logo ){
                                            $logo_id = benevolent_pro_get_attachment_id( $logo );
                                            if( $logo_id ) benevolent_pro_duplicate_post_logo( $logo_id, 'logo', true );
                                        }
                                    } 
                                }

                                if ( $option == 'benevolent_sponsor_logo_three_url' ){
                                    if( $value ){
                                        $meta_urls = explode( ',', $value );
                                        foreach( $meta_urls as $meta_url ){
                                            $logo_posts = get_posts( 
                                                array(
                                                  'post_type'   => 'logo'
                                                )
                                            );
                                            foreach( $logo_posts as $logos ){
                                                add_post_meta( $logos->ID,'_benevolent_pro_logo_link',$meta_url );
                                            }
                                        }
                                    }
                                }
                            }elseif( $option == 'benevolent_sponsor_logo_four' || $option == 'benevolent_sponsor_logo_four_url' ){
                                if ( $option == 'benevolent_sponsor_logo_four' ){
                                    if( $value ){ 
                                        $logos = explode( ',', $value );
                                        foreach( $logos as $logo ){
                                            $logo_id = benevolent_pro_get_attachment_id( $logo );
                                            if( $logo_id ) benevolent_pro_duplicate_post_logo( $logo_id, 'logo', true );
                                        }
                                    } 
                                }

                                if ( $option == 'benevolent_sponsor_logo_four_url' ){
                                    if( $value ){
                                        $meta_urls = explode( ',', $value );
                                        foreach( $meta_urls as $meta_url ){
                                            $logo_posts = get_posts( 
                                                array(
                                                  'post_type'   => 'logo'
                                                )
                                            );
                                            foreach( $logo_posts as $logos ){
                                                add_post_meta( $logos->ID,'_benevolent_pro_logo_link',$meta_url );
                                            }
                                        }
                                    }
                                }
                            }elseif( $option == 'benevolent_sponsor_logo_five' || $option == 'benevolent_sponsor_logo_five_url' ){
                                if ( $option == 'benevolent_sponsor_logo_five' ){
                                    if( $value ){ 
                                        $logos = explode( ',', $value );
                                        foreach( $logos as $logo ){
                                            $logo_id = benevolent_pro_get_attachment_id( $logo );
                                            if( $logo_id ) benevolent_pro_duplicate_post_logo( $logo_id, 'logo', true );
                                        }
                                    } 
                                }

                                if ( $option == 'benevolent_sponsor_logo_five_url' ){
                                    if( $value ){
                                        $meta_urls = explode( ',', $value );
                                        foreach( $meta_urls as $meta_url ){
                                            $logo_posts = get_posts( 
                                                array(
                                                  'post_type'   => 'logo'
                                                )
                                            );
                                            foreach( $logo_posts as $logos ){
                                                add_post_meta( $logos->ID,'_benevolent_pro_logo_link',$meta_url );
                                            }
                                        }
                                    }
                                }
                            }
                        }elseif( $option == 'benevolent_promotional_section_title' || $option == 'benevolent_promotional_button_text' || $option == 'benevolent_promotional_button_url' || $option == 'benevolent_promotional_section_bg' ){              
                            if( $option == 'benevolent_promotional_section_title' ) $promotional_cta['title'] = $value; 
                            if( $option == 'benevolent_promotional_button_text' ) $promotional_cta['button_text'] = $value;
                            if( $option == 'benevolent_promotional_button_url' ) $promotional_cta['button_url'] = $value;               
                            if( $option == 'benevolent_promotional_section_bg' ) $promotional_cta['bg_image'] = benevolent_pro_get_attachment_id( $value );               
                        }elseif( $option == 'benevolent_ed_breadcrumb' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_breadcrumb', $value );
                        }elseif( $option == 'benevolent_ed_current' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_current', $value );
                        }elseif( $option == 'benevolent_breadcrumb_home_text' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_breadcrumb_home_text', $value );
                        }elseif( $option == 'benevolent_breadcrumb_separator' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_breadcrumb_separator', $value );
                        }elseif( $option == 'benevolent_ed_social_header' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_ed_social_header', $value );
                        }elseif( $option == 'benevolent_facebook' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'facebook', 'link' => $value ) );
                        }elseif( $option == 'benevolent_twitter' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'twitter', 'link'  => $value ) );
                        }elseif( $option == 'benevolent_pinterest' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'pinterest', 'link'  => $value ) );
                        }elseif( $option == 'benevolent_linkedin' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'linkedin', 'link'  => $value ) );
                        }elseif( $option == 'benevolent_instagram' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'instagram', 'link'  => $value ) );
                        }elseif( $option == 'benevolent_youtube' ){
                            if( $value ) array_push( $social_array, array( 'icon' => 'youtube', 'link'  => $value ) );
                        }elseif( $option == 'benevolent_footer_copyright_text' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_footer_copyright', $value );
                        }elseif( $option == 'charity_care_give_section_title' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_give_section_title', $value );
                        }elseif( $option == 'charity_care_give_section_content' ){
                            if( $value ) set_theme_mod( 'benevolent_pro_give_section_content', $value );
                        }elseif( $option !== 'sidebars_widgets' ){
                            set_theme_mod( $option, $value );
                        }        
                    }

                    if( $promotional_cta ){
                        $cta[$j] = $promotional_cta;
                        array_push( $cta_promotional, 'benevolent_pro_cta_widget-' . $j );               
                        $j++;
                    } 
                    
                    if( $cta ){
                        update_option( 'widget_benevolent_pro_cta_widget', $cta );
                    }

                    if( $cta_promotional ){
                        $final_cta_promotional = array( 'cta' => $cta_promotional );
                    }
                    if( $cta_counter ){
                        $array_list_merge = array(
                            array_slice($cta_counter, 0, 2),
                            array_slice($cta_counter, 2, 2),
                            array_slice($cta_counter, 4, 2),
                            array_slice($cta_counter, 6, 8),
                        );
                        foreach ( $array_list_merge as $counter ) {

                            $counter_cta[$i] = array(
                                'counter' => $counter[0],
                                'title'   => $counter[1],
                            );
                            array_push( $counter_sidebar, 'benevolent_pro_stat_counter_widget-' . $i );
                            $i++;
                        }
                    }
                    
                    if( $counter_cta ){
                        update_option( 'widget_benevolent_pro_stat_counter_widget', $counter_cta );
                    }

                    if( $counter_sidebar ){
                        $final_cta_counter = array( 'stat-counter' => $counter_sidebar );
                    }

                    $final_sidebar = array_merge( $sidebar_options, $final_cta_promotional, $final_cta_counter );

                    update_option( 'sidebars_widgets', $final_sidebar );

                    //create default pages on theme migration
                    foreach( $pages as $page => $val ){
                        benevolent_pro_create_post( $val['page_name'], $page, $val['page_template'] );
                    }

                    if( $social_array ){
                        set_theme_mod( 'benevolent_pro_social', $social_array );
                    }
                }
                update_option( '_benevolent_pro_fresh_migrate', true );  
            }
        
            wp_send_json_success();
        }
    }
}
Benevolent_Pro_Option_Migration::get_instance();
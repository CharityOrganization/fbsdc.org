jQuery(document).ready(function($){
    $('#migration_radio button').on( 'click', function(e){
       e.preventDefault();
       
       var id   = $(this).attr('id');
       var data = {
            action: 'customizer_migration',
            id : id,
            nonce: RaraMigration.nonce
        };

        $.confirm({
		    title: RaraMigration.title,
		    content: RaraMigration.content,
		    type: 'red',
		    typeAnimated: true,
		    icon: 'fas fa-skull-crossbones',
		    autoClose: 'no|15000',
            buttons: {
		        yes: {
		            isHidden: true, // hide the button
		            keys: ['y'],
		            action: function () {
		                $.post(ajaxurl, data, function (e) {
                            wp.customize.state('saved').set(true);
                            location.reload();
                        });
		            }
		        },
		        no: {
		            keys: ['N'],
                    btnClass: 'btn-blue',
		            action: function () {
		                //$.alert('You clicked No.');
		            }
		        },
			}
		});
    });        
});
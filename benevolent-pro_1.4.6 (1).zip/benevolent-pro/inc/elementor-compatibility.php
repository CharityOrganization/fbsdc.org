<?php
/**
 * Helper functions for elementor widgets
 * 
 * @package Benevolent Pro
 */

if( ! function_exists( 'benevolent_pro_add_theme_colors' ) ) :
    /**
     * Benevolent Pro Theme Colors
     *
     * @param [type] $response
     * @param [type] $handler
     * @param [type] $request
     * @return void
     */
    function benevolent_pro_add_theme_colors( $response, $handler, $request ){
        $child_theme_support = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );

        if( $child_theme_support == 'charity-care' ){
            $primary_color   = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
            $secondary_color = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
            $body_color      = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }elseif( $child_theme_support == 'revive-charity' ){
            $primary_color    = get_theme_mod( 'benevolent_pro_primary_color_scheme_revive_charity', '#45c267' );
            $secondary_color  = get_theme_mod( 'benevolent_pro_secondary_color_scheme_revive_charity', '#f8b016' );
            $body_color       = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }else{
            $primary_color    = get_theme_mod( 'benevolent_pro_color_scheme', '#45c267' );
            $secondary_color  = get_theme_mod( 'benevolent_pro_secondary_color_scheme', '#F8B016' );
            $body_color       = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }

        $route = $request->get_route();
    
        if ( '/elementor/v1/globals' != $route ) {
            return $response;
        }
    
        $data = $response->get_data();
        
        $data['colors']['benevolent_pro_primary_color'] = array(
            'id'    => 'benevolent_pro_primary_color',
            'title' =>  __( 'Primary Theme Color', 'benevolent-pro' ),
            'value' => $primary_color,
        );
        
        $data['colors']['benevolent_pro_secondary_color'] = array(
            'id'    => 'benevolent_pro_secondary_color',
            'title' => __( 'Secondary Theme Color', 'benevolent-pro' ),
            'value' => $secondary_color,
        );
    
        $data['colors']['benevolent_pro_body_color'] = array(
            'id'    => 'benevolent_pro_body_color',
            'title' => __( 'Body Font Color', 'benevolent-pro' ),
            'value' => $body_color,
        );
    
        $response->set_data( $data );
    
        return $response;
    }
endif;
add_action( 'rest_request_after_callbacks', 'benevolent_pro_add_theme_colors', 999, 3 );
    
if( ! function_exists( 'benevolent_pro_display_global_colors_elementor' ) ) :
    /**
     * Displays frontend Elementor colors function
     *
     * @param [type] $response
     * @param [type] $handler
     * @param [type] $request
     * @return void
     */
    function benevolent_pro_display_global_colors_elementor( $response, $handler, $request ) {
        $child_theme_support = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );

        if( $child_theme_support == 'charity-care' ){
            $primary_color   = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
            $secondary_color = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
            $body_color      = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }elseif( $child_theme_support == 'revive-charity' ){
            $primary_color    = get_theme_mod( 'benevolent_pro_primary_color_scheme_revive_charity', '#45c267' );
            $secondary_color  = get_theme_mod( 'benevolent_pro_secondary_color_scheme_revive_charity', '#f8b016' );
            $body_color       = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }else{
            $primary_color    = get_theme_mod( 'benevolent_pro_color_scheme', '#45c267' );
            $secondary_color  = get_theme_mod( 'benevolent_pro_secondary_color_scheme', '#F8B016' );
            $body_color       = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
        }

        $route = $request->get_route();
    
        if ( 0 !== strpos( $route, '/elementor/v1/globals' ) ) {
            return $response;
        }
    
        $slug_map = array();
    
        $slug_map['benevolent_pro_primary_color']     = 0;
        $slug_map['benevolent_pro_secondary_color']   = 1;
        $slug_map['benevolent_pro_body_color']        = 2;        
    
        $rest_id = substr( $route, strrpos( $route, '/' ) + 1 );
    
        if ( ! in_array( $rest_id, array_keys( $slug_map ), true ) ) {
            return $response;
        }
           
        $response = rest_ensure_response(
            array(
                'id'    => 'benevolent_pro_primary_color',
                'title' => 'benevolent_pro_primary_color',
                'value' => $primary_color,
            ),
            array(
                'id'    => 'benevolent_pro_secondary_color',
                'title' => 'benevolent_pro_secondary_color',
                'value' => $secondary_color,
            ),
            array(
                'id'    => 'benevolent_pro_body_color',
                'title' => 'benevolent_pro_body_color',
                'value' => $body_color,
            )
        );

        return $response;
    }
endif;
add_action( 'rest_request_after_callbacks', 'benevolent_pro_display_global_colors_elementor', 999, 3 );

if( benevolent_pro_is_elementor_activated() ){
    
    /** Disable Default Colours and Default Fonts of elementor on Theme Activation*/
    $fresh     = get_option( 'benevolent_pro_flag' );
    if( ! $fresh ){
        update_option('elementor_disable_color_schemes', 'yes');
        update_option('elementor_disable_typography_schemes', 'yes');
        update_option( 'benevolent_pro_flag', true ); 
    }
    $flexbox = get_option( 'benevolent_pro_flexbox_flag' );
    if( ! $flexbox ){
        update_option( 'elementor_experiment-container', 'active' ); 
        update_option( 'benevolent_pro_flexbox_flag', true );
    }
}
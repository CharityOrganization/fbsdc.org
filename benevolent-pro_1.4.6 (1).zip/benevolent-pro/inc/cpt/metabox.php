<?php
/**
 * Benevolent Pro Meta Box
 * 
 * @package Benevolent_Pro
 */

 add_action('add_meta_boxes', 'benevolent_pro_add_sidebar_layout_box');

function benevolent_pro_add_sidebar_layout_box(){    
    
    $screens = array( 'post', 'page' );
    foreach ( $screens as $screen ){
        add_meta_box(
                 'benevolent_pro_sidebar_layout', // $id
                 __( 'Sidebar Layout', 'benevolent-pro' ), // $title
                 'benevolent_pro_sidebar_layout_callback', // $callback
                 $screen, // $page
                 'normal', // $context
                 'high' // $priority
        );
    }
    
    // Meta box to add logo link for "Logo"
    add_meta_box(
                 'benevolent_pro_logo_link', // $id
                 __( 'Logo Link', 'benevolent-pro' ), // $title
                 'benevolent_pro_logo_link_callback', // $callback
                 'logo', // $post_type
                 'normal', // $context
                 'low'// $priority
    );  
    
    // Meta box to add designation for "Testimonial"
    add_meta_box(
                 'benevolent_pro_testimonial_designation', // $id
                 __( 'Designation', 'benevolent-pro' ), // $title
                 'benevolent_pro_testimonial_designation_callback', // $callback
                 'testimonial', // $post_type
                 'normal', // $context
                 'high'// $priority
    );
    
    // Meta box to add designation for "Team"
    add_meta_box(
                 'benevolent_pro_team_designation', // $id
                 __( 'Designation', 'benevolent-pro' ), // $title
                 'benevolent_pro_team_designation_callback', // $callback
                 'team', // $post_type
                 'normal', // $context
                 'high'// $priority
    );   
        
}

$benevolent_pro_sidebar_layout = array(         
    'default-sidebar' => array(
                            'value' => 'default-sidebar',
                            'thumbnail' => get_template_directory_uri() . '/images/default-sidebar.png'
                        ),
    'left-sidebar' => array(
                            'value' => 'left-sidebar',
                            'thumbnail' => get_template_directory_uri() . '/images/left-sidebar.png'
                        ),
    'right-sidebar' => array(
                            'value' => 'right-sidebar',
                            'thumbnail' => get_template_directory_uri() . '/images/right-sidebar.png'
                        )
    );

function benevolent_pro_sidebar_layout_callback(){
    
    global $post , $benevolent_pro_sidebar_layout;
    wp_nonce_field( basename( __FILE__ ), 'benevolent_pro_sidebar_layout_nonce' ); 
    
    $sidebars = benevolent_pro_get_dynamnic_sidebar( true, true, true );
    $sidebar  = get_post_meta( $post->ID, '_benevolent_pro_sidebar', true );
?>
<table class="form-table page-meta-box">
    <tr>
        <td colspan="4"><em class="f13"><?php _e( 'Choose Sidebar Template', 'benevolent-pro' ); ?></em></td>
    </tr>

    <tr>
        <td>
        <?php  
            foreach( $benevolent_pro_sidebar_layout as $field ){  
                $layout = get_post_meta( $post->ID, '_benevolent_pro_sidebar_layout', true ); ?>

            <div class="hide-radio radio-image-wrapper" style="float:left; margin-right:30px;">
                <input id="<?php echo esc_attr( $field['value'] ); ?>" type="radio" name="benevolent_pro_sidebar_layout" value="<?php echo esc_attr( $field['value'] ); ?>" <?php checked( $field['value'], $layout ); if( empty( $layout ) ){ checked( $field['value'], 'default-sidebar' ); }?>/>
                <label class="description" for="<?php echo esc_attr( $field['value'] ); ?>">
                    <img src="<?php echo esc_url( $field['thumbnail'] ); ?>" alt="<?php echo esc_attr( $field['value'] ); ?>" />
                </label>
            </div>
            <?php } // end foreach 
            ?>
            <div class="clear"></div>
        </td>
    </tr>
    
    <tr>
        <td colspan="3"><em class="f13"><?php esc_html_e('Choose Sidebar', 'benevolent-pro'); ?></em></td>
    </tr>
    
    <tr>
        <td>
            <select name="benevolent_pro_sidebar">
            <?php 
                foreach( $sidebars as $k => $v ){ ?>
                    <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $sidebar, $k ); if( empty( $sidebar ) && $k == 'default-sidebar' ){ echo "selected='selected'";}?> ><?php echo esc_html( $v ); ?></option>
                <?php }
            ?>
            </select>
        </td>    
    </tr>
    
    <tr>
        <td><em class="f13"><?php printf( esc_html__( 'You can set up the sidebar content from %s', 'benevolent-pro' ), '<a href="'. esc_url( admin_url( 'widgets.php' ) ) .'">here</a>' ); ?></em></td>
    </tr>
    
</table>
<?php        
}

/**
 * save the custom metabox data
 * @hooked to save_post hook
 */
function benevolent_pro_save_sidebar_layout( $post_id ) { 
    
    global $benevolent_pro_sidebar_layout, $post; 

    // Verify the nonce before proceeding.
    if ( !isset( $_POST[ 'benevolent_pro_sidebar_layout_nonce' ] ) || !wp_verify_nonce( $_POST[ 'benevolent_pro_sidebar_layout_nonce' ], basename( __FILE__ ) ) )
        return;

    // Stop WP from clearing custom fields on autosave
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )  
        return;
        
    if ('page' == $_POST['post_type']) {  
        if ( !current_user_can( 'edit_page', $post_id ) )  
            return $post_id;  
    } elseif ( !current_user_can( 'edit_post', $post_id ) ) {  
            return $post_id;  
    }  
    
    // Make sure that it is set.
	if ( ! isset( $_POST['benevolent_pro_sidebar'] ) ) {
		return;
	}
    
    foreach( $benevolent_pro_sidebar_layout as $field ){  
        //Execute this saving function
        $old = get_post_meta( $post_id, '_benevolent_pro_sidebar_layout', true ); 
        $new = sanitize_text_field( $_POST['benevolent_pro_sidebar_layout'] );
        if ( $new && $new != $old ){  
            update_post_meta( $post_id, '_benevolent_pro_sidebar_layout', $new );  
        } elseif( '' == $new && $old ){  
            delete_post_meta( $post_id, '_benevolent_pro_sidebar_layout', $old );  
        } 
    } // end foreach
    
    // Sanitize user input.
	$sidebar = sanitize_text_field( $_POST['benevolent_pro_sidebar'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_benevolent_pro_sidebar', $sidebar );   
}
add_action( 'save_post', 'benevolent_pro_save_sidebar_layout' ); 

/**
 * Callback for Logo Link
*/
function benevolent_pro_logo_link_callback(){
    global $post;
    wp_nonce_field( basename( __FILE__ ), 'benevolent_pro_logo_link_nonce' );
    
    $link = get_post_meta( $post->ID, '_benevolent_pro_logo_link', true );
    ?>
    <div>
        <div class="clearfix">
            <label class="bold-label float-left input_label" for="benevolent_pro_logo_link"><?php _e( 'Link', 'benevolent-pro' ); ?></label>
            <div class="below_row_input float-left"><input type="text" id="benevolent_pro_logo_link" name="benevolent_pro_logo_link" value="<?php echo esc_url( $link ); ?>" /></div>
        </div>
    </div>
    <?php    
}

function benevolent_pro_save_logo_link( $post_id ){
    // Check if our nonce is set.
	if ( ! isset( $_POST['benevolent_pro_logo_link_nonce'] ) || ! wp_verify_nonce( $_POST['benevolent_pro_logo_link_nonce'], basename( __FILE__ ) ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post_id ) ) return;		
	} else {
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;
	}
    
    if ( ! isset( $_POST['benevolent_pro_logo_link'] ) ) {
		return;
	}
    
    // Sanitize user input.
	$link = esc_url_raw( $_POST['benevolent_pro_logo_link'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_benevolent_pro_logo_link', $link );

}
add_action( 'save_post', 'benevolent_pro_save_logo_link' );

/**
 * Callback for Testimonail Designation
*/
function benevolent_pro_testimonial_designation_callback(){
    global $post;
    wp_nonce_field( basename( __FILE__ ), 'benevolent_pro_testimonial_designation_nonce' );
    
    $designation = get_post_meta( $post->ID, '_benevolent_pro_testimonial_designation', true );
    ?>
    <div>
        <div class="clearfix">
            <label class="bold-label float-left input_label" for="benevolent_pro_testimonial_designation"><?php _e( 'Designation', 'benevolent-pro' ); ?></label>
            <div class="below_row_input float-left"><input type="text" id="benevolent_pro_testimonial_designation" name="benevolent_pro_testimonial_designation" value="<?php echo esc_attr( $designation ); ?>" /></div>
        </div>
    </div>
    <?php
}

function benevolent_pro_save_testimonial_designation( $post_id ){
    // Check if our nonce is set.
	if ( ! isset( $_POST['benevolent_pro_testimonial_designation_nonce'] ) || ! wp_verify_nonce( $_POST['benevolent_pro_testimonial_designation_nonce'], basename( __FILE__ ) ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post_id ) ) return;		
	} else {
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;
	}
    
    if ( ! isset( $_POST['benevolent_pro_testimonial_designation'] ) ) {
		return;
	}
    
    // Sanitize user input.
	$designation = sanitize_text_field( $_POST['benevolent_pro_testimonial_designation'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_benevolent_pro_testimonial_designation', $designation );

}
add_action( 'save_post', 'benevolent_pro_save_testimonial_designation' );

/**
 * Callback for Additional Info for Team
*/
function benevolent_pro_team_designation_callback(){
    global $post;
    wp_nonce_field( basename( __FILE__ ), 'benevolent_pro_team_designation_nonce' );
    
    $designation = get_post_meta( $post->ID, '_benevolent_pro_team_designation', true );
    ?>
    
    <div class="clearfix">
        <label class="bold-label float-left input_label" for="benevolent_pro_team_designation"><?php _e( 'Designation', 'benevolent-pro' ); ?></label>
        <div class="below_row_input float-left"><input type="text" id="benevolent_pro_team_designation" name="benevolent_pro_team_designation" value="<?php echo esc_attr( $designation ); ?>" /></div>
    </div>
    
    <?php
}

function benevolent_pro_save_team_designation( $post_id ){
    // Check if our nonce is set.
	if ( ! isset( $_POST['benevolent_pro_team_designation_nonce'] ) || ! wp_verify_nonce( $_POST['benevolent_pro_team_designation_nonce'], basename( __FILE__ ) ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post_id ) ) return;		
	} else {
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;
	}
    
    if ( ! isset( $_POST['benevolent_pro_team_designation'] ) ) {
		return;
	}
    
    // Sanitize user input.
	$designation = sanitize_text_field( $_POST['benevolent_pro_team_designation'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_benevolent_pro_team_designation', $designation );
    

}
add_action( 'save_post', 'benevolent_pro_save_team_designation' );
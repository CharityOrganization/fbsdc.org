<?php
/**
 * Benevolent Pro Theme Customizer.
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_move_sections( $wp_customize ){

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';

    if ( version_compare( $GLOBALS['wp_version'], '4.7', '>=' ) ) {
        $wp_customize->get_section( 'custom_css' )->panel = 'benevolent_pro_custom_code_panel';
    }

    $wp_customize->get_section( 'title_tagline' )->panel = 'benevolent_pro_header_setting';

    if ( version_compare( get_bloginfo('version'),'4.9', '>=') ) {
		$wp_customize->get_section( 'static_front_page' )->title = __( 'Static Front Page', 'benevolent-pro' );
    }
}
add_action( 'customize_register', 'benevolent_pro_move_sections' );
  
$controls = array( 'panels', 'sections', 'note', 'select', 'toggle', 'radio', 'text', 'multicheck', 'typography', 'slider', 'repeater', 'sort', 'radio-image', 'image', 'color', 'radio-buttonset', 'code', 'editor' );

foreach( $controls as $control ){
    require get_template_directory() . '/inc/customizer/controls/' . $control . '.php';
}

/**
 * Sanitization Functions
*/
require get_template_directory() . '/inc/customizer/sanitization-functions.php';

/**
 * Active Callbacks
*/
require get_template_directory() . '/inc/customizer/active-callback.php';

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function benevolent_pro_customize_preview_js() {

	$build  = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '/build' : '';
    $suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'benevolent_pro_customizer', get_template_directory_uri() . '/js' . $build . '/customizer' . $suffix . '.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'benevolent_pro_customize_preview_js' );
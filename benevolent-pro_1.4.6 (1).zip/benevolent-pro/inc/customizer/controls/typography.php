<?php
/**
 * Typography Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_typography( $wp_customize ){

    $typography = array(
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_body_font',
            'label'       => __( 'Body Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_typography_body_section',
            'default'     => array(
                'font-family' => 'Raleway',
                'variant'     => 'regular',
            ),
            'active_callback' => 'benevolent_pro_typography_ac'
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_hps_title_font',
            'label'       => __( 'Home Page Section Title Font', 'benevolent-pro' ),
            'tooltip'     => __( 'Setting for the Section Title of Home Page Section', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_hps_title_section',
            'default'     => array(
                'font-family' => 'Raleway',
                'variant'     => '700',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_page_title_font',
            'label'       => __( 'Page Title Font', 'benevolent-pro' ),
            'tooltip'     => __( 'Setting for Page title above breadcrumb', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_page_title_setting',
            'default'     => array(
                'font-family' => 'Raleway',
                'variant'     => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_post_title_font',
            'label'       => __( 'Post Title Font', 'benevolent-pro' ),
            'tooltip'     => __( 'Setting for Post Title in Blog/Archive Page.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_post_title_setting',
            'default'     => array(
                'font-family' => 'Raleway',
                'variant'     => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h1_font',
            'label'       => __( 'H1 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h1_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h2_font',
            'label'       => __( 'H2 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h2_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h3_font',
            'label'       => __( 'H3 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h3_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h4_font',
            'label'       => __( 'H4 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h4_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h5_font',
            'label'       => __( 'H5 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h5_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_h6_font',
            'label'       => __( 'H6 Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_h6_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => 'regular',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_widget_title_font',
            'label'       => __( 'Widget Title Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_widget_title_section',
            'default'     => array(
                'font-family'    => 'Raleway',
                'variant'        => '700',
            ),
        ),
        array(
            'type'        => 'typography',
            'settings'    => 'benevolent_pro_body_font_rc',
            'label'       => __( 'Body Font', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_typography_body_section',
            'default'     => array(
                'font-family' => 'Lexend Deca',
                'variant'     => 'regular',
            ),
            'active_callback' => 'benevolent_pro_typography_ac'
        ),
    );

    foreach( $typography as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => array( 'Benevolent_Pro_Fonts', 'sanitize_typography' )
            )
        );
        
        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new Benevolent_Pro_Typography_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_typography' );
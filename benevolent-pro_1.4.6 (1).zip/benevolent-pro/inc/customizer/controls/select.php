<?php
/**
 * Select Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_select( $wp_customize ){
    
    /** Zoom Level */
    $zoom = array();
    for($z = 1; $z < 20; $z++){
        $zoom[$z] = $z;
    }

    $selects = array(
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_donate_form',
            'label'           => __( 'Choose Donate Form', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_header_misc_setting',
            'choices'         => benevolent_pro_get_posts( 'give_forms' ),
            'default'         => '',
            'active_callback' => 'benevolent_pro_donate_button_ac',
            'priority'        => 11
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_slider_animation',
            'label'    => __( 'Choose Slider Animation', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => 'slide',
            'choices'  => benevolent_pro_slider_animation_options(),
            'priority' => 15
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_slider_type',
            'label'    => __( 'Choose Slider Type', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_contents',
            'default'  => 'post',
            'choices'  => array(
                'post'   => __( 'Post/Page', 'benevolent-pro' ),
                'cat'    => __( 'Category', 'benevolent-pro' ),
                'custom' => __( 'Custom', 'benevolent-pro' ),
            )
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_post_one',
            'label'           => __( 'Choose Post/Page One', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_posts( array( 'post', 'page' ) ),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_post_two',
            'label'           => __( 'Choose Post/Page Two', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_posts( array( 'post', 'page' ) ),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_post_three',
            'label'           => __( 'Choose Post/Page Three', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_posts( array( 'post', 'page' ) ),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_post_four',
            'label'           => __( 'Choose Post/Page Four', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_posts( array( 'post', 'page' ) ),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_post_five',
            'label'           => __( 'Choose Post/Page Five', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_posts( array( 'post', 'page' ) ),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'            => 'select',
            'settings'        => 'benevolent_pro_slider_cat',
            'label'           => __( 'Choose Slider Category', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_slider_contents',
            'default'         => '',
            'choices'         => benevolent_pro_get_categories(),
            'active_callback' => 'benevolent_pro_banner_ac'
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_community_post_one',
            'label'    => __( 'Select Post One', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_community_settings',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts( array( 'post', 'page' ) ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_community_post_two',
            'label'    => __( 'Select Post Two', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_community_settings',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts( array( 'post', 'page' ) ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_community_post_three',
            'label'    => __( 'Select Post Three', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_community_settings',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts( array( 'post', 'page' ) ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_community_post_four',
            'label'    => __( 'Select Post Four', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_community_settings',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts( array( 'post', 'page' ) ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_sponsor_cat',
            'label'    => __( 'Sponsor Logo Category', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sponsor_settings',
            'default'  => '',
            'choices'  => benevolent_pro_get_categories( true, 'logo-category' ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_current_project_one',
            'label'    => __( 'Select Post One', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_about_current_project_section',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts()
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_current_project_two',
            'label'    => __( 'Select Post Two', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_about_current_project_section',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts()
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_current_project_three',
            'label'    => __( 'Select Post Three', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_about_current_project_section',
            'default'  => '',
            'choices'  => benevolent_pro_get_posts()
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_service_donor_cat',
            'label'    => __( 'Donor Logo Category', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_service_donor_section',
            'default'  => '',
            'choices'  => benevolent_pro_get_categories( true, 'logo-category' ),
            'priority' => 20
        ),
        array(
            'type'        => 'select',
            'settings'    => 'benevolent_pro_post_meta',
            'label'       => __( 'Post Meta', 'benevolent-pro' ),
            'description' => __( 'You can rearrange the order you want.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_post_meta_settings',
            'multiple'    => 3,
            'choices'     => array(                    
                'author'  => __( 'Author', 'benevolent-pro' ),
                'date'    => __( 'Date', 'benevolent-pro' ),
                'comment' => __( 'Comment', 'benevolent-pro' ),
            ),
            'default' => array( 'author', 'date', 'comment' ),
        ),
        array(
            'type'        => 'select',
            'settings'    => 'benevolent_pro_cat_tag',
            'label'       => __( 'Categories and Tags', 'benevolent-pro' ),
            'description' => __( 'Post meta in single post page. You can rearrange the order you want.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_post_meta_settings',
            'multiple'    => 3,
            'choices'     => array(
                'cat' => __( 'Categories', 'benevolent-pro' ),
                'tag' => __( 'Tags', 'benevolent-pro' ),
            ),
            'default' => array( 'cat', 'tag' ),
        ),
        array(
            'settings' => 'benevolent_pro_google_map_option',
            'label'    => __( 'Google Map Option', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_google_map_section',
            'type'     => 'select',
            'default'  => 'google_map_api',
            'choices'  => array(
                'google_map_api'    => __( 'Google Map API', 'benevolent-pro' ),
                'google_map_iframe' => __( 'Google Map Iframe', 'benevolent-pro' ),
            ),
            'active_callback' => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'        => 'benevolent_pro_map_zoom',
            'label'           => __( 'Zoom Level', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_google_map_section',
            'type'            => 'select',
            'default'         => '17',
            'choices'         => $zoom,
            'active_callback' => 'benevolent_pro_google_map_ac',
            'priority'        => 20
        ),
        array(
            'settings' => 'benevolent_pro_map_type',
            'label'    => __( 'Map Type', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_google_map_section',
            'type'     => 'select',
            'default'  => 'ROADMAP',
            'choices'  => array(
                'ROADMAP'   => __( 'ROADMAP', 'benevolent-pro' ),
                'SATELLITE' => __( 'SATELLITE', 'benevolent-pro' ),
                'HYBRID'    => __( 'HYBRID', 'benevolent-pro' ),
                'TERRAIN'   => __( 'TERRAIN', 'benevolent-pro' )
            ),
            'active_callback' => 'benevolent_pro_google_map_ac',
            'priority'        => 20
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_ed_child_style',
            'label'    => __( 'Select Theme Style', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_styling_settings',
            'default'  => 'default',
            'choices'  => array(
                'default'        => __('Benevolent Default Style','benevolent-pro'),
                'charity-care'   => __('Charity Care Style','benevolent-pro'),
                'revive-charity' => __( 'Revive Charity', 'benevolent-pro' ),
            ),
            'priority' => 25
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_blog_page_sidebar',
            'label'    => __( 'Blog Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the blog page.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_single_page_sidebar',
            'label'    => __( 'Single Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the single pages. If a page has a custom sidebar set, it will override this.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_single_post_sidebar',
            'label'    => __( 'Single Post Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the single posts. If a post has a custom sidebar set, it will override this.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_archive_page_sidebar',
            'label'    => __( 'Archive Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the archives. Specific archive sidebars will override this setting (see below).', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_cat_archive_page_sidebar',
            'label'    => __( 'Category Archive Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the category archives.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'default-sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_tag_archive_page_sidebar',
            'label'    => __( 'Tag Archive Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the tag archives.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'default-sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_date_archive_page_sidebar',
            'label'    => __( 'Date Archive Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the date archives.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'default-sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_author_archive_page_sidebar',
            'label'    => __( 'Author Archive Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the author archives.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'default-sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true, true ),
        ),
        array(
            'type'     => 'select',
            'settings' => 'benevolent_pro_search_page_sidebar',
            'label'    => __( 'Search Page Sidebar', 'benevolent-pro' ),
            'tooltip'  => __( 'Select a sidebar for the search results.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sidebar_settings',
            'default'  => 'sidebar',
            'choices'  => benevolent_pro_get_dynamnic_sidebar( true, true ),
        ),
        array(
            'type'        => 'select',
            'settings'    => 'benevolent_pro_social_contact',
            'label'       => __( 'Social Icons in Contact Widget', 'benevolent-pro' ),
            'description' => __( 'You can rearrange the order you want.', 'benevolent-pro' ),
            'priority'    => 20,
            'section'     => 'benevolent_pro_social_settings',
            'multiple'    => 5,
            'choices'     => benevolent_pro_social_icons(),
            'default'     => array( 'facebook', 'twitter', 'linkedin', 'google-plus', 'pinterest' ),
        ),
    );

    foreach( $selects as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_select',
            )
        );
        
        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['multiple' ] ) && $val['multiple'] ) $array['multiple']                      = $val['multiple'];
        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new Benevolent_Pro_Select_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_select' );
<?php
/**
 * Text Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_text( $wp_customize ){
    $text = array(
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_donate_button_label',
            'label'             => __( 'Donate Button Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_header_misc_setting',
            'default'           => __( 'Donate Now', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_donate_button_ac',
            'priority'          => 15
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_donate_button_url',
            'label'             => __( 'Donate Button Url', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_header_misc_setting',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'active_callback'   => 'benevolent_pro_donate_button_ac',
            'priority'          => 15
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_load_more_label',
            'label'             => __( 'Load More Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_general_settings',
            'default'           => __( 'Load More Posts', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_loading_ac',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_loading_label',
            'label'             => __( 'Loading Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_general_settings',
            'default'           => __( 'Loading...', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_loading_ac',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'shop_archive_description',
            'label'             => __( 'Shop Page Description', 'benevolent-pro' ),
            'tooltip'           => __( 'Enable to show Shop Page Description.', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_general_settings',
            'default'           => __( 'Write new description for Shop Page to overwrite the default description.', 'benevolent-pro' ),
            'sanitize_callback' => 'wp_kses_post',
            'active_callback'   => 'benevolent_pro_shop_description_ac',
            'priority'          => 20
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_slider_readmore',
            'label'             => __( 'Readmore Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_slider_contents',
            'default'           => __( 'Learn More', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 20
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_section_title',
            'label'             => __( 'Intro Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 5
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_intro_section_content',
            'label'             => __( 'Intro Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
            'priority'          => 5
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_one_title',
            'label'             => __( 'Intro One Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 15
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_one_link_label',
            'label'             => __( 'Intro One Link Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 15
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_one_url',
            'label'             => __( 'Intro One Link', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'priority'          => 15
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_two_title',
            'label'             => __( 'Intro Two Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 20
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_two_link_label',
            'label'             => __( 'Intro Two Link Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 20
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_two_url',
            'label'             => __( 'Intro Two Link', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'priority'          => 20
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_three_title',
            'label'             => __( 'Intro Three Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 25
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_three_link_label',
            'label'             => __( 'Intro Three Link Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 25
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_intro_three_url',
            'label'             => __( 'Intro Three Link', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_intro_settings',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'priority'          => 25
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_community_section_title',
            'label'             => __( 'Community Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_community_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 5
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_community_readmore',
            'label'             => __( 'Community Section Read more Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_community_settings',
            'default'           => __( 'LEARN MORE', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 20,
            'active_callback'   => 'benevolent_pro_community_section_ac'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_give_section_title',
            'label'             => __( 'Give Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_give_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback' => 'is_give_activated'
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_give_section_content',
            'label'             => __( 'Give Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_give_settings',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
            'active_callback' => 'is_give_activated'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_give_button_label',
            'label'             => __( 'Donate Button Label', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_give_settings',
            'default'           => __( 'Donate Now', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback' => 'is_give_activated'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_blog_section_title',
            'label'             => __( 'Blog Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_blog_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_blog_section_content',
            'label'             => __( 'Blog Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_blog_settings',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_blog_section_readmore',
            'label'             => __( 'Blog Section Read More Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_blog_settings',
            'default'           => __( 'Read More', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_blog_section_viewall',
            'label'             => __( 'Blog Section View All Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_blog_settings',
            'default'           => __( 'READ ALL BLOG', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_blog_ac'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_blog_section_viewall_link',
            'label'             => __( 'Blog Section View All Link', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_blog_settings',
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'active_callback'   => 'benevolent_pro_blog_ac'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_sponsor_section_title',
            'label'             => __( 'Sponsor Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_sponsor_settings',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 5
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_sponsor_section_content',
            'label'             => __( 'Sponsor Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_sponsor_settings',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
            'priority'          => 5
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_about_video_iframe',
            'label'             => __( 'Video Iframe', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_about_intro_section',
            'default'           => '',
            'sanitize_callback' => 'benevolent_pro_sanitize_code'
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_about_video_caption',
            'label'             => __( 'Video Caption', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_about_intro_section',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_profile_section_title',
            'label'             => __( 'Profile Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_profile_section',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_profile_section_content',
            'label'             => __( 'Profile Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_profile_section',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_believe_section_title',
            'label'             => __( 'We Believe Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_about_believe_section',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_current_project_section_title',
            'label'             => __( 'Current Project Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_about_current_project_section',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 5
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_service_video_iframe',
            'label'             => __( 'Video Iframe', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_service_intro_section',
            'default'           => '',
            'sanitize_callback' => 'benevolent_pro_sanitize_code'
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_services_section_title',
            'label'             => __( 'Services Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_service_services_section',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_services_section_content',
            'label'             => __( 'Services Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_service_services_section',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'type'              => 'text',
            'settings'          => 'benevolent_pro_service_donor_title',
            'label'             => __( 'Donor Section Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_service_donor_section',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_service_donor_content',
            'label'             => __( 'Donor Section Content', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_service_donor_section',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'label'             => __( 'Post Read More Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_post_meta_settings',
            'settings'          => 'benevolent_pro_post_read_more',
            'type'              => 'text',
            'default'           => __( 'Read More', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
            'priority'          => 20
        ),
        array(
            'settings'          => 'benevolent_pro_marker_title',
            'label'             => __( 'Marker Title', 'benevolent-pro' ),
            'tooltip'           => __( 'Enter the Marker Title', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'type'              => 'text',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'          => 'benevolent_pro_map_api',
            'label'             => __( 'Google Map API Key', 'benevolent-pro' ),
            'tooltip'           => __( 'Enter the Google Map API Key', 'benevolent-pro' ),
            'description'       => __( 'You can get API key from here https://developers.google.com/maps/documentation/javascript/get-api-key', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'type'              => 'text',
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'          => 'benevolent_pro_lattitude',
            'label'             => __( 'Latitude', 'benevolent-pro' ),
            'tooltip'           => __( 'Enter the Latitude of your Location', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'type'              => 'text',
            'default'           => 27.7304135,
            'sanitize_callback' => 'benevolent_pro_sanitize_number_floatval',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'          => 'benevolent_pro_longitude',
            'label'             => __( 'Longitude', 'benevolent-pro' ),
            'tooltip'           => __( 'Enter the Longitude of your Location', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'type'              => 'text',
            'default'           => 85.3304937,
            'sanitize_callback' => 'benevolent_pro_sanitize_number_floatval',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'          => 'benevolent_pro_map_height',
            'label'             => __( 'Map Height', 'benevolent-pro' ),
            'tooltip'           => __( 'Enter the height of map for example: 300', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'type'              => 'number',
            'default'           => 500,
            'sanitize_callback' => 'benevolent_pro_sanitize_number_absint',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'          => 'benevolent_pro_map_iframe',
            'label'             => __( 'Google Map Iframe', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_google_map_section',
            'tooltip'           => __( 'Input Google Map iframe.', 'benevolent-pro' ),
            'type'              => 'textarea',
            'default'           => '',
            'sanitize_callback' => 'benevolent_pro_sanitize_code',
            'active_callback'   => 'benevolent_pro_google_map_ac',
        ),
        array(
            'label'             => __( 'Breadcrumb Home Text', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_breadcrumb_settings',
            'settings'          => 'benevolent_pro_breadcrumb_home_text',
            'type'              => 'text',
            'default'           => __( 'Home', 'benevolent-pro' ),
            'sanitize_callback' => 'sanitize_text_field',
        ),
        array(
            'label'             => __( 'Breadcrumb Separator', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_breadcrumb_settings',
            'settings'          => 'benevolent_pro_breadcrumb_separator',
            'type'              => 'text',
            'default'           => __( '>', 'benevolent-pro' ),
            'sanitize_callback' => 'wp_kses_post',
        ),
        array(
            'type'              => 'textarea',
            'settings'          => 'benevolent_pro_footer_copyright',
            'label'             => __( 'Footer Copyright', 'benevolent-pro' ),
            'tooltip'           => __( 'You can change footer copyright and use your own custom text from here. Add [the-year],[the-site-link] shortcode to add current year and site link.', 'benevolent-pro' ),
            'section'           => 'benevolent_pro_footer_settings',
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
            'priority'          => 5
        )
    );

    foreach( $text as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => $val['sanitize_callback'],
            )
        );

        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'type'    => $val['type']
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control( $val['settings'], $array );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_text' );
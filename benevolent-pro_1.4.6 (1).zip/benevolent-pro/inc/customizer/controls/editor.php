<?php
/**
 * Editor Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_editor( $wp_customize ){
    $editors = array(
        array(
            'type'     => 'editor',
            'settings' => 'benevolent_pro_believe_section_content',
            'label'    => __( 'We Believe Section content', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_about_believe_section',
            'default'  => '',
        )
    );

    foreach( $editors as $val ){

        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );
        
        $array = array(
            'section'     => $val['section'],
            'label'       => $val['label'],
            'input_attrs' => array(
                'toolbar1'     => 'bold italic bullist numlist alignleft aligncenter alignright link',
                'mediaButtons' => true,
            )
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new Benevolent_Pro_Editor_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_editor' );
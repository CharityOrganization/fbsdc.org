<?php
/**
 * Note Control
 *
 * @package Benevolent_Pro
 */

function benevonet_pro_customizer_theme_note( $wp_customize ) {
	
    $theme_info = '<ul>';
    $theme_info .= sprintf( __( '<li>View demo: %1$sClick here.%2$s</li>', 'benevolent-pro' ),  '<a href="' . esc_url( 'https://rarathemes.com/previews/?theme=benevolent-pro' ) . '" target="_blank">', '</a>' );
    $theme_info .= sprintf( __( '<li>View documentation: %1$sClick here.%2$s</li>', 'benevolent-pro' ),  '<a href="' . esc_url( 'https://docs.rarathemes.com/docs/benevolent-pro/' ) . '" target="_blank">', '</a>' );
    $theme_info .= sprintf( __( '<li>Theme info: %1$sClick here.%2$s</li>', 'benevolent-pro' ),  '<a href="' . esc_url( 'https://rarathemes.com/wordpress-themes/benevolent-pro/' ) . '" target="_blank">', '</a>' );
    $theme_info .= sprintf( __( '<li>Support ticket: %1$sClick here.%2$s</li>', 'benevolent-pro' ),  '<a href="' . esc_url( 'https://rarathemes.com/support-ticket/' ) . '" target="_blank">', '</a>' );
    $theme_info .= sprintf( __( '<li>More WordPress Themes: %1$sClick here.%2$s</li>', 'benevolent-pro' ),  '<a href="' . esc_url( 'https://rarathemes.com/wordpress-themes/' ) . '" target="_blank">', '</a>' );
    $theme_info .= '</ul>';

	$notes = array(
        'theme_info_theme' => array(
            'label'       => __( 'Important Links' , 'benevolent-pro' ),
            'section'     => 'theme_info',
            'description' => $theme_info
        ),
        'typography_text' => array(
            'section'     => 'benevolent_pro_typography_body_section',
            'description' => sprintf( __( 'To load google fonts from your own server instead from google\'s CDN enable the %1$sLocally Host Google Fonts%2$s option in Performance Settings.', 'benevolent-pro' ), '<span class="text-inner-link typography_text">', '</span>' ),
            'priority'    => 20
        ),
        'revive_charity_text' => array(
            'section'         => 'benevolent_pro_ed_child_style',
            'description'     => sprintf(__( 'To achieve the exact layout of "Revive Charity" child theme, please select the %1$ssecond header layout%2$s', 'benevolent-pro' ), '<span class="child-inner-link h-layout">', '</span>' ),
            'active_callback' => 'benevolent_pro_child_support_ac',
            'priority'        => 30
        ),
    );

    foreach( $notes as $key => $val ){
        $wp_customize->add_setting(
            $key,
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $array = array(
            'section'     => $val['section'],
            'description' => $val['description'],
        );

        if( isset( $val['label' ] ) && $val['label'] ) $array['label']                               = $val['label'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control(
            new Benevolent_Pro_Note_Control( 
                $wp_customize,
                $key,
                $array
            )
        );
    }

}
add_action( 'customize_register', 'benevonet_pro_customizer_theme_note' );
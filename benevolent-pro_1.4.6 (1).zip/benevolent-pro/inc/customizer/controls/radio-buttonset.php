<?php
/**
 * Radio Image Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_radio_buttonset( $wp_customize ){
    $radio_images = array(
        array(
            'label'    => __( 'Team Order', 'benevolent-pro' ),
            'tooltip'  => __( 'Choose team order for team page.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'settings' => 'cpt_team_page_order_type',
            'type'     => 'radio-buttonset',
            'default'  => 'date',
            'choices'  => array(
                'date'       => __( 'Post Date', 'benevolent-pro' ),
                'menu_order' => __( 'Menu Order', 'benevolent-pro' ),
            ),
        ),
        array(
            'label'    => __( 'Testimonial Order', 'benevolent-pro' ),
            'tooltip'  => __( 'Choose testimonial order for team page.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'settings' => 'cpt_testimonial_page_order_type',
            'type'     => 'radio-buttonset',
            'default'  => 'date',
            'choices'  => array(
                'date'       => __( 'Post Date', 'benevolent-pro' ),
                'menu_order' => __( 'Menu Order', 'benevolent-pro' ),
            ),
        ),
        array(
            'label'    => __( 'Body Background', 'benevolent-pro' ),
            'tooltip'  => __( 'Choose body background as image or pattern.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_styling_settings',
            'settings' => 'benevolent_pro_body_bg',
            'type'     => 'radio-buttonset',
            'default'  => 'image',
            'choices'  => array(
                'image'   => __( 'Image', 'benevolent-pro' ),
                'pattern' => __( 'Pattern', 'benevolent-pro' ),
            ),
        )
    );

    foreach( $radio_images as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_radio',
            )
        );

        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control(
            new Benevolent_Pro_Radio_Buttonset_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_radio_buttonset' );
<?php
/**
 * Code Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_code( $wp_customize ) {
        
    $codes = array( 
        'google_analytics_ad_code' => array(
            'section'     => 'google_analytics_settings',
            'label'       => __( 'Analytics Code', 'benevolent-pro' ),
            'description' => __( 'Paste your google analytics code here.', 'benevolent-pro' ),
        ),
        'benevolent_pro_custom_script' => array(
            'label'       => __( 'Custom Script', 'benevolent-pro' ),
            'description' => __( 'Put the script like anlytics or any other here.', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_custom_settings',
        )
    );
    
    foreach( $codes as $key => $val ){
        $wp_customize->add_setting(
            $key,
            array(
                'default'           => '',
                'sanitize_callback' => 'benevolent_pro_sanitize_code',
            )
        );

        $array = array(
            'section'   => $val['section'],
            'label'     => $val['label'],
            'code_type' => 'javascript',
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control(
            new WP_Customize_Code_Editor_Control( 
                $wp_customize,
                $key,
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_code' );
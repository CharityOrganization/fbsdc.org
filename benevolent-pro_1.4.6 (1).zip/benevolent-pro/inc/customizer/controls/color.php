<?php
/**
 * Color Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_color( $wp_customize ){
    $colors = array(
        array(
            'label'    => __( 'Backgrond Color ', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_community_settings',
            'settings' => 'benevolent_pro_community_bg',
            'type'     => 'color',
            'default'  => '#0f907f',
        ),
        array(
            'label'           => __( 'Backgrond Color ', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_give_settings',
            'settings'        => 'benevolent_pro_give_bg',
            'type'            => 'color',
            'default'         => '#0f907f',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Backgrond Color ', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_give_settings',
            'settings'        => 'benevolent_pro_give_bg_charity_care',
            'type'            => 'color',
            'default'         => '#5890ff',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Color Scheme', 'benevolent-pro' ),
            'tooltip'         => __( 'The theme comes with unlimited color schemes for your theme styling.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_color_scheme',
            'type'            => 'color',
            'default'         => '#45c267',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Secondary Color Scheme', 'benevolent-pro' ),
            'tooltip'         => __( 'Secondary color scheme for your theme styling. Please choose dark based color.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_secondary_color_scheme',
            'type'            => 'color',
            'default'         => '#F8B016',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Primary Color', 'benevolent-pro' ),
            'tooltip'         => __( 'Secondary color scheme for your theme styling. Please choose dark based color.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_secondary_color_scheme_charity_care',
            'type'            => 'color',
            'default'         => '#2dc08d',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Primary Color', 'benevolent-pro' ),
            'tooltip'         => __( 'Primary color scheme for your theme styling. Please choose dark based color.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_primary_color_scheme_revive_charity',
            'type'            => 'color',
            'default'         => '#45c267',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'           => __( 'Secondary Color', 'benevolent-pro' ),
            'tooltip'         => __( 'Secondary color scheme for your theme styling. Please choose dark based color.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_secondary_color_scheme_revive_charity',
            'type'            => 'color',
            'default'         => '#f8b016',
            'active_callback' => 'benevonet_pro_child_ac',
        ),
        array(
            'label'    => __( 'Background Color', 'benevolent-pro' ),
            'tooltip'  => __( 'Pick a color for site background.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_styling_settings',
            'settings' => 'benevolent_pro_bg_color',
            'type'     => 'color',
            'default'  => '#ffffff',
        ),
        array(    
            'settings' => 'benevolent_pro_body_color',
            'label'    => __( 'Body Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_typography_body_section',
            'type'     => 'color',
            'default'  => '#777777',
        ),
        array(    
            'settings' => 'benevolent_pro_page_title_color',
            'label'    => __( 'Page Title Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_page_title_setting',
            'type'     => 'color',
            'default'  => '#000000',
        ),
        array(    
            'settings' => 'benevolent_pro_post_title_color',
            'label'    => __( 'Post Title Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_title_setting',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h1_color',
            'label'    => __( 'H1 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h1_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h2_color',
            'label'    => __( 'H2 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h2_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h3_color',
            'label'    => __( 'H3 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h3_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h4_color',
            'label'    => __( 'H4 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h4_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h5_color',
            'label'    => __( 'H5 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h5_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        array(    
            'settings' => 'benevolent_pro_h6_color',
            'label'    => __( 'H6 Color', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h6_section',
            'type'     => 'color',
            'default'  => '#121212',
        ),
        
    );

    foreach( $colors as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );
        
        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new WP_Customize_Color_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_color' );
<?php
/**
 * Slider Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_slider( $wp_customize ){

    $sliders = array(
        array(
            'type'     => 'slider',
            'settings' => 'benevolent_pro_slider_speed',
            'label'    => __( 'Slider Speed', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => 400,
            'choices'  => array(
                'min'  => 100,
                'max'  => 1000,
                'step' => 100
            ),
            'priority' => 15
        ),
        array(
            'type'     => 'slider',
            'settings' => 'benevolent_pro_slider_pause',
            'label'    => __( 'Slider Pause', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => 6000,
            'choices'  => array(
                'min'  => 1000,
                'max'  => 10000,
                'step' => 500
            ),
            'priority' => 15
        ),
        array(
            'type'     => 'slider',
            'settings' => 'benevolent_pro_give_excerpt_words',
            'label'    => __( 'Excerpt Words', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_give_settings',
            'default'  => 25,
            'choices'  => array(
                'min'  => 5,
                'max'  => 50,
                'step' => 2
            ),
            'active_callback' => 'is_give_activated'
        ),
        array(
            'label'    => __( 'Post Excerpt Words', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_meta_settings',
            'settings' => 'benevolent_pro_post_excerpt_words',
            'type'     => 'slider',
            'default'  => 30,
            'choices'  => array(
                'min'  => 10,
                'max'  => 100,
                'step' => 2
            ),
        ),
        array(    
            'settings' => 'benevolent_pro_body_font_size',
            'label'    => __( 'Body Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_typography_body_section',
            'default'  => '18',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 35,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_body_line_height',
            'label'    => __( 'Body Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_typography_body_section',
            'default'  => '28',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 15,
                            'max'  => 50,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_hps_title_font_size',
            'label'    => __( 'Home Page Section Title Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_hps_title_section',
            'default'  => '40',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 60,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_hps_title_line_height',
            'label'    => __( 'Home Page Section Title Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_hps_title_section',
            'default'  => '48',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 70,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_page_title_font_size',
            'label'    => __( 'Page Title Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_page_title_setting',
            'default'  => '38',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 60,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_page_title_line_height',
            'label'    => __( 'Page Title Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_page_title_setting',
            'default'  => '48',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 25,
                            'max'  => 70,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_post_title_font_size',
            'label'    => __( 'Post Title Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_title_setting',
            'default'  => '30',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 15,
                            'max'  => 60,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_post_title_line_height',
            'label'    => __( 'Post Title Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_title_setting',
            'default'  => '36',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 70,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h1_font_size',
            'label'    => __( 'H1 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h1_section',
            'default'  => '48',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 25,
                            'max'  => 70,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h1_line_height',
            'label'    => __( 'H1 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h1_section',
            'default'  => '57',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 30,
                            'max'  => 80,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h2_font_size',
            'label'    => __( 'H2 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h2_section',
            'default'  => '40',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 60,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h2_line_height',
            'label'    => __( 'H2 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h2_section',
            'default'  => '48',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 30,
                            'max'  => 70,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h3_font_size',
            'label'    => __( 'H3 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h3_section',
            'default'  => '30',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 15,
                            'max'  => 50,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h3_line_height',
            'label'    => __( 'H3 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h3_section',
            'default'  => '36',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 60,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h4_font_size',
            'label'    => __( 'H4 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h4_section',
            'default'  => '24',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 30,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h4_line_height',
            'label'    => __( 'H4 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h4_section',
            'default'  => '28',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 15,
                            'max'  => 40,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h5_font_size',
            'label'    => __( 'H5 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h5_section',
            'default'  => '20',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 30,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h5_line_height',
            'label'    => __( 'H5 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h5_section',
            'default'  => '24',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 35,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h6_font_size',
            'label'    => __( 'H6 Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h6_section',
            'default'  => '18',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 30,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_h6_line_height',
            'label'    => __( 'H6 Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_h6_section',
            'default'  => '22',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 35,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_widget_title_font_size',
            'label'    => __( 'Widget Title Font Size', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_widget_title_section',
            'default'  => '20',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 10,
                            'max'  => 35,
                            'step' => 1,
                        )
        ),
        array(    
            'settings' => 'benevolent_pro_widget_title_line_height',
            'label'    => __( 'Widget Title Line Height', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_widget_title_section',
            'default'  => '35',
            'type'     => 'slider',
            'choices'  => array(
                            'min'  => 20,
                            'max'  => 60,
                            'step' => 1,
                        )
        )
    );

    foreach( $sliders as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_number_absint',
            )
        );
        
        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new Benevolent_Pro_Slider_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_slider' );
<?php
/**
 * Customizer Sections
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_sections( $wp_customize ){

    $sections = array(
        'benevolent_pro_custom_settings' => array(
            'title'    => __( 'Custom Script', 'benevolent-pro' ),
            'priority' => 10,
            'panel'    => 'benevolent_pro_custom_code_panel',
        ),
        'google_analytics_settings' => array(
            'title'    => __( 'Google Analytics Settings', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_custom_code_panel',
        ),
        'benevolent_pro_about_believe_section' => array(
            'title'    => __( 'We Believe Section', 'benevolent-pro' ),
            'priority' => 60,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_about_current_project_section' => array(
            'title'    => __( 'Current Project Section', 'benevolent-pro' ),
            'priority' => 70,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_about_intro_section' => array(
            'title'    => __( 'Intro Section', 'benevolent-pro' ),
            'priority' => 20,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_profile_section' => array(
            'title'    => __( 'Profile Section', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_sort_about_section' => array(
            'title'    => __( 'Sort About Page Sections', 'benevolent-pro' ),
            'priority' => 80,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_about_stat_counter_section' => array(
            'title'    => __( 'Stat Counter Section', 'benevolent-pro' ),
            'priority' => 50,
            'panel'    => 'benevolent_pro_about_page_settings',
        ),
        'benevolent_pro_header_layout_setting' => array(
            'title'    => __( 'Layout Settings', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_header_setting',
        ),
        'benevolent_pro_header_misc_setting' => array(
            'title'    => __( 'Misc Settings', 'benevolent-pro' ),
            'priority' => 40,
            'panel'    => 'benevolent_pro_header_setting',
        ),
        'benevolent_pro_blog_settings' => array(
            'title'    => __( 'Blog Section', 'benevolent-pro' ),
            'priority' => 50,
            'panel'    => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_community_settings' => array(
            'title'    => __( 'Community Section', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_give_settings' => array(
            'title'           => __( 'Give Section', 'benevolent-pro' ),
            'priority'        => 45,
            'panel'           => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_intro_settings' => array(
            'title'    => __( 'Intro Section', 'benevolent-pro' ),
            'priority' => 20,
            'panel'    => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_sort_home_section' => array(
            'title'    => __( 'Sort Home Page Sections', 'benevolent-pro' ),
            'priority' => 80,
            'panel'    => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_sponsor_settings' => array(
            'title'    => __( 'Sponsor Section', 'benevolent-pro' ),
            'priority' => 60,
            'panel'    => 'benevolent_pro_home_page_settings',
        ),
        'benevolent_pro_service_donor_section' => array(
            'title'    => __( 'Donor Section', 'benevolent-pro' ),
            'priority' => 60,
            'panel'    => 'benevolent_pro_service_page_settings',
        ),
        'benevolent_pro_service_intro_section' => array(
            'title'    => __( 'Intro Section', 'benevolent-pro' ),
            'priority' => 20,
            'panel'    => 'benevolent_pro_service_page_settings',
        ),
        'benevolent_pro_service_services_section' => array(
            'title'    => __( 'Services Section', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_service_page_settings',
        ),
        'benevolent_pro_sort_service_section' => array(
            'title'    => __( 'Sort Service Page Sections', 'benevolent-pro' ),
            'priority' => 70,
            'panel'    => 'benevolent_pro_service_page_settings',
        ),
        'benevolent_pro_slider_contents' => array(
            'title'    => __( 'Slider Contents', 'benevolent-pro' ),
            'priority' => 30,
            'panel'    => 'benevolent_pro_slider_settings',
        ),
        'benevolent_pro_slider_options' => array(
            'title'    => __( 'Slider Options', 'benevolent-pro' ),
            'priority' => 20,
            'panel'    => 'benevolent_pro_slider_settings',
        ),
        'benevolent_pro_typography_body_section' => array(
            'title'      => __( 'Body Settings', 'benevolent-pro' ),
            'priority'   => 10,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h1_section' => array(
            'title'      => __( 'H1 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 23,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h2_section' => array(
            'title'      => __( 'H2 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 24,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h3_section' => array(
            'title'      => __( 'H3 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 25,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h4_section' => array(
            'title'      => __( 'H4 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 26,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h5_section' => array(
            'title'      => __( 'H5 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 27,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_h6_section' => array(
            'title'      => __( 'H6 Settings (Content)', 'benevolent-pro' ),
            'priority'   => 28,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_hps_title_section' => array(
            'title'      => __( 'Home Page Section Title Settings', 'benevolent-pro' ),
            'priority'   => 11,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_page_title_setting' => array(
            'title'      => __( 'Page Template Title Settings', 'benevolent-pro' ),
            'priority'   => 15,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_post_title_setting' => array(
            'title'      => __( 'Post Title Settings', 'benevolent-pro' ),
            'priority'   => 16,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_widget_title_section' => array(
            'title'      => __( 'Widget Title Settings', 'benevolent-pro' ),
            'priority'   => 29,
            'capability' => 'edit_theme_options',
            'panel'      => 'benevolent_pro_typography_section'
        ),
        'benevolent_pro_blog_page_settings' => array(
            'priority'   => 27,
            'capability' => 'edit_theme_options',
            'title'      => __( 'Blog Page Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_breadcrumb_settings' => array(
            'priority'   => 31,
            'capability' => 'edit_theme_options',
            'title'      => __( 'BreadCrumb Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_elementor_settings' => array(
            'title'      => __( 'Elementor Settings', 'benevolent-pro' ),
            'priority'   => 75,
            'capability' => 'edit_theme_options',
        ),
        'benevolent_pro_footer_settings' => array(
            'title'      => __( 'Footer Settings', 'benevolent-pro' ),
            'priority'   => 122,
            'capability' => 'edit_theme_options',
        ),
        'benevolent_pro_general_settings' => array(
            'priority'   => 22,
            'capability' => 'edit_theme_options',
            'title'      => __( 'General Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_google_map_section' => array(
            'title'       => __( 'Google Map Settings', 'benevolent-pro' ),
            'description' => __( 'Google Map can be displayed in the contact page. Make sure you have created a page with Contact Form template for the map to be displayed in it.', 'benevolent-pro' ),
            'priority'    => 30,
            'capability'  => 'edit_theme_options',
        ),
        'theme_info' => array(
            'title'    => __( 'Information Links' , 'benevolent-pro' ),
            'priority' => 5,
		),
        'benevolent_pro_performance_settings' => array(
            'title'      => __( 'Performance Settings', 'benevolent-pro' ),
            'priority'   => 70,
            'capability' => 'edit_theme_options',
        ),
        'benevolent_pro_post_meta_settings' => array(
            'title'      => __( 'Post Meta Settings', 'benevolent-pro' ),
            'priority'   => 29,
            'capability' => 'edit_theme_options',
        ),
        'benevolent_pro_post_page_settings' => array(
            'priority'   => 28,
            'capability' => 'edit_theme_options',
            'title'      => __( 'Post Page Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_sidebar_settings' => array(
            'title'       => __( 'Sidebar Settings', 'benevolent-pro' ),
            'priority'    => 34,
            'capability'  => 'edit_theme_options',
            'description' => __( 'Add custom sidebars. You need to save the changes and reload the customizer to use the sidebars in the dropdowns below. You can add content to the sidebars in Appearance / Widgets.', 'benevolent-pro' ),
        ),
        'benevolent_pro_social_settings' => array(
            'title'      => __( 'Social Settings', 'benevolent-pro' ),
            'priority'   => 35,
            'capability' => 'edit_theme_options',
        ),
        'benevolent_pro_styling_settings' => array(
            'priority'   => 32,
            'capability' => 'edit_theme_options',
            'title'      => __( 'Styling Settings', 'benevolent-pro' ),
        ),
    );

    foreach( $sections as $key => $val ){
        $array = array(
            'title'      => $val['title'],
            'priority'   => $val['priority'],
            'capability' => 'edit_theme_options',
        );
        
        if( isset( $val['panel'] ) && $val['panel'] ) $array['panel']                   = $val['panel'];
        if( isset( $val['description'] ) && $val['description'] ) $array['description'] = $val['description'];

        $wp_customize->add_section( $key, $array );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_sections' );
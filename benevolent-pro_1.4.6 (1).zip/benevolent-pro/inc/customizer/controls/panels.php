<?php
/**
 * Customizer Panels
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_panels( $wp_customize ){

    $panels = array(
        'benevolent_pro_header_setting' => array(
            'title'    => __( 'Header Settings', 'benevolent-pro' ),
            'priority' => 21,
        ),
        'benevolent_pro_slider_settings' => array(
            'title'    => __( 'Slider Settings', 'benevolent-pro' ),
            'priority' => 23,
        ),
        'benevolent_pro_home_page_settings' => array(
            'priority'    => 24,
            'title'       => __( 'Home Page Settings', 'benevolent-pro' ),
            'description' => __( 'Customize Home Page Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_about_page_settings' => array(
            'priority'    => 25,
            'title'       => __( 'About Page Settings', 'benevolent-pro' ),
            'description' => __( 'Customize About Page Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_service_page_settings' => array(
            'priority'    => 26,
            'title'       => __( 'Service Page Settings', 'benevolent-pro' ),
            'description' => __( 'Customize Service Page Settings', 'benevolent-pro' ),
        ),
        'benevolent_pro_typography_section' => array(
            'title'    => __( 'Typography Settings', 'benevolent-pro' ),
            'priority' => 33,
        ),
        'benevolent_pro_custom_code_panel' => array(
            'title'    => __( 'Custom Codes', 'benevolent-pro' ),
            'priority' => 121,
        ),
    );

    foreach( $panels as $key => $val ){
        $wp_customize->add_panel(
            $key,
            array(
                'title'      => $val['title'],
                'priority'   => $val['priority'],
                'capability' => 'edit_theme_options',
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_panels' );
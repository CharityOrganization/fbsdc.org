<?php
/**
 * Toggle Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_toggle( $wp_customize ){
    $toggles = array(
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_sticky_header',
            'label'    => __( 'Enable Sticky Header', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to make header sticky.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_misc_setting',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_search_form',
            'label'    => __( 'Enable Search Form', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to show search form in header.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_misc_setting',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_donate_button',
            'label'    => __( 'Enable Donate Button', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to show donate button link.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_misc_setting',
            'default'  => '',
        ),
        array(
            'type'            => 'toggle',
            'settings'        => 'benevolent_pro_ed_donate_form',
            'label'           => __( 'Use Donate Form', 'benevolent-pro' ),
            'tooltip'         => __( 'Use Donate form instead of custom donate link.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_header_misc_setting',
            'default'         => '',
            'active_callback' => 'benevolent_pro_donate_button_ac',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_donate_btn_outside_menu',
            'label'    => __( 'Separate Donate Button in Mobile Menu', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to display Donate button link outside of mobile menu just like in free version.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_misc_setting',
            'default'  => '',
            'priority' => 20
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_donate_in_new_tab',
            'label'    => __( 'Open Donate Button in New Tab', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to open Donate button in new tab.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_misc_setting',
            'default'  => '',
            'priority' => 20
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_adminbar',
            'label'    => __( 'Disable Admin Bar', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to disable Admin Bar in frontend when logged in.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_lightbox',
            'label'    => __( 'Enable Lightbox', 'benevolent-pro' ),
            'tooltip'  => __( 'A lightbox is a stylized pop-up that allows your visitors to view larger versions of images without leaving the current page. You can enable or disable the lightbox here.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_ajax_search',
            'label'    => __( 'Enable Ajax Quick Search', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to display search results appearing instantly below the search form.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'default'  => '',
        ),
        array(
            'type'            => 'toggle',
            'settings'        => 'ed_shop_archive_description',
            'label'           => __( 'Shop Page Description', 'benevolent-pro' ),
            'tooltip'         => __( 'Enable to show Shop Page Description.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_general_settings',
            'default'         => '',
            'active_callback' => 'benevolent_pro_shop_description_ac',
            'priority'        => 20
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_slider',
            'label'    => __( 'Enable Home Page Slider', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_slider_auto',
            'label'    => __( 'Enable Slider Auto Transition', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_slider_loop',
            'label'    => __( 'Enable Slider Loop', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_slider_pager',
            'label'    => __( 'Enable Slider Pager', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_slider_caption',
            'label'    => __( 'Enable Slider Caption', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_slider_full_image',
            'label'    => __( 'Use Full Size Image', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_options',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_intro_new_tab',
            'label'    => __( 'Open in new tab', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to open link in new tab.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '1',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_blog_date',
            'label'    => __( 'Show Blog Date', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_blog_settings',
            'default'  => '',
        ),
        array(
            'type'     => 'toggle',
            'settings' => 'benevolent_pro_ed_sponsor_loop',
            'label'    => __( 'Enable Slider Loop', 'benevolent-pro' ),
            'tooltip'  => __( 'Enable to loop through the items', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_sponsor_settings',
            'default'  => '1',
        ),
        array(
            'label'           => __( 'Blog Post Image Crop', 'benevolent-pro' ),
            'tooltip'         => __( 'Enable to avoid automatic cropping of featured image in homepage blog section and archive page', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_blog_page_settings',
            'settings'        => 'ed_crop_archive_page_image',
            'type'            => 'toggle',
            'default'         => '',
            'active_callback' => 'benevolent_pro_blog_ac'
        ),
        array(
            'label'    => __( 'Show Featured Image', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_page_settings',
            'settings' => 'benevolent_pro_ed_featured_image',
            'type'     => 'toggle',
            'default'  => '1',
        ),
        array(
            'label'           => __( 'Single Post Image Crop', 'benevolent-pro' ),
            'tooltip'         => __( 'Enable to avoid automatic cropping of featured image in single post', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_post_page_settings',
            'settings'        => 'ed_crop_single_post_image',
            'active_callback' => 'benevolent_pro_post_page_ac',
            'type'            => 'toggle',
            'default'         => '',
        ),
        array(
            'label'    => __( 'Show Comments', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_page_settings',
            'settings' => 'benevolent_pro_ed_comments',
            'type'     => 'toggle',
            'default'  => '1',
        ),
        array(
            'label'    => __( 'Highlight Author Comment', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_page_settings',
            'settings' => 'benevolent_pro_ed_auth_comments',
            'type'     => 'toggle',
            'default'  => '',
        ),
        array(
            'label'    => __( 'Hide Prefix in Archive Page', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_post_page_settings',
            'settings' => 'benevolent_pro_ed_prefix_archive',
            'type'     => 'toggle',
            'default'  => '',
        ),
        array(
            'settings' => 'benevolent_pro_ed_google_map',
            'label'    => __( 'Enable/Disable Google map', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_google_map_section',
            'type'     => 'toggle',
            'default'  => '',
            'priority' => 5
        ),
        array(
            'settings'        => 'benevolent_pro_ed_map_scroll',
            'label'           => __( 'Enable/Disable Scrolling Wheel', 'benevolent-pro' ),
            'tooltip'         => __( 'Zoom map on Scrolling', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_google_map_section',
            'type'            => 'toggle',
            'default'         => '1',
            'active_callback' => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'        => 'benevolent_pro_ed_map_controls',
            'label'           => __( 'Enable/Disable Map Controls', 'benevolent-pro' ),
            'tooltip'         => __( 'Controls icons that appears above Map', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_google_map_section',
            'type'            => 'toggle',
            'default'         => '1',
            'active_callback' => 'benevolent_pro_google_map_ac',
        ),
        array(
            'settings'        => 'benevolent_pro_ed_map_marker',
            'label'           => __( 'Enable/Disable Map Marker', 'benevolent-pro' ),
            'tooltip'         => __( 'Marker icons that appears above Map', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_google_map_section',
            'type'            => 'toggle',
            'default'         => '',
            'active_callback' => 'benevolent_pro_google_map_ac',
        ),
        array(
            'label'    => __( 'Enable Breadcrumb', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_breadcrumb_settings',
            'settings' => 'benevolent_pro_ed_breadcrumb',
            'type'     => 'toggle',
            'default'  => '',
        ),
        array(
            'label'    => __( 'Show Current', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_breadcrumb_settings',
            'settings' => 'benevolent_pro_ed_current',
            'type'     => 'toggle',
            'default'  => '1',
        ),
        array(
            'type'        => 'toggle',
            'settings'    => 'benevolent_pro_ed_social_header',
            'label'       => __( 'Enable Social Links in Header', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_social_settings',
            'default'     => '',
            'priority'    => 10
        ),
        array(
            'label'     => __( 'Lazy Load', 'benevolent-pro' ),
            'description'   => __( 'Enable lazy loading of featured images.', 'benevolent-pro' ),
            'section'   => 'benevolent_pro_performance_settings',
            'settings'  => 'ed_lazy_load',
            'type'      => 'toggle',
            'default'   => '',
        ),
        array(
            'label'     => __( 'Lazy Load Content Images', 'benevolent-pro' ),
            'description'   => __( 'Enable lazy loading of images inside page/post content.', 'benevolent-pro' ),
            'section'   => 'benevolent_pro_performance_settings',
            'settings'  => 'ed_lazy_load_cimage',
            'type'      => 'toggle',
            'default'   => '',
        ),
        array(
            'label'     => __( 'Defer JavaScript', 'benevolent-pro' ),
            'description'   => __( 'Adds "defer" attribute to sript tags to improve page download speed.', 'benevolent-pro' ),
            'section'   => 'benevolent_pro_performance_settings',
            'settings'  => 'ed_defer',
            'type'      => 'toggle',
            'default'   => '',
        ),
        array(
            'label'     => __( 'Remove ver parameters', 'benevolent-pro' ),
            'description'   => __( 'Enable to remove "ver" parameter from CSS and JS file calls.', 'benevolent-pro' ),
            'section'   => 'benevolent_pro_performance_settings',
            'settings'  => 'ed_ver',
            'type'      => 'toggle',
            'default'   => '',
        ),
        array(
            'label'       => __( 'Locally Host Google Fonts', 'benevolent-pro' ),
            'description' => sprintf( __( 'Enable to load google fonts from your own server instead from google\'s CDN. This solves privacy concerns with Google\'s CDN and their sometimes less-than-transparent policies. %1$sBack to Typgraphy%2$s', 'benevolent-pro' ), '<span class="text-inner-link ed_googlefont_local">', '</span>' ),
            'section'     => 'benevolent_pro_performance_settings',
            'settings'    => 'ed_googlefont_local',
            'type'        => 'toggle',
            'default'     => '',
        ),
        array(
            'label'           => __( 'Enable Elementor Page Builder in FrontPage', 'benevolent-pro' ),
            'description'     => __( 'You can override your Homepage Contents from this Elementor Page Builder', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_elementor_settings',
            'settings'        => 'ed_elementor',
            'type'            => 'toggle',
            'active_callback' => 'benevolent_pro_is_elementor_activated',
            'default'         => '',
        ),
        array(
            'type'        => 'toggle',
            'settings'    => 'benevolent_pro_ed_author_link',
            'label'       => __( 'Hide Author Link', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_footer_settings',
            'default'     => '',
        ),
        array(
            'type'        => 'toggle',
            'settings'    => 'benevolent_pro_ed_wp_link',
            'label'       => __( 'Hide WordPress Link', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_footer_settings',
            'default'     => '',
        )
    );

    foreach( $toggles as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_checkbox',
            )
        );

        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control(
            new Benevolent_Pro_Toggle_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_toggle' );
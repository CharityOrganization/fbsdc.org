<?php
/**
 * Repeater Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_repeater( $wp_customize ){

    $repeaters = array(
        array(
            'type'     => 'repeater',
            'settings' => 'benevolent_pro_slider_slides',
            'label'    => __( 'Add Sliders', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_slider_contents',
            'default'  => '',
            'fields'   => array(
                'thumbnail' => array(
                    'type'  => 'image',
                    'label' => __( 'Add Image', 'benevolent-pro' ),
                ),
                'title'     => array(
                    'type'  => 'text',
                    'label' => __( 'Title', 'benevolent-pro' ),
                ),
                'content'   => array(
                    'type'  => 'textarea',
                    'label' => __( 'Content', 'benevolent-pro' ),
                ),
                'link'     => array(
                    'type'  => 'text',
                    'label' => __( 'Link', 'benevolent-pro' ),
                    
                )
            ),
            'active_callback' => 'benevolent_pro_banner_ac',
            'row_label'       => array(
                'type'  => 'field',
                'value' => __( 'slides', 'benevolent-pro' ),
                'field' => 'title',
            ),  
        ),
        array(
            'type'        => 'repeater',
            'settings'    => 'benevolent_pro_sidebar',
            'label'       => __( 'Add Sidebars', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_sidebar_settings',
            'default'     => '',
            'fields'     => array(
                'name'     => array(
                    'type'  => 'text',
                    'label' => __( 'Name', 'benevolent-pro' ),
                    'description'  => __( 'Example: Homepage Sidebar', 'benevolent-pro' ),
                ),
                'id'     => array(
                    'type'  => 'text',
                    'label' => __( 'ID', 'benevolent-pro' ),
                    'description'  => __( 'Enter a unique ID for the sidebar. Use only alphanumeric characters, underscores (_) and dashes (-), eg. "sidebar-home"', 'benevolent-pro' ),
                )
            ),
            'row_label' => array(
                'type' => 'field',
                'value' => __( 'sidebar', 'benevolent-pro' ),
                'field' => 'name'
            ),
            'priority' => 5
        ),
        array(
            'type'        => 'repeater',
            'settings'    => 'benevolent_pro_social',
            'label'       => __( 'Add Social Links', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_social_settings',
            'priority'    => 30,
            'default'     => array(
                array(
                    'icon' => 'facebook',
                    'link' => 'https://facebook.com',
                ),
                array(
                    'icon' => 'twitter',
                    'link' => 'https://twitter.com',
                ),
            ),
            'fields'     => array(
                'icon'     => array(
                    'type'     => 'select',
                    'label'    => __( 'Social Icon', 'benevolent-pro' ),
                    'choices'  => benevolent_pro_social_icons(),
                    'default'  => 'dribbble'
                ),
                'link'     => array(
                    'type'  => 'url',
                    'label' => __( 'Link', 'benevolent-pro' ),
                    'description'  => __( 'Leave blank if you do not want to show.', 'benevolent-pro' ),
                )
            ),
            'row_label' => array(
                'type' => 'field',
                'value' => __( 'link', 'benevolent-pro' ),
                'field' => 'icon'
            ),               
        )
    );

    foreach( $repeaters as $val ){
        $wp_customize->add_setting( 
            new Benevolent_Pro_Repeater_Setting( 
                $wp_customize, 
                $val['settings'],
                array(
                    'default'           => $val['default'],
                    'sanitize_callback' => array( 'Benevolent_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),
                ) 
            ) 
        );
        
        $array = array(
            'section'   => $val['section'],
            'label'     => $val['label'],
            'fields'    => $val['fields'],
            'row_label' => $val['row_label'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        if( isset( $val['choices' ] ) && $val['choices'] ) $array['choices']                         = $val['choices'];

        $wp_customize->add_control(
            new Benevolent_Pro_Control_Repeater( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_repeater' );
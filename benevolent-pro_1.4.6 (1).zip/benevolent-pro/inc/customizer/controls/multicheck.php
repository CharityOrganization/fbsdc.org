<?php
/**
 * Multicheck Control
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_multicheck( $wp_customize ) {
	
    $wp_customize->add_setting(
        'benevolent_pro_exclude_categories',
        array(
            'default'           => '',
            'sanitize_callback' => 'benevolent_pro_sanitize_multiple_check',
        )
    );

    $wp_customize->add_control(
        new Benevolent_Pro_MultiCheck_Control( 
            $wp_customize,
            'benevolent_pro_exclude_categories',
            array(
                'label'       => __( 'Exclude Categories', 'benevolent-pro' ),
                'description' => __( 'Check multiple categories to exclude from blog and archive page.', 'benevolent-pro' ),
                'section'     => 'benevolent_pro_blog_page_settings',
                'choices'     => benevolent_pro_get_categories( false ),
            )
        )
    );

}
add_action( 'customize_register', 'benevolent_pro_customize_register_multicheck' );
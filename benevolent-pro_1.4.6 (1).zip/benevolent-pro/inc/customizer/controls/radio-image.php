<?php
/**
 * Radio Image Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_radio_image( $wp_customize ){
    $radio_images = array(
        array(
            'label'    => __( 'Header Layout', 'benevolent-pro' ),
            'tooltip'  => __( 'Choose the layout of header for your site.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_header_layout_setting',
            'settings' => 'benevolent_pro_header_layout',
            'type'     => 'radio-image',
            'default'  => 'one',
            'choices'  => array(
                'one'   => get_template_directory_uri() . '/images/header-1.jpg',
                'two'   => get_template_directory_uri() . '/images/header-2.jpg',
                'three' => get_template_directory_uri() . '/images/header-3.jpg',
                'four'  => get_template_directory_uri() . '/images/header-4.jpg',
                'five'  => get_template_directory_uri() . '/images/header-5.jpg',
            )
        ),
        array(
            'label'    => __( 'Layout Style', 'benevolent-pro' ),
            'tooltip'  => __( 'Choose the default sidebar position for your site. The position of the sidebar for individual posts can be set in the post editor.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_styling_settings',
            'settings' => 'benevolent_pro_layout_style',
            'type'     => 'radio-image',
            'default'  => 'right-sidebar',
            'choices'  => array(
                'left-sidebar'  => get_template_directory_uri() . '/images/left-sidebar.png',
                'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
            )
        ),
        array(
            'label'           => __( 'Background Pattern', 'benevolent-pro' ),
            'tooltip'         => __( 'Choose from any of 63 awesome background patterns for your site background.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_bg_pattern',
            'type'            => 'radio-image',
            'default'         => 'nobg',
            'choices'         => benevolent_pro_get_patterns(),
            'active_callback' => 'benevolent_pro_body_bg_choice',
            'priority'        => 20
        )
    );

    foreach( $radio_images as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_radio',
            )
        );

        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control(
            new Benevolent_Pro_Radio_Image_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_radio_image' );
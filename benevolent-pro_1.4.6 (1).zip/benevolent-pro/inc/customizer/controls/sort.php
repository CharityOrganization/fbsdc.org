<?php
/**
 * Sort Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_sort( $wp_customize ){
    
    $sorts = array(
        array(
            'type'        => 'sortable',
            'settings'    => 'benevolent_pro_sort_homepage',
            'label'       => __( 'Sort Sections', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_sort_home_section',
            'default'     => array( 'intro', 'community', 'stat', 'give', 'blog', 'sponsor', 'cta' ),
            'choices'     => array(
                'intro'       => __( 'Intro Section', 'benevolent-pro' ),
                'community'   => __( 'Community Section', 'benevolent-pro' ),
                'stat'        => __( 'Stat Counter Section', 'benevolent-pro' ),
                'give'        => __( 'Give Section', 'benevolent-pro' ),
                'blog'        => __( 'Blog Section', 'benevolent-pro' ),
                'sponsor'     => __( 'Sponsor Section', 'benevolent-pro' ),
                'cta'         => __( 'CTA Section', 'benevolent-pro' ),
            ),        
        ),
        array(
            'type'        => 'sortable',
            'settings'    => 'benevolent_pro_sort_aboutpage',
            'label'       => __( 'Sort Sections', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_sort_about_section',
            'default'     => array( 'intro', 'profile', 'stat', 'believe', 'current' ),
            'choices'     => array(
                'intro'   => esc_attr__( 'Intro Section', 'benevolent-pro' ),
                'profile' => esc_attr__( 'Profile Section', 'benevolent-pro' ),
                'stat'    => esc_attr__( 'Stat Counter Section', 'benevolent-pro' ),
                'believe' => esc_attr__( 'We Believe Section', 'benevolent-pro' ),
                'current' => esc_attr__( 'Current Project Section', 'benevolent-pro' ),
            ),        
        ),
        array(
            'type'        => 'sortable',
            'settings'    => 'benevolent_pro_sort_servicepage',
            'label'       => __( 'Sort Sections', 'benevolent-pro' ),
            'section'     => 'benevolent_pro_sort_service_section',
            'default'     => array( 'intro', 'services', 'cta', 'donor' ),
            'choices'     => array(
                'intro'    => esc_attr__( 'Intro Section', 'benevolent-pro' ),
                'services' => esc_attr__( 'Services Section', 'benevolent-pro' ),
                'cta'      => esc_attr__( 'CTA Section', 'benevolent-pro' ),
                'donor'    => esc_attr__( 'Donor Section', 'benevolent-pro' ),
            ),        
        )
    );

    foreach( $sorts as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_sortable',
            )
        );
        
        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];

        $wp_customize->add_control(
            new Benevolent_Pro_Sortable_Control( 
                $wp_customize,
                $val['settings'],
                $array
            )
        );
    }    
}
add_action( 'customize_register', 'benevolent_pro_customize_register_sort' );
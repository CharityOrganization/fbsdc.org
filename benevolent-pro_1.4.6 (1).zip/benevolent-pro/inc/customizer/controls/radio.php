<?php
/**
 * Radio Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_radio( $wp_customize ){
    $radio_images = array(
        array(
            'type'     => 'radio',
            'settings' => 'benevolent_pro_pagination_type',
            'label'    => __( 'Pagination Type', 'benevolent-pro' ),
            'tooltip'  => __( 'Select pagination type.', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_general_settings',
            'default'  => 'default',
            'choices'  => array(
                'default'         => __( 'Default (Next / Previous)', 'benevolent-pro' ),
                'numbered'        => __( 'Numbered (1 2 3 4...)', 'benevolent-pro' ),
                'load_more'       => __( 'AJAX (Load More Button)', 'benevolent-pro' ),
                'infinite_scroll' => __( 'AJAX (Auto Infinite Scroll)', 'benevolent-pro' ),
            )  
        ),
        array(
            'settings' => 'benevolent_pro_blog_layout',
            'label'    => __( 'Blog Page Layout', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_blog_page_settings',
            'type'     => 'radio',
            'default'  => 'default',
            'choices'  => array(
                'default' => __( 'Default', 'benevolent-pro' ),
                'square'  => __( 'Square Image', 'benevolent-pro' ),
                'round'   => __( 'Round Image', 'benevolent-pro' ),
            ),
            'priority' => 5
        )
    );

    foreach( $radio_images as $val ){
        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => 'benevolent_pro_sanitize_radio',
            )
        );

        $array = array(
            'type'    => 'radio',
            'section' => $val['section'],
            'label'   => $val['label'],
            'choices' => $val['choices'],
        );

        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        $wp_customize->add_control( $val['settings'], $array );
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_radio' );
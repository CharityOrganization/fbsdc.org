<?php
/**
 * Image Controls
 *
 * @package Benevolent_Pro
 */

function benevolent_pro_customize_register_image( $wp_customize ){
    $images = array(
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_one_logo',
            'label'    => __( 'Upload a Logo One', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 85,
            'height'   => 85,
            'priority' => 15
        ),
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_one_image',
            'label'    => __( 'Upload a Image One', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 200,
            'height'   => 200,
            'priority' => 15
        ),
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_two_logo',
            'label'    => __( 'Upload a Logo Two', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 85,
            'height'   => 85,
            'priority' => 20
        ),
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_two_image',
            'label'    => __( 'Upload a Image Two', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 200,
            'height'   => 200,
            'priority' => 20
        ),
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_three_logo',
            'label'    => __( 'Upload a Logo Three', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 85,
            'height'   => 85,
            'priority' => 25
        ),
        array(
            'type'     => 'cropped_image',
            'settings' => 'benevolent_pro_intro_three_image',
            'label'    => __( 'Upload a Image Three', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => '',
            'width'    => 200,
            'height'   => 200,
            'priority' => 35
        ),
        array(
            'type'     => 'image',
            'settings' => 'benevolent_pro_intro_bg',
            'label'    => __( 'Background Image', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_intro_settings',
            'default'  => get_template_directory_uri() . '/images/map.jpg',
        ),
        array(
            'type'     => 'image',
            'settings' => 'benevolent_pro_about_stat_counter_bg',
            'label'    => __( 'Background Image', 'benevolent-pro' ),
            'section'  => 'benevolent_pro_about_stat_counter_section',
            'default'  => '',
        ),
        array(
            'label'           => __( 'Background Image', 'benevolent-pro' ),
            'tooltip'         => __( 'Upload your own custom background image or pattern.', 'benevolent-pro' ),
            'section'         => 'benevolent_pro_styling_settings',
            'settings'        => 'benevolent_pro_bg_image',
            'type'            => 'image',
            'default'         => '',
            'active_callback' => 'benevolent_pro_body_bg_choice',
            'priority'        => 20
        )
    );

    foreach( $images as $val ){
        
        $sanitize_callback = ( isset( $val['type' ] ) && $val['type'] == 'image' ) ? 'benevolent_pro_sanitize_image' : 'benevolent_pro_sanitize_number_absint';

        $wp_customize->add_setting(
            $val['settings'],
            array(
                'default'           => $val['default'],
                'sanitize_callback' => $sanitize_callback,
            )
        );

        $array = array(
            'section' => $val['section'],
            'label'   => $val['label'],
        );

        if( isset( $val['width' ] ) && $val['width'] ) $array['width']                               = $val['width'];
        if( isset( $val['height' ] ) && $val['height'] ) $array['height']                            = $val['height'];
        if( isset( $val['description' ] ) && $val['description'] ) $array['description']             = $val['description'];
        if( isset( $val['tooltip' ] ) && $val['tooltip'] ) $array['description']                     = $val['tooltip'];
        if( isset( $val['priority' ] ) && $val['priority'] ) $array['priority']                      = $val['priority'];
        if( isset( $val['active_callback' ] ) && $val['active_callback'] ) $array['active_callback'] = $val['active_callback'];
        
        if( isset( $val['type' ] ) && $val['type'] == 'image' ){
            $wp_customize->add_control(
                new WP_Customize_Image_Control( 
                    $wp_customize,
                    $val['settings'],
                    $array
                )
            );
        }else{
            $wp_customize->add_control(
                new WP_Customize_Cropped_Image_Control( 
                    $wp_customize,
                    $val['settings'],
                    $array
                )
            );
        }
    }
}
add_action( 'customize_register', 'benevolent_pro_customize_register_image' );
<?php
/**
 * Active Callback
 * 
 * @package Benevolent_Pro
*/

function benevolent_pro_donate_button_ac( $control ){
    $ed_donate_button = $control->manager->get_setting( 'benevolent_pro_ed_donate_button' )->value();
    $ed_donate_form = $control->manager->get_setting( 'benevolent_pro_ed_donate_form' )->value();
    $control_id = $control->id;
    
    if( $control_id == 'benevolent_pro_ed_donate_form' && $ed_donate_button && is_give_activated() ) return true;
    if( $control_id == 'benevolent_pro_donate_form' && $ed_donate_button && $ed_donate_form && is_give_activated() ) return true;
    if( $control_id == 'benevolent_pro_donate_button_label' && $ed_donate_button ) return true;

    if( $control_id == 'benevolent_pro_donate_button_url' && $ed_donate_button ){
        if( is_give_activated() ){
           if( $ed_donate_form ){
               return false;
           }else{
               return true;
           }
        }else{
            return true;
        }
    } 
    
    return false;
}

/**
 * Active Callback for pagination
*/
function benevolent_pro_loading_ac( $control ){
    
    $pagination_type = $control->manager->get_setting( 'benevolent_pro_pagination_type' )->value();
    
    if ( $pagination_type == 'load_more' ) return true;
    
    return false;
}

/**
 * Active Callback for Shop page description
*/
function benevolent_pro_shop_description_ac( $control ){
    $ed_shop_archive_desc = $control->manager->get_setting( 'ed_shop_archive_description' )->value();
    $control_id = $control->id;
    
    if( $control_id == 'ed_shop_archive_description' && benevolent_pro_is_woocommerce_activated() ) return true;
    if( $control_id == 'shop_archive_description' && $ed_shop_archive_desc  && benevolent_pro_is_woocommerce_activated() ) return true;
    
    return false;
}

/**
 * Active Callback for Banner Slider
*/
function benevolent_pro_banner_ac( $control ){
    $slider_type = $control->manager->get_setting( 'benevolent_pro_slider_type' )->value();
    $control_id  = $control->id;
    
    if ( $control_id == 'benevolent_pro_slider_post_one' && $slider_type == 'post' ) return true;
    if ( $control_id == 'benevolent_pro_slider_post_two' && $slider_type == 'post' ) return true;
    if ( $control_id == 'benevolent_pro_slider_post_three' && $slider_type == 'post' ) return true;
    if ( $control_id == 'benevolent_pro_slider_post_four' && $slider_type == 'post' ) return true;
    if ( $control_id == 'benevolent_pro_slider_post_five' && $slider_type == 'post' ) return true;
    if ( $control_id == 'benevolent_pro_slider_cat' && $slider_type == 'cat' ) return true;    
    if ( $control_id == 'benevolent_pro_slider_slides' && $slider_type == 'custom' ) return true;
    
    return false;
}

function benevonet_pro_child_ac( $control ){
    $child_style = $control->manager->get_setting( 'benevolent_pro_ed_child_style' )->value();
    $control_id  = $control->id;
    
    if ( $control_id == 'benevolent_pro_give_bg' && $child_style == 'default' && is_give_activated() ) return true;
    if ( $control_id == 'benevolent_pro_give_bg_charity_care' && $child_style == 'charity-care' && is_give_activated() ) return true;
    if ( $control_id == 'benevolent_pro_color_scheme' && $child_style == 'default' ) return true;
    if ( $control_id == 'benevolent_pro_secondary_color_scheme' && $child_style == 'default' ) return true;
    if ( $control_id == 'benevolent_pro_secondary_color_scheme_charity_care' && $child_style == 'charity-care' ) return true;
    if ( $control_id == 'benevolent_pro_primary_color_scheme_revive_charity' && $child_style == 'revive-charity' ) return true;
    if ( $control_id == 'benevolent_pro_secondary_color_scheme_revive_charity' && $child_style == 'revive-charity' ) return true;
    
    return false;
}

/**
 * Active Callback 
*/
function benevolent_pro_blog_ac( $control ){
    
    $layout       = $control->manager->get_setting( 'benevolent_pro_blog_layout' )->value();
    $child_theme  = $control->manager->get_setting( 'benevolent_pro_ed_child_style' )->value();
    $control_id   = $control->id;
    
    if ( $control_id == 'ed_crop_archive_page_image' && $layout !== 'round' ) return true;

    //Child theme revive charity
    if( $control_id == 'benevolent_pro_blog_section_viewall_link' && $child_theme == 'revive-charity' ) return true;
    if( $control_id == 'benevolent_pro_blog_section_viewall' && $child_theme == 'revive-charity' ) return true;

    return false;
}


/**
 * Active Callback 
*/
function benevolent_pro_community_section_ac( $control ){
    
    $child_theme  = $control->manager->get_setting( 'benevolent_pro_ed_child_style' )->value();
    $control_id   = $control->id;
    
    //Child theme revive charity
    if( $control_id == 'benevolent_pro_community_readmore' && $child_theme == 'revive-charity' ) return true;

    return false;
}

/**
 * Active Callback 
*/
function benevolent_pro_post_page_ac( $control ){
    
    $ed_featured_image = $control->manager->get_setting( 'benevolent_pro_ed_featured_image' )->value();
    $control_id        = $control->id;
    
    if ( $control_id == 'ed_crop_single_post_image' && $ed_featured_image ) return true;

    return false;
}

/**
 * Active Callback for Google Map
*/
function benevolent_pro_google_map_ac( $control ){
    $ed_google_map = $control->manager->get_setting( 'benevolent_pro_ed_google_map' )->value();
    $map_option  = $control->manager->get_setting( 'benevolent_pro_google_map_option' )->value();
    $ed_map_marker = $control->manager->get_setting( 'benevolent_pro_ed_map_marker' )->value();
    $control_id  = $control->id;
    
    if ( $control_id == 'benevolent_pro_google_map_option' && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_ed_map_scroll' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_ed_map_controls' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_ed_map_marker' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_marker_title' && ( $map_option == 'google_map_api' ) && $ed_google_map && $ed_map_marker ) return true;
    if ( $control_id == 'benevolent_pro_map_api' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_lattitude' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_longitude' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_map_height' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_map_zoom' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_map_type' && ( $map_option == 'google_map_api' ) && $ed_google_map ) return true;
    if ( $control_id == 'benevolent_pro_map_iframe' && ( $map_option == 'google_map_iframe' ) && $ed_google_map ) return true;
    
    return false;
}

/**
 * Active Callback for Body Background
*/
function benevolent_pro_body_bg_choice( $control ){
    
    $body_bg    = $control->manager->get_setting( 'benevolent_pro_body_bg' )->value();
    $control_id = $control->id;
         
    if ( $control_id == 'benevolent_pro_bg_image' && $body_bg == 'image' ) return true;
    if ( $control_id == 'benevolent_pro_bg_pattern' && $body_bg == 'pattern' ) return true;
    
    return false;
}

/**
 * Active Callback for typography
*/
function benevolent_pro_typography_ac( $control ){
    
    $child_theme = $control->manager->get_setting( 'benevolent_pro_ed_child_style' )->value();
    $control_id  = $control->id;
         
    if ( $control_id == 'benevolent_pro_body_font' && ( $child_theme == 'default' || $child_theme == 'charity-care' ) ) return true;
    if ( $control_id == 'benevolent_pro_body_font_rc' && $child_theme == 'revive-charity' ) return true;
    
    return false;
}
jQuery(document).ready(function($) {
	/* Move widgets to their respective sections */
	wp.customize.section( 'sidebar-widgets-stat-counter' ).panel( 'benevolent_pro_home_page_settings' );
	wp.customize.section( 'sidebar-widgets-stat-counter' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-cta' ).panel( 'benevolent_pro_home_page_settings' );
	wp.customize.section( 'sidebar-widgets-cta' ).priority( '70' );
    
    wp.customize.section( 'sidebar-widgets-about-profile' ).panel( 'benevolent_pro_about_page_settings' );
	wp.customize.section( 'sidebar-widgets-about-profile' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-about-counter' ).panel( 'benevolent_pro_about_page_settings' );
	wp.customize.section( 'sidebar-widgets-about-counter' ).priority( '55' );
    
        
    wp.customize.section( 'sidebar-widgets-service-first' ).panel( 'benevolent_pro_service_page_settings' );
	wp.customize.section( 'sidebar-widgets-service-first' ).priority( '40' );
    wp.customize.section( 'sidebar-widgets-service-cta' ).panel( 'benevolent_pro_service_page_settings' );
	wp.customize.section( 'sidebar-widgets-service-cta' ).priority( '50' );
    
    /* Home page preview url */
    wp.customize.panel( 'benevolent_pro_home_page_settings', function( section ){
        section.expanded.bind( function( isExpanded ) {
            if( isExpanded ){
                wp.customize.previewer.previewUrl.set( bp_cdata.home );
            }
        });
    });

     /* About Page preview url */
    wp.customize.panel( 'benevolent_pro_about_page_settings', function( section ){
        section.expanded.bind( function( isExpanded ){
            if( isExpanded ){
                wp.customize.previewer.previewUrl.set( bp_cdata.about );
            }
        });
    });

    /* Service Page preview url */
    wp.customize.panel( 'benevolent_pro_service_page_settings', function( section ){
        section.expanded.bind( function( isExpanded ){
            if( isExpanded ){
                wp.customize.previewer.previewUrl.set( bp_cdata.service );
            }
        });
    });

    /* Blog page preview url */
    wp.customize.section( 'benevolent_pro_blog_page_settings', function( section ){
        section.expanded.bind( function( isExpanded ) {
            if( isExpanded ){
                wp.customize.previewer.previewUrl.set( bp_cdata.blog );
            }
        });
    });

      /* Blog page preview url */
    wp.customize.section( 'benevolent_pro_blog_page_settings', function( section ){
        section.expanded.bind( function( isExpanded ) {
            if( isExpanded ){
                wp.customize.previewer.previewUrl.set( bp_cdata.blog );
            }
        });
    });

    // Scroll to front page sections
    $('body').on('click', '#sub-accordion-panel-benevolent_pro_home_page_settings .control-subsection .accordion-section-title', function(event) {
        var section_id = $(this).parent('.control-subsection').attr('id');
        scroll_to_homepage_section( section_id );
    }); 

    // Scroll to about page sections
    $('body').on('click', '#sub-accordion-panel-benevolent_pro_about_page_settings .control-subsection .accordion-section-title', function(event) {
        var section_id = $(this).parent('.control-subsection').attr('id');
        scroll_to_about_template_section( section_id );
    });

    //Scroll to services page sections
    $('body').on('click', '#sub-accordion-panel-benevolent_pro_service_page_settings .control-subsection .accordion-section-title', function(event) {
        var section_id = $(this).parent('.control-subsection').attr('id');
        scroll_to_services_template_section( section_id );
    });

    $('#sub-accordion-section-benevolent_pro_typography_body_section').on( 'click', '.typography_text', function(e){
        e.preventDefault();
        wp.customize.control( 'ed_googlefont_local' ).focus();        
    });

    $('#sub-accordion-section-benevolent_pro_performance_settings').on( 'click', '.ed_googlefont_local', function(e){
        e.preventDefault();
        wp.customize.control( 'typography_text' ).focus();        
    });
});

function scroll_to_homepage_section( section_id ){
    var preview_section_id = "banner-slider";

    var $contents = jQuery('#customize-preview iframe').contents();

    switch ( section_id ) {

        case 'accordion-section-benevolent_pro_intro_settings':
        preview_section_id = "intro-section";
        break;
        
        case 'accordion-section-benevolent_pro_community_settings':
        preview_section_id = "community-section";
        break;

        case 'accordion-section-sidebar-widgets-stat-counter':
        preview_section_id = "stat-section";
        break;
        
        case 'accordion-section-benevolent_pro_give_settings':
        preview_section_id = "give-section";
        break;

        case 'accordion-section-benevolent_pro_blog_settings':
        preview_section_id = "blog-section";
        break;

        case 'accordion-section-benevolent_pro_sponsor_settings':
        preview_section_id = "sponser-section";
        break;
        
        case 'accordion-section-sidebar-widgets-cta':
        preview_section_id = "cta-section";
        break;

        case 'accordion-section-benevolent_pro_sort_home_section':
        preview_section_id = "intro-section";
        break;
    }

    if( $contents.find('#'+preview_section_id).length > 0 && $contents.find('.home').length > 0 ){
        $contents.find("html, body").animate({
        scrollTop: $contents.find( "#" + preview_section_id ).offset().top
        }, 1000);
    }
}

function scroll_to_about_template_section( section_id ){
    var preview_section_id = "about-intro";

    var $contents = jQuery('#customize-preview iframe').contents();

    switch ( section_id ) {
        
        case 'accordion-section-benevolent_pro_about_intro_section':
        preview_section_id = "about-intro";
        break;
        
        case 'accordion-section-benevolent_pro_profile_section':
        case 'accordion-section-sidebar-widgets-about-profile':
        preview_section_id = "about-profile";
        break;
        
        case 'accordion-section-benevolent_pro_about_stat_counter_section':
        case 'accordion-section-sidebar-widgets-about-counter':
        preview_section_id = "about-stat";
        break;
        
        case 'accordion-section-benevolent_pro_about_believe_section':
        preview_section_id = "about-believe";
        break;
        
        case 'accordion-section-benevolent_pro_about_current_project_section':
        preview_section_id = "about-current";
        break;

        case 'accordion-section-benevolent_pro_sort_about_section':
        preview_section_id = "about-intro";
        break;
    }

    if( $contents.find('#'+preview_section_id).length > 0 && $contents.find('.page-template-template-about').length > 0 ){
        $contents.find("html, body").animate({
        scrollTop: $contents.find( "#" + preview_section_id ).offset().top
        }, 1000);
    }
}

function scroll_to_services_template_section( section_id ){
    var preview_section_id = "service-intro";

    var $contents = jQuery('#customize-preview iframe').contents();

    switch ( section_id ) {
        
        case 'accordion-section-benevolent_pro_service_intro_section':
        preview_section_id = "service-intro";
        break;
        
        case 'accordion-section-benevolent_pro_service_services_section':
        case 'accordion-section-sidebar-widgets-service-first':
        preview_section_id = "service-work";
        break;

        case 'accordion-section-sidebar-widgets-service-cta':
        preview_section_id = "service-promotional";
        break;

        case 'accordion-section-benevolent_pro_service_donor_section':
        preview_section_id = "sponser-section";
        break;

        case 'accordion-section-benevolent_pro_sort_service_section':
        preview_section_id = "service-intro";
        break;
    }

    if( $contents.find('#'+preview_section_id).length > 0 && $contents.find('.page-template-template-service').length > 0 ){
        $contents.find("html, body").animate({
        scrollTop: $contents.find( "#" + preview_section_id ).offset().top
        }, 1000);
    }
}
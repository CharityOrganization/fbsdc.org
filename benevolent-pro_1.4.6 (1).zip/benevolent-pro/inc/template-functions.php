<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Benevolent_Pro
 */

if( ! function_exists( 'benevolent_pro_doctype_cb' ) ) :
/**
 * Doctype Declaration
*/
function benevolent_pro_doctype_cb(){
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <?php
}
endif;
add_action( 'benevolent_pro_doctype', 'benevolent_pro_doctype_cb' );

if( ! function_exists( 'benevolent_pro_head' ) ) :
/**
 * Before wp_head
*/
function benevolent_pro_head(){
    ?>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php
}
endif;
add_action( 'benevolent_pro_before_wp_head', 'benevolent_pro_head' );

if( ! function_exists( 'benevolent_pro_fb_page_box' ) ) :
/**
 * Callback to add Facebook Page Plugin JS
*/
function benevolent_pro_fb_page_box(){
    if( is_active_widget( false, false, 'benevolent_pro_facebook_page_widget' ) ){ ?>
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    <?php }
}
endif;
add_action( 'benevolent_pro_before_header', 'benevolent_pro_fb_page_box', 15 );

if( ! function_exists( 'benevolent_pro_page_start' ) ) :
/**
 * Page Start
*/
function benevolent_pro_page_start(){
    ?>
    <div id="page" class="site">
    <?php
}
endif;
add_action( 'benevolent_pro_before_header', 'benevolent_pro_page_start', 20 );

if( ! function_exists( 'benevolent_pro_responsive_menu' ) ) :
/**
 * Responsive menu
*/
function benevolent_pro_responsive_menu(){
    $button_menu_outside = get_theme_mod( 'benevolent_pro_ed_donate_btn_outside_menu' );
    $ed_donate_form      = get_theme_mod( 'benevolent_pro_ed_donate_form' );
    $donate_form         = get_theme_mod( 'benevolent_pro_donate_form' );
    $button_text         = get_theme_mod( 'benevolent_pro_donate_button_label', __( 'Donate Now', 'benevolent-pro' ) );
    $button_url          = get_theme_mod( 'benevolent_pro_donate_button_url' );

    $ed_search_form      = get_theme_mod( 'benevolent_pro_ed_search_form', '1' );
    $ed_social_link      = get_theme_mod( 'benevolent_pro_ed_social_header' );
    $new_tab             = get_theme_mod( 'benevolent_pro_ed_donate_in_new_tab' );
    $target              = $new_tab ? 'target="_blank"' : 'target="_self"';

    ?>
    <div class="mobile-header">
       <div class="container">
            <div class="site-branding">
           <?php
                if( function_exists( 'has_custom_logo' ) && has_custom_logo() ){
                    echo '<div class="img-logo">';
                    the_custom_logo();
                    echo '</div><!-- .img-logo -->';
                } ?>
                <div class="text-logo">
                <?php
                    $site_title =  get_bloginfo( 'name', 'display' );
                    $description = get_bloginfo( 'description', 'display' );

                    if( $site_title ) : ?>
                        <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></p>
                    <?php
                    endif;
                
                   if ( $description ) : ?>
                       <p class="site-description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
                    <?php
                   endif; 
                ?>
                </div>
            </div> <!-- site-branding ends --> 
            <?php 
                if( $button_menu_outside ) {
                    if( is_give_activated() && ( $ed_donate_form && $donate_form && $button_text ) ){
                        echo '<div class="btn-donate"><a href="' . esc_url( get_permalink( $donate_form ) ). '" '. $target .'>' . esc_html( $button_text ) . '</a></div>';
                    }elseif( $button_text && $button_url ){ 
                        echo '<div class="btn-donate"><a href="' . esc_url( $button_url ). '" '. $target .'>' . esc_html( $button_text ) . '</a></div>';
                    }
                } 
            ?>
            <div class="menu-opener">
               <span></span>
               <span></span>
               <span></span>
           </div>
       </div>
       <div class="mobile-menu">
            <?php  
                if( $ed_search_form ) get_search_form();

                benevolent_pro_navigation_menu_primary( false, '' );

                benevolent_pro_navigation_menu_secondary( false, '' );

                if( $ed_social_link ) benevolent_pro_get_social_links();

            ?>
       </div>
   </div>
    <?php
}
endif;
add_action( 'benevolent_pro_before_header', 'benevolent_pro_responsive_menu', 25 );

if( ! function_exists( 'benevolent_pro_dynamic_header' ) ) :
/**
 * Dynamic Header 
*/
function benevolent_pro_dynamic_header(){
    
    $header_array = array( 'one', 'two', 'three', 'four', 'five' );
    $header = get_theme_mod( 'benevolent_pro_header_layout', 'one' );
    if( in_array( $header, $header_array ) ){            
        get_template_part( 'header/' . $header );
    }
    
}
endif;
add_action( 'benevolent_pro_header', 'benevolent_pro_dynamic_header', 20 );

if( ! function_exists( 'benevolent_pro_slider' ) ) : 
/**
 * Callback for Banner Slider 
 */
function benevolent_pro_slider(){

    if( is_front_page() && get_theme_mod( 'benevolent_pro_ed_slider' ) ){
    
        $slider_caption    = get_theme_mod( 'benevolent_pro_slider_caption', '1' );
        $slider_type       = get_theme_mod( 'benevolent_pro_slider_type', 'post' ); 
        $slider_post_one   = get_theme_mod( 'benevolent_pro_slider_post_one' );
        $slider_post_two   = get_theme_mod( 'benevolent_pro_slider_post_two' );
        $slider_post_three = get_theme_mod( 'benevolent_pro_slider_post_three' );
        $slider_post_four  = get_theme_mod( 'benevolent_pro_slider_post_four' );
        $slider_post_five  = get_theme_mod( 'benevolent_pro_slider_post_five' );
        $slider_cat        = get_theme_mod( 'benevolent_pro_slider_cat' );
        $slider_slides     = get_theme_mod( 'benevolent_pro_slider_slides' );
        $slider_readmore   = get_theme_mod( 'benevolent_pro_slider_readmore', __( 'Learn More', 'benevolent-pro' ) );
        $slider_full_img   = get_theme_mod( 'benevolent_pro_slider_full_image' );
        
        $slider_posts      = array( $slider_post_one, $slider_post_two, $slider_post_three, $slider_post_four, $slider_post_five );
        $slider_posts      = array_diff( array_unique( $slider_posts ), array('') );
        
        if( $slider_full_img ){
            $img_size = 'full';
        }else{
            $img_size = 'benevolent-pro-slider';
        }
                
        if( $slider_type == 'post' || $slider_type == 'cat' ){
            
            if( $slider_type == 'post' && $slider_posts ){
                $qry = new WP_Query ( array( 
                    'post_type'           => array( 'post', 'page' ),
                    'post_status'         => 'publish',
                    'posts_per_page'      => -1,                    
                    'post__in'            => $slider_posts, 
                    'orderby'             => 'post__in',
                    'ignore_sticky_posts' => true
                ) );
                
                if( $qry->have_posts() ){?>
                    <div class="banner">
                        <div id="banner-slider" class="owl-carousel">
                        <?php
                            while( $qry->have_posts() ){
                                $qry->the_post();
                                
                                if( has_post_thumbnail() ){?>
                                    <div class="item">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail( $img_size, array( 'itemprop' => 'image' ) ); ?>
                                        </a>
                                        <?php 
                                            if( $slider_caption ){ ?>
                                                <div class="banner-text">
                                                    <div class="container">
                                                        <div class="text">                								
                                                            <strong class="main-title"><?php the_title(); ?></strong>
                                                            <?php 
                                                                if( has_excerpt() ){
                                                                    the_excerpt();    
                                                                }else{
                                                                    echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );
                                                                }  
                                                            ?>
                                                            <a class="btn-more" href="<?php the_permalink(); ?>"><?php echo esc_html( $slider_readmore );?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php 
                                            } 
                                        ?>
                                    </div>
                                    <?php
                                } 
                            }
                            wp_reset_postdata();
                        ?>
                        </div>
                    </div>
                    <?php
                }else{
                    echo '<div class="banner"></div>';
                }
                wp_reset_postdata();       
            } //end of post slider
            
            if( $slider_type == 'cat' && $slider_cat ){
                $qry = new WP_Query ( array( 
                    'post_type'           => 'post', 
                    'post_status'         => 'publish',
                    'posts_per_page'      => -1,                    
                    'cat'                 => $slider_cat,
                    'ignore_sticky_posts' => true
                ) );
                
                if( $qry->have_posts() ){?>
                    <div class="banner">
                        <div id="banner-slider" class="owl-carousel">
                            <?php
                                while( $qry->have_posts() ){
                                    $qry->the_post();
                                    
                                    if( has_post_thumbnail() ){?>
                                        <div>
                                            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $img_size, array( 'itemprop' => 'image' ) ); ?></a>
                                            <?php 
                                                if( $slider_caption ){ ?>
                                                    <div class="banner-text">
                                                        <div class="container">
                                                            <div class="text">                								
                                                                <strong class="main-title"><?php the_title(); ?></strong>
                                                                <?php 
                                                                    if( has_excerpt() ){
                                                                        the_excerpt();    
                                                                    }else{
                                                                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );
                                                                    }  
                                                                ?>
                                                                <a class="btn-more" href="<?php the_permalink(); ?>"><?php echo esc_html( $slider_readmore );?></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                } 
                                            ?>
                                        </div>
                                        <?php 
                                    }
                                }
                            ?>
                        </div>
                    </div>
                    <?php
                }else{
                    echo '<div class="banner"></div>';
                }
                wp_reset_postdata();       
            }//end of cat slider   
            
        }elseif( $slider_type == 'custom' && $slider_slides ){ //end of post and cat slider ?>
            <div class="banner">
                <div id="banner-slider" class="owl-carousel">
                    <?php
                        foreach( $slider_slides as $slides ){
                            if( $slides['thumbnail'] ){
                                $image = wp_get_attachment_image_src( $slides['thumbnail'], $img_size );
                                if( $image ){ ?>
                                    <div>
                                        <?php 
                                            if( $slides['link'] ) echo '<a href="' . esc_url( $slides['link'] ) . '">'; 
                                            echo wp_get_attachment_image( $slides['thumbnail'], $img_size );
                                        ?>
                                        <?php if( $slides['link'] ) echo '</a>'; ?>
                                        <?php if( $slider_caption && ( $slides['title'] || ( $slides['link'] && $slider_readmore ) ) ){ ?>
                                        <div class="banner-text">
                                            <div class="container">
                                                <div class="text">
                                                    <?php 
                                                    if( $slides['title'] ) echo '<strong class="main-title">' . esc_html( $slides['title'] ) . '</strong>';
                                                    if( $slides['content'] ) echo wpautop( wp_kses_post( $slides['content'] ) );
                                                    if( $slides['link'] && $slider_readmore ){ ?>
                                                    <a href="<?php echo esc_url( $slides['link'] ); ?>" class="btn-more"><?php echo esc_html( $slider_readmore ); ?></a>
                                                    <?php }?>
                                                </div>
                                            </div>
                                        </div>                                
                                        <?php }?>
                                    </div>
                                    <?php        
                                }        
                            }
                        }
                    ?>
                </div>
            </div>
            <?php
        }else{
            echo '<div class="banner"></div>';
        }// end of custom slider
    }
}
endif;
add_action( 'benevolent_pro_after_header', 'benevolent_pro_slider', 20 );

if( ! function_exists( 'benevolent_pro_breadcrumb' ) ) :
/**
 * Custom Bread Crumb
 *
 * @link http://www.qualitytuts.com/wordpress-custom-breadcrumbs-without-plugin/
 */
function benevolent_pro_breadcrumb() {
    
    if( get_theme_mod( 'benevolent_pro_ed_breadcrumb' ) && ! is_404() ){ 
        
        global $post;
        
        $post_page   = get_option( 'page_for_posts' ); //The ID of the page that displays posts.
        $show_front  = get_option( 'show_on_front' ); //What to show on the front page
        $showOnHome  = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
        $delimiter   = get_theme_mod( 'benevolent_pro_breadcrumb_separator', __( '>', 'benevolent-pro' ) ); // delimiter between crumbs
        $home        = get_theme_mod( 'benevolent_pro_breadcrumb_home_text', __( 'Home', 'benevolent-pro' ) ); // text for the 'Home' link
        $showCurrent = get_theme_mod( 'benevolent_pro_ed_current', '1' ); // 1 - show current post/page title in breadcrumbs, 0 - don't show
        $before      = '<span class="current" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">'; // tag before the current crumb
        $after       = '</span>'; // tag after the current crumb        
     
        if( is_front_page() ){
        
            if( $showOnHome == 1 ) echo '<div id="crumbs"><div class="container"><a href="' . esc_url( home_url() ) . '">' . esc_html( $home ) . '</a></div></div>';
        
        }else{
     
           $depth = 1;
           echo '<div id="crumbs" itemscope itemtype="https://schema.org/BreadcrumbList"><div class="container"><span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( home_url() ) . '"><span itemprop="name">' . esc_html( $home ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
            
            if( is_home() ){
                $depth = 2;
                if( $showCurrent == 1 ) echo $before . '<a itemprop="item" href="'. esc_url( get_the_permalink() ) .'"><span itemprop="name">' . esc_html( single_post_title( '', false ) ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                              
            }elseif( is_category() ){
                
                $depth = 2;
                $thisCat = get_category( get_query_var( 'cat' ), false );

                if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                    $p = get_post( $post_page );
                    echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_permalink( $post_page ) ) . '"><span itemprop="name">' . esc_html( $p->post_title ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                    $depth ++;  
                }

                if ( $thisCat->parent != 0 ) {
                    $parent_categories = get_category_parents( $thisCat->parent, false, ',' );
                    $parent_categories = explode( ',', $parent_categories );

                    foreach ( $parent_categories as $parent_term ) {
                        $parent_obj = get_term_by( 'name', $parent_term, 'category' );
                        if( is_object( $parent_obj ) ){
                            $term_url    = get_term_link( $parent_obj->term_id );
                            $term_name   = $parent_obj->name;
                            echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( $term_url ) . '"><span itemprop="name">' . esc_html( $term_name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                            $depth ++;
                        }
                    }
                }
                if( $showCurrent == 1 ) echo $before . '<a itemprop="item" href="' . esc_url( get_term_link( $thisCat->term_id) ) . '"><span itemprop="name">' .  esc_html( single_cat_title( '', false ) ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" />' . $after;
                
         
            }elseif( benevolent_pro_is_woocommerce_activated() && ( is_product_category() || is_product_tag() ) ){ //For Woocommerce archive page
        
                $depth = 2;
                $current_term = $GLOBALS['wp_query']->get_queried_object();
                
                if ( wc_get_page_id( 'shop' ) ) { //Displaying Shop link in woocommerce archive page
                    $_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
                    $shop_url = wc_get_page_id( 'shop' ) && wc_get_page_id( 'shop' ) > 0  ? get_the_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop' );
                    if ( ! $_name ) {
                        $product_post_type = get_post_type_object( 'product' );
                        $_name = $product_post_type->labels->singular_name;
                    }
                    echo ' <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( $shop_url ) . '"><span itemprop="name">' . esc_html( $_name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /> <span class="separator">' . esc_html( $delimiter ) . '</span></span> ';
                    $depth++;
                }

                if( is_product_category() ){
                    $ancestors = get_ancestors( $current_term->term_id, 'product_cat' );
                    $ancestors = array_reverse( $ancestors );
                    foreach ( $ancestors as $ancestor ) {
                        $ancestor = get_term( $ancestor, 'product_cat' );    
                        if ( ! is_wp_error( $ancestor ) && $ancestor ) {
                            echo ' <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_term_link( $ancestor ) ) . '"><span itemprop="name">' . esc_html( $ancestor->name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /> <span class="separator">' . esc_html( $delimiter ) . '</span></span> ';
                            $depth++;
                        }
                    }
                }           
                if( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_term_link( $current_term->term_id ) ) . '"><span itemprop="name">'. esc_html( $current_term->name ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                
            }elseif( benevolent_pro_is_woocommerce_activated() && is_shop() ){ //Shop Archive page
                $depth = 2;
                if ( get_option( 'page_on_front' ) == wc_get_page_id( 'shop' ) ) {
                    return;
                }
                $_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
                $shop_url = wc_get_page_id( 'shop' ) && wc_get_page_id( 'shop' ) > 0  ? get_the_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop' );
        
                if ( ! $_name ) {
                    $product_post_type = get_post_type_object( 'product' );
                    $_name = $product_post_type->labels->singular_name;
                }
                if( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( $shop_url ) . '"><span itemprop="name">'. esc_html( $_name ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                
            }elseif( is_tag() ){

                $queried_object = get_queried_object();
                $depth = 2;
                if ( $showCurrent == 1 ) echo $before . '<a itemprop="item" href="' . esc_url( get_term_link( $queried_object->term_id ) ) . '"><span itemprop="name">' . esc_html( single_tag_title( '', false ) ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_author() ){
                
                $depth = 2;
                global $author;

                $userdata = get_userdata( $author );
                if ( $showCurrent == 1 ) echo $before . '<a itemprop="item" href="' . esc_url( get_author_posts_url( $author ) ) . '"><span itemprop="name">' . esc_html( $userdata->display_name ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_search() ){
                
                $depth = 2;
                $request_uri = $_SERVER['REQUEST_URI'];
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="'. esc_url( $request_uri ) .'"><span itemprop="name">'. esc_html__( 'Search Results for "', 'benevolent-pro' ) . esc_html( get_search_query() ) . esc_html__( '"', 'benevolent-pro' ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_day() ){
                
                $depth = 2;
                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_year_link( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">' . esc_html( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                $depth ++;
                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_month_link( get_the_time( __( 'Y', 'benevolent-pro' ) ), get_the_time( __( 'm', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">' . esc_html( get_the_time( __( 'F', 'benevolent-pro' ) ) ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                $depth ++;
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_day_link( get_the_time( __( 'Y', 'benevolent-pro' ) ), get_the_time( __( 'm', 'benevolent-pro' ) ), get_the_time( __( 'd', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">'. esc_html( get_the_time( __( 'd', 'benevolent-pro' ) ) ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_month() ){
                
                $depth = 2;
                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( get_year_link( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">' . esc_html( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                $depth++;
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_month_link( get_the_time( __( 'Y', 'benevolent-pro' ) ), get_the_time( __( 'm', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">'. esc_html( get_the_time( __( 'F', 'benevolent-pro' ) ) ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_year() ){
                $depth = 2;
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_year_link( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) ) . '"><span itemprop="name">'. esc_html( get_the_time( __( 'Y', 'benevolent-pro' ) ) ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
         
            }elseif( is_single() && !is_attachment() ){
                
                if( benevolent_pro_is_woocommerce_activated() && 'product' === get_post_type() ){ //For Woocommerce single product
            		$depth = 2;
                    if ( wc_get_page_id( 'shop' ) ) { //Displaying Shop link in woocommerce archive page
                        $_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
                        $shop_url = wc_get_page_id( 'shop' ) && wc_get_page_id( 'shop' ) > 0  ? get_the_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop' );
                        if ( ! $_name ) {
                            $product_post_type = get_post_type_object( 'product' );
                            $_name = $product_post_type->labels->singular_name;
                        }
                        echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( $shop_url ) . '"><span itemprop="name">' . esc_html( $_name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /> <span class="separator">' . esc_html( $delimiter ) . '</span></span> ';
                        $depth++;
                    }
                
                    if ( $terms = wc_get_product_terms( $post->ID, 'product_cat', array( 'orderby' => 'parent', 'order' => 'DESC' ) ) ) {
                        $main_term = apply_filters( 'woocommerce_breadcrumb_main_term', $terms[0], $terms );
                        $ancestors = get_ancestors( $main_term->term_id, 'product_cat' );
                        $ancestors = array_reverse( $ancestors );
                        foreach ( $ancestors as $ancestor ) {
                            $ancestor = get_term( $ancestor, 'product_cat' );    
                            if ( ! is_wp_error( $ancestor ) && $ancestor ) {
                                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_term_link( $ancestor ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $ancestor->name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                                $depth++;
                            }
                        }
                        echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_term_link( $main_term ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $main_term->name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                        $depth ++;
                    }
                    
                    if ( $showCurrent == 1 ) echo $before .'<a href="' . esc_url( get_the_permalink() ) . '" itemprop="item"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                    
                }elseif ( get_post_type() != 'post' ) { //For Custom Post Type
                     $post_type = get_post_type_object( get_post_type() );
                        if( ( get_post_type() != 'team' ) && ( get_post_type() != 'testimonial' ) && ( get_post_type() != 'logo' ) ){ //excluding archive for our CPTs.
                            $label = !empty( $post_type->labels->archive_title ) ? $post_type->labels->archive_title : $post_type->labels->name;
                           printf( '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="%1$s" itemprop="item"><span itemprop="name">%2$s</span></a><meta itemprop="position" content="%3$s" />', esc_url( get_post_type_archive_link( get_post_type() ) ), $label, $depth );
                           echo '<meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                           $depth ++;
                        }
                        
                    if ( $showCurrent == 1 ) echo $before .'<a href="' . esc_url( get_the_permalink() ) . '" itemprop="item"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                    
                }else{ //For Post
                    
                    $cat_object       = get_the_category();
                    $potential_parent = 0;
                    $depth            = 2;
                    
                    if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                        $p = get_post( $post_page );
                        echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_permalink( $post_page ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $p->post_title ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';  
                        $depth++;
                    }
                    
                    if( is_array( $cat_object ) ){ //Getting category hierarchy if any
            
                        //Now try to find the deepest term of those that we know of
                        $use_term = key( $cat_object );
                        foreach( $cat_object as $key => $object )
                        {
                            //Can't use the next($cat_object) trick since order is unknown
                            if( $object->parent > 0  && ( $potential_parent === 0 || $object->parent === $potential_parent ) ){
                                $use_term = $key;
                                $potential_parent = $object->term_id;
                            }
                        }
                        
                        $cat = $cat_object[$use_term];
                  
                        $cats = get_category_parents( $cat, false, ',' );
                        $cats = explode( ',', $cats );

                        foreach ( $cats as $cat ) {
                            $cat_obj = get_term_by( 'name', $cat, 'category' );
                            if( is_object( $cat_obj ) ){
                                $term_url    = get_term_link( $cat_obj->term_id );
                                $term_name   = $cat_obj->name;
                                echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a itemprop="item" href="' . esc_url( $term_url ) . '"><span itemprop="name">' . esc_html( $term_name ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /><span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                                $depth ++;
                            }
                        }
                }
    
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_the_permalink() ) . '"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;  
                }
            
            }elseif( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ){
                
                $depth = 2;
                $post_type = get_post_type_object(get_post_type());
                if( get_query_var('paged') ){
                    echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_post_type_archive_link( $post_type->name ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $post_type->label ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" />';
                    echo ' <span class="separator">' . esc_html( $delimiter ) . '</span></span> ' . $before . sprintf( __('Page %s', 'benevolent-pro'), get_query_var('paged') ) . $after;
                }elseif( is_archive() ){
                    echo $before .'<a itemprop="item" href="' . esc_url( get_post_type_archive_link( $post_type->name ) ) . '"><span itemprop="name">'. esc_html( post_type_archive_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                }else{
                    echo $before .'<a itemprop="item" href="' . esc_url( get_post_type_archive_link( $post_type->name ) ) . '"><span itemprop="name">'. esc_html( $post_type->label ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
                }
         
            }elseif ( is_attachment() ){
                
                $depth = 2;
                $parent = get_post( $post->post_parent );
                $cat = get_the_category( $parent->ID ); 
                if( $cat ){
                    $cat = $cat[0];
                    echo get_category_parents( $cat, TRUE, ' <span class="separator">' . esc_html( $delimiter ) . '</span> ');
                    echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_permalink( $parent ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $parent->post_title ) . '<span></a><meta itemprop="position" content="'. absint( $depth ).'" />' . ' <span class="separator">' . esc_html( $delimiter ) . '</span></span>';
                }
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_the_permalink() ) . '"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
             
            } elseif ( is_page() && !$post->post_parent ) {
                $depth = 2;
                if ( $showCurrent == 1 ) echo $before .'<a itemprop="item" href="' . esc_url( get_the_permalink() ) . '"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" />'. $after;
            } elseif ( is_page() && $post->post_parent ) {
                
                 global $post;
                $depth = 2;
                $parent_id  = $post->post_parent;
                $breadcrumbs = array();
                
                while( $parent_id ){
                    $current_page  = get_post( $parent_id );
                    $breadcrumbs[] = $current_page->ID;
                    $parent_id     = $current_page->post_parent;
                }
                $breadcrumbs = array_reverse( $breadcrumbs );
                for ( $i = 0; $i < count( $breadcrumbs); $i++ ){
                    echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><a href="' . esc_url( get_permalink( $breadcrumbs[$i] ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( get_the_title( $breadcrumbs[$i] ) ) . '</span></a><meta itemprop="position" content="'. absint( $depth ).'" /></span>';
                    if ( $i != count( $breadcrumbs ) - 1 ) echo ' <span class="separator">' . esc_html( $delimiter ) . '</span> ';
                    $depth++;
                }

                echo ' <span class="separator">' . esc_html( $delimiter ) . '</span> ' . $before .'<a href="' . get_permalink() . '" itemprop="item"><span itemprop="name">'. esc_html( get_the_title() ) .'</span></a><meta itemprop="position" content="'. absint( $depth ).'" /></span>'. $after;
                } 
            
            if ( get_query_var('paged') && ( $showCurrent == 1 ) ) echo __( ' (Page', 'benevolent-pro' ) . ' ' . get_query_var('paged') . __( ')', 'benevolent-pro' );
         
            echo '</div></div>';
     
        }
    }
} // end benevolent_pro_breadcrumb()
endif;
add_action( 'benevolent_pro_before_content', 'benevolent_pro_breadcrumb', 20 );

if( ! function_exists( 'benevolent_pro_content_start' ) ) :
/**
 * Content Start
*/
function benevolent_pro_content_start(){
    
    if( ! is_page_template( array( 'templates/template-home.php', 'templates/template-about.php', 'templates/template-service.php', 'templates/template-team.php', 'templates/template-testimonial.php' ) ) ){ 
        if ( benevolent_pro_is_elementor_activated_post() ) echo '<div id="content" class="site-content">';

        echo '<div class="container">';
        
            if( ! is_page_template( 'templates/template-contact.php' ) ){ 
                if ( ! benevolent_pro_is_elementor_activated_post() ) echo '<div id="content" class="site-content">';

                echo '<div class="row">';               
            }                       
    }
}
endif;
add_action( 'benevolent_pro_content', 'benevolent_pro_content_start' );

if( ! function_exists( 'benevolent_pro_content_end' ) ) :
/**
 * Content End
*/
function benevolent_pro_content_end(){
    if( ! is_page_template( array( 'templates/template-home.php', 'templates/template-about.php', 'templates/template-service.php', 'templates/template-team.php', 'templates/template-testimonial.php' ) ) ){
        
        if( ! is_page_template( 'templates/template-contact.php' ) ){ ?>
                </div><!-- .row -->
            </div><!-- #content -->
            <?php } ?>
        </div><!-- .container -->
    <?php    
    }
}
endif;
add_action( 'benevolent_pro_after_content', 'benevolent_pro_content_end', 20 );

if( ! function_exists( 'benevolent_pro_footer_start' ) ) :
/**
 * Footer Start
*/
function benevolent_pro_footer_start(){
    ?>
    <footer id="colophon" class="site-footer" role="contentinfo" itemscope itemtype="https://schema.org/WPFooter">
    <?php
}
endif;
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_start', 20 );

if( ! function_exists( 'benevolent_pro_footer_top' ) ) :
/**
 * Footer Top
*/
function benevolent_pro_footer_top(){
    if( is_active_sidebar( 'footer-one' ) || is_active_sidebar( 'footer-two' ) || is_active_sidebar( 'footer-three' ) || is_active_sidebar( 'footer-four' ) ){ ?>
    <div class="container">
		<div class="footer-t">
			<div class="row">
					<?php if( is_active_sidebar( 'footer-one' ) ){ ?>
					<div class="column">
					   <?php dynamic_sidebar( 'footer-one' ); ?>	
					</div>
                <?php } ?>
				
                <?php if( is_active_sidebar( 'footer-two' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-two' ); ?>	
					</div>
                <?php } ?>
                
                <?php if( is_active_sidebar( 'footer-three' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-three' ); ?>	
					</div>
                <?php } ?>
                
                <?php if( is_active_sidebar( 'footer-four' ) ){ ?>
                    <div class="column">
					   <?php dynamic_sidebar( 'footer-four' ); ?>	
					</div>
                <?php } ?>
				</div>
		</div>
	</div>
    <?php 
    } 
}
endif;
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_top', 30 );

if( ! function_exists( 'benevolent_pro_footer_credit' ) ) :
/**
 * Footer Credits 
*/
function benevolent_pro_footer_credit(){
    
    $footer_copyright = get_theme_mod( 'benevolent_pro_footer_copyright' );
    $ed_author_link   = get_theme_mod( 'benevolent_pro_ed_author_link' );
    $ed_wp_link       = get_theme_mod( 'benevolent_pro_ed_wp_link' );
    
    $text  = '<div class="site-info"><div class="container">';
    
    if( $footer_copyright ){
        $text .= '<span class="copyright">' . wp_kses_post( benevolent_pro_apply_footer_shortcode( $footer_copyright ) ) . '</span>';
    }else{
        $text .= '<span class="copyright">';
        $text .=  esc_html__( '&copy; ', 'benevolent-pro' ) . date_i18n( esc_html__( 'Y', 'benevolent-pro' ) ); 
        $text .= ' <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>.</span>';
    }
    
    if( ! $ed_author_link || ! $ed_wp_link ) $text .= '<span class="by">';
    
    if( ! $ed_author_link ){
        $text .= esc_html__( 'Benevolent Pro | Developed By ', 'benevolent-pro' );
        $text .= '<a href="' . esc_url( 'https://rarathemes.com/' ) .'" rel="nofollow" target="_blank">' . esc_html__( 'Rara Theme', 'benevolent-pro' ) . '</a>.';
    }
    
    if( ! $ed_wp_link ){
        $text .= sprintf( esc_html__( ' Powered by: %s.', 'benevolent-pro' ), '<a href="'. esc_url( __( 'https://wordpress.org/', 'benevolent-pro' ) ) .'" target="_blank">WordPress</a>' );
    }
    
    if( ! $ed_author_link || ! $ed_wp_link ) $text .= '</span>';
    
    if ( function_exists( 'the_privacy_policy_link' ) ) {
       $text .= get_the_privacy_policy_link();
    }
    
    $text .= '</div></div>';
    
    echo apply_filters( 'benevolent_pro_footer_text', $text );        
        
}
endif;
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_credit', 40 );

if( ! function_exists( 'benevolent_pro_footer_end' ) ) :
/**
 * Footer End
*/
function benevolent_pro_footer_end(){
    ?>
    </footer><!-- #colophon -->
    <div class="overlay"></div>
    <?php
}
endif;
add_action( 'benevolent_pro_footer', 'benevolent_pro_footer_end', 50 );

if( ! function_exists( 'benevolent_pro_back_to_top' ) ) :
/**
 * Back to Top
*/
function benevolent_pro_back_to_top(){
    ?>
    <div id="rara-top"><i class="fa fa-angle-up"></i></div>
    <?php
}
endif;
add_action( 'benevolent_pro_after_footer', 'benevolent_pro_back_to_top', 15 );

if( ! function_exists( 'benevolent_pro_page_end' ) ) :
/**
 * Page End
*/
function benevolent_pro_page_end(){
    ?>
    </div><!-- #page -->
    <?php
}
endif;
add_action( 'benevolent_pro_after_footer', 'benevolent_pro_page_end', 20 );
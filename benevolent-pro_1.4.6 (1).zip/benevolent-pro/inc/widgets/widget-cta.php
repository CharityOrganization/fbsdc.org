<?php
/**
 * Call To Action Widget
 *
 * @package Benevolent_Pro
 */

// register Benevolent_Pro_Cta_Widget widget
function benevolent_pro_register_cta_widget(){
    register_widget( 'Benevolent_Pro_Cta_Widget' );
}
add_action('widgets_init', 'benevolent_pro_register_cta_widget');
 
 /**
 * Adds Benevolent_Pro_Cta_Widget widget.
 */
class Benevolent_Pro_Cta_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
            'benevolent_pro_cta_widget', // Base ID
            __( 'RARA: Call To Action Widget', 'benevolent-pro' ), // Name
            array( 'description' => __( 'A Call To Action Text Widget.', 'benevolent-pro' ), ) // Args
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        
        $title       = ! empty( $instance['title'] ) ? $instance['title'] : '' ;        
        $content     = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $bg_image    = ! empty( $instance['bg_image'] ) ? $instance['bg_image'] : '';
        $bg_color    = ! empty( $instance['bg_color'] ) ? $instance['bg_color'] : '#686868';
        $button_text = ! empty( $instance['button_text'] ) ? $instance['button_text'] : '' ;
        $button_url  = ! empty( $instance['button_url'] ) ? $instance['button_url'] : '' ;
        
        if( $bg_image ){
                $attachment_id = $bg_image;
                $image_array   = wp_get_attachment_image_src( $attachment_id, 'full');
                $fimg_url      = $image_array[0]; 
            $bg = 'style="background:url(' . esc_url( $fimg_url ) . ') no-repeat"';
        }else{
            $bg = 'style="background:' . sanitize_hex_color( $bg_color ) . '"';
        }
        
        echo $args['before_widget']; ?>
        <div class="text" <?php echo $bg; ?>>
            <div class="container">
                <div class="text-holder">
                    <?php if( $title ) echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title']; ?>
                    <div class="widget-content">
                        <?php
                        if( $content ) echo wpautop( wp_kses_post( $content ) ); 
                        
                        if( $button_text && $button_url ) echo '<a href="' . esc_url( $button_url ) . '" class="btn-donate">' . esc_html( $button_text ) . '</a>';
                        ?>
                    </div>                
                </div>
            </div>
        </div>
        <?php 
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        
        $title       = ! empty( $instance['title'] ) ? $instance['title'] : '' ;        
        $content     = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $bg_image    = ! empty( $instance['bg_image'] ) ? $instance['bg_image'] : '';
        $bg_color    = ! empty( $instance['bg_color'] ) ? $instance['bg_color'] : '#686868';
        $button_text = ! empty( $instance['button_text'] ) ? $instance['button_text'] : '' ;
        $button_url  = ! empty( $instance['button_url'] ) ? $instance['button_url'] : '' ;
        
        ?>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />            
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content', 'benevolent-pro' ); ?></label>
            <textarea name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php print $content; ?></textarea>
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'button_text' ) ); ?>"><?php esc_html_e( 'Button Text', 'benevolent-pro' ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'button_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'button_text' ) ); ?>" type="text" value="<?php echo esc_attr( $button_text ); ?>" />
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'button_url' ) ); ?>"><?php esc_html_e( 'Button Link', 'benevolent-pro' ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'button_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'button_url' ) ); ?>" type="text" value="<?php echo esc_url( $button_url ); ?>" />
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'bg_color' ) ); ?>"><?php esc_html_e( 'Background Color', 'benevolent-pro' ); ?></label><br />
            <input class="rara-color-picker" type="text" data-default-color="#686868" id="<?php echo esc_attr( $this->get_field_id( 'bg_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bg_color' ) ); ?>" value="<?php echo esc_attr( $bg_color ); ?>" />
        </p>
        
        <?php benevolent_pro_get_image_field( $this->get_field_id( 'bg_image' ), $this->get_field_name( 'bg_image' ), $bg_image, __( 'Background Image', 'benevolent-pro' ) ); ?>
                        
        <?php
    }
    
    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        
        $instance['title']       = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '' ;
        $instance['content']     = ! empty( $new_instance['content'] ) ? wp_kses_post( $new_instance['content'] ) : '';
        $instance['bg_image']    = ! empty( $new_instance['bg_image'] ) ? absint( $new_instance['bg_image'] ) : '';
        $instance['bg_color']    = ! empty( $new_instance['bg_color'] ) ? sanitize_hex_color( $new_instance['bg_color'] ) : '#686868';
        $instance['button_url']  = ! empty( $new_instance['button_url'] ) ? esc_url_raw( $new_instance['button_url'] ) : '';
        $instance['button_text'] = ! empty( $new_instance['button_text'] ) ? sanitize_text_field( $new_instance['button_text'] ) : '';
        
        return $instance;
    }
    
}  // class Benevolent_Pro_Cta_Widget 
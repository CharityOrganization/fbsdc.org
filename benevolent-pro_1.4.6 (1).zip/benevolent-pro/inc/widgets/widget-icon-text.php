<?php
/**
 * Icon Text Widget
 *
 * @package Benevolent_Pro
 */

// register Benevolent_Pro_Icon_Text_Widget widget
function benevolent_pro_register_icon_text_widget(){
    register_widget( 'Benevolent_Pro_Icon_Text_Widget' );
}
add_action('widgets_init', 'benevolent_pro_register_icon_text_widget');
 
 /**
 * Adds Benevolent_Pro_Icon_Text_Widget widget.
 */
class Benevolent_Pro_Icon_Text_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
			'benevolent_pro_icon_text_widget', // Base ID
			__( 'RARA: Icon Text Widget', 'benevolent-pro' ), // Name
			array( 'description' => __( 'An Icon Text Widget.', 'benevolent-pro' ), ) // Args
		);
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        
        $title   = ! empty( $instance['title'] ) ? $instance['title'] : '' ;		
        $content = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $link    = ! empty( $instance['link'] ) ? $instance['link'] : '';
        $icon    = ! empty( $instance['icon'] ) ? $instance['icon'] : '';
        $image   = ! empty( $instance['image'] ) ? $instance['image'] : '';
        $style   = ! empty( $instance['style'] ) ? $instance['style'] : 'style1';

        echo $args['before_widget']; 
                
        //if( is_page_template( 'templates/template-about.php' ) && $args['id'] == 'about-profile' ) echo 'about-profile'; /* SIDEBAR SPECIFIC CONTENT */
        ?>
        
            <div class="col <?php echo esc_attr( $style ); ?>">
				
                <?php if( $image ){ ?>
                    <div class="icon-holder">
                        <?php 
                            if( $link ) echo '<a href="' . esc_url( $link ) . '">'; 
                                echo wp_get_attachment_image( $image, 'full', false, array( 'alt' => esc_html( $title ))); 
                            if( $link ) echo '</a>'; 
                        ?>
                    </div>
                <?php }elseif( $icon ){ ?>
                    <div class="icon-holder">
                        <?php if( $link ) echo '<a href="' . esc_url( $link ) . '">'; ?>
                            <span class="<?php echo esc_attr( $icon ); ?>"></span>
                        <?php if( $link ) echo '</a>'; ?>
                    </div>
                <?php }?>
    
                <div class="text-holder">
                <?php 
                    if( $title ) {
                        if( $link ) echo '<a href="' . esc_url( $link ) . '">'; 
                            echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title'];
                        if( $link ) echo '</a>'; 
                    }
                    if( $content ) echo wpautop( wp_kses_post( $content ) );
                ?>								
				</div>
                
			</div>
        <?php    
        echo $args['after_widget'];
    }

    /**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        $title   = ! empty( $instance['title'] ) ? $instance['title'] : '' ;		
        $content = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $link    = ! empty( $instance['link'] ) ? $instance['link'] : '';
        $icon    = ! empty( $instance['icon'] ) ? $instance['icon'] : '';
        $image   = ! empty( $instance['image'] ) ? $instance['image'] : '';
        $style   = ! empty( $instance['style'] ) ? $instance['style'] : 'style1';
        
        ?>
		
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'benevolent-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />            
		</p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Content', 'benevolent-pro' ); ?></label>
            <textarea name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php print $content; ?></textarea>
        </p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link', 'benevolent-pro' ); ?></label>
            <input id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_url( $link ); ?>" />
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Select Style', 'benevolent-pro' ); ?></label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>" class="widefat">
				<option value="style1" <?php selected( 'style1', $style ) ?>><?php esc_html_e( 'Style 1', 'benevolent-pro' ); ?></option>
				<option value="style2" <?php selected( 'style2', $style ) ?>><?php esc_html_e( 'Style 2', 'benevolent-pro' ); ?></option>				
			</select>
		</p>
        
        <?php benevolent_pro_get_image_field( $this->get_field_id( 'image' ), $this->get_field_name( 'image' ), $image, __( 'Upload Image', 'benevolent-pro' ) ); ?>
        
        <p><strong><?php esc_html_e( 'or', 'benevolent-pro' ); ?></strong></p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>"><?php esc_html_e( 'Icons', 'benevolent-pro' ); ?></label><br />
            <?php 
                $class = "";
                if( isset($icon) && $icon!='' )
                {
                    $class = "yes";
                }
            ?>
            <span class="icon-receiver <?php echo $class;?>"><i class="<?php echo esc_attr( $icon ); ?>"></i></span>
            <input class="hidden-icon-input" name="<?php echo esc_attr( $this->get_field_name( 'icon' ) ); ?>" type="hidden" id="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>" value="<?php echo esc_attr( $icon ); ?>" />            
        </p>
        
        <?php benevolent_pro_get_icon_list(); ?>
                        
        <?php
	}
    
    /**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
        $instance['title']   = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '' ;
        $instance['content'] = ! empty( $new_instance['content'] ) ? wp_kses_post( $new_instance['content'] ) : '';
        $instance['link']    = ! empty( $new_instance['link'] ) ? esc_url_raw( $new_instance['link'] ) : '';
        $instance['style']   = ! empty( $new_instance['style'] ) ? esc_attr( $new_instance['style'] ) : 'style1';        
        $instance['image']   = ! empty( $new_instance['image'] ) ? absint( $new_instance['image'] ) : '';
        $instance['icon']    = ! empty( $new_instance['icon'] ) ? esc_attr( $new_instance['icon'] ) : '';
        
        return $instance;
	}
    
}  // class Benevolent_Pro_Icon_Text_Widget 
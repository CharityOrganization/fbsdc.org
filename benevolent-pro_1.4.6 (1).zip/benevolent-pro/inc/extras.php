<?php
/**
 * Custom functions that act independently of the theme templates.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Benevolent_Pro
 */

if ( ! function_exists( 'benevolent_pro_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function benevolent_pro_posted_on() {
	
    $post_meta = get_theme_mod( 'benevolent_pro_post_meta', array( 'date', 'author', 'comment' ) );
    
    if( $post_meta ){
    	echo '<div class="entry-meta">';
    
        foreach( $post_meta as $meta ){
            benevolent_pro_post_meta( $meta );        
        }   
        
        echo '</div>'; // WPCS: XSS OK.
    }
    
}
endif;

if( ! function_exists( 'benevolent_pro_post_meta' ) ) :
/**
 * Post meta function 
*/
function benevolent_pro_post_meta( $meta ){
    
    switch( $meta ){
        case 'date': //Date
        
        $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	
    	$time_string = sprintf( $time_string,
    		esc_attr( get_the_date( 'c' ) ),
    		esc_html( get_the_date() )
    	);
        
        echo '<span class="posted-on"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a></span>';
        break;
        
        case 'author': //Author
        
        echo '<span class="byline" itemprop="author" itemscope itemtype="https://schema.org/Person"><span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span></span>';
        break;
        
        case 'comment': //Comment
        
        if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
    		echo '<span class="comments-link">';
    		comments_popup_link( esc_html__( 'Leave a comment', 'benevolent-pro' ), esc_html__( '1 Comment', 'benevolent-pro' ), esc_html__( '% Comments', 'benevolent-pro' ) );
    		echo '</span>';
    	}
        
        break;
    }
}
endif;

if( ! function_exists( 'benevolent_pro_cat_tag' ) ) :
/**
 * Categories and Tags
*/
function benevolent_pro_cat_tag(){
    
    $cat_tag = get_theme_mod( 'benevolent_pro_cat_tag', array( 'cat', 'tag' ) );
    
    // Hide category and tag text for pages.
	if ( 'post' === get_post_type() && $cat_tag ) {
		echo '<div class="tags-block">';
            foreach( $cat_tag as $c ){
                benevolent_pro_tax( $c );
            }            
        echo '</div>';		
	}
}
endif;

if( ! function_exists( 'benevolent_pro_tax' ) ) :
/**
 * List Cat and Tags
*/
function benevolent_pro_tax( $tax ){
    switch( $tax ){
        
        case 'cat':
        
        /* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'benevolent-pro' ) );		
        
        if ( $categories_list && benevolent_pro_categorized_blog() ) {
			printf( '<span class="cat-links"><span class="fa fa-folder-open"></span>' . esc_html__( 'Categories: %1$s', 'benevolent-pro' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		}
        
        break;
        
        case 'tag':
        
        /* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_html__( ', ', 'benevolent-pro' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links"><span class="fa fa-tags"></span>' . esc_html__( 'Tags: %1$s', 'benevolent-pro' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		}
        
        break;
    }    
}
endif;

if ( ! function_exists( 'benevolent_pro_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function benevolent_pro_entry_footer() {
	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'benevolent-pro' ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function benevolent_pro_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'benevolent_pro_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'benevolent_pro_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so benevolent_pro_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so benevolent_pro_categorized_blog should return false.
		return false;
	}
}

if( ! function_exists( 'benevolent_pro_excerpt' ) ):  
/**
 * benevolent_pro_excerpt can truncate a string up to a number of characters while preserving whole words and HTML tags
 *
 * @param string $text String to truncate.
 * @param integer $length Length of returned string, including ellipsis.
 * @param string $ending Ending to be appended to the trimmed string.
 * @param boolean $exact If false, $text will not be cut mid-word
 * @param boolean $considerHtml If true, HTML tags would be handled correctly
 *
 * @return string Trimmed string.
 * 
 * @link http://alanwhipple.com/2011/05/25/php-truncate-string-preserving-html-tags-words/
 */
function benevolent_pro_excerpt($text, $length = 100, $ending = '...', $exact = false, $considerHtml = true) {
	$text = strip_shortcodes( $text );
    $text = benevolent_pro_strip_single( 'img', $text );
    $text = benevolent_pro_strip_single( 'a', $text );
    
    if ($considerHtml) {
		// if the plain text is shorter than the maximum length, return the whole text
		if (strlen(preg_replace('/<.*?>/', '', $text)) <= $length) {
			return $text;
		}
		// splits all html-tags to scanable lines
		preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);
		$total_length = strlen($ending);
		$open_tags = array();
		$truncate = '';
		foreach ($lines as $line_matchings) {
			// if there is any html-tag in this line, handle it and add it (uncounted) to the output
			if (!empty($line_matchings[1])) {
				// if it's an "empty element" with or without xhtml-conform closing slash
				if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
					// do nothing
				// if tag is a closing tag
				} else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
					// delete tag from $open_tags list
					$pos = array_search($tag_matchings[1], $open_tags);
					if ($pos !== false) {
					unset($open_tags[$pos]);
					}
				// if tag is an opening tag
				} else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
					// add tag to the beginning of $open_tags list
					array_unshift($open_tags, strtolower($tag_matchings[1]));
				}
				// add html-tag to $truncate'd text
				$truncate .= $line_matchings[1];
			}
			// calculate the length of the plain text part of the line; handle entities as one character
			$content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
			if ($total_length+$content_length> $length) {
				// the number of characters which are left
				$left = $length - $total_length;
				$entities_length = 0;
				// search for html entities
				if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
					// calculate the real length of all entities in the legal range
					foreach ($entities[0] as $entity) {
						if ($entity[1]+1-$entities_length <= $left) {
							$left--;
							$entities_length += strlen($entity[0]);
						} else {
							// no more characters left
							break;
						}
					}
				}
				$truncate .= substr($line_matchings[2], 0, $left+$entities_length);
				// maximum lenght is reached, so get off the loop
				break;
			} else {
				$truncate .= $line_matchings[2];
				$total_length += $content_length;
			}
			// if the maximum length is reached, get off the loop
			if($total_length>= $length) {
				break;
			}
		}
	} else {
		if (strlen($text) <= $length) {
			return $text;
		} else {
			$truncate = substr($text, 0, $length - strlen($ending));
		}
	}
	// if the words shouldn't be cut in the middle...
	if (!$exact) {
		// ...search the last occurance of a space...
		$spacepos = strrpos($truncate, ' ');
		if (isset($spacepos)) {
			// ...and cut the text in this position
			$truncate = substr($truncate, 0, $spacepos);
		}
	}
	// add the defined ending to the text
	$truncate .= $ending;
	if($considerHtml) {
		// close all unclosed html-tags
		foreach ($open_tags as $tag) {
			$truncate .= '</' . $tag . '>';
		}
	}
	return $truncate;
}
endif; // End function_exists

/**
 * Strip specific tags from string
 * @link http://www.altafweb.com/2011/12/remove-specific-tag-from-php-string.html
*/
function benevolent_pro_strip_single( $tag, $string ){
    $string = preg_replace('/<'.$tag.'[^>]*>/i', '', $string);
    $string = preg_replace('/<\/'.$tag.'>/i', '', $string);
    return $string;
} 

if( ! function_exists( 'benevolent_pro_theme_comment' ) ) :
/**
 * Callback function for Comment List 
 * 
 * @link https://codex.wordpress.org/Function_Reference/wp_list_comments 
 */
function benevolent_pro_theme_comment($comment, $args, $depth){
	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
?>
	<<?php echo $tag ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	<?php if ( 'div' != $args['style'] ) : ?>
	<div id="div-comment-<?php comment_ID() ?>" class="comment-body" itemscope itemtype="https://schema.org/UserComments">
	<?php endif; ?>
	
    <footer class="comment-meta">    
        <div class="comment-author vcard">
    	<?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
    	<?php printf( __( '<b class="fn" itemprop="creator" itemscope itemtype="https://schema.org/Person">%s</b>', 'benevolent-pro' ), get_comment_author_link() ); ?>
    	</div>
    	<?php if ( $comment->comment_approved == '0' ) : ?>
    		<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'benevolent-pro' ); ?></em>
    		<br />
    	<?php endif; ?>
    
    	<div class="comment-metadata commentmetadata">
            <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
                <time datetime="<?php comment_date(); ?>"><?php echo get_comment_date(); ?></time>
            </a>
            <?php edit_comment_link( __( '(Edit)', 'benevolent-pro' ), '  ', '' ); ?>
    	</div>
    </footer>
    
    <div class="comment-content"><?php comment_text(); ?></div>

	<div class="reply">
	<?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
	</div>
	<?php if ( 'div' != $args['style'] ) : ?>
	</div>
	<?php endif; ?>
<?php
}
endif;

if( ! function_exists( 'benevolent_pro_intro_helper' ) ) :
/**
 * Helper function for listing Intro section
*/
function benevolent_pro_intro_helper( $image, $logo, $title, $link, $url, $new_tab ){
    
    if( $image ){
        $img = wp_get_attachment_image_src( $image, 'full' );
        $log = wp_get_attachment_image_src( $logo, 'full' );
        
        echo '<div class="columns-3">';
        echo '<div class="img-holder"><img src="' . esc_url( $img[0] ) . '" alt="' . esc_attr( $title ) . '" /></div>';
        
        if( $log ) echo '<div class="icon-holder"><img src="' . esc_url( $log[0] ) .'" alt="' . esc_attr( $title ) . '" /></div>';
        
		if( $title || $url ){ 
            echo '<div class="text-holder">';
            $target = $new_tab ?  ' target="_blank"' : '';

			if( $title ) echo '<strong class="title">' . esc_html( $title ) . '</strong>'; 
			if( $url && $link ) echo '<a class="btn" href="' . esc_url( $url ) . '"'. $target .'>' . esc_html( $link ) . '<span class="fa fa-angle-right"></span></a>';
            echo '</div>';
        } 
        echo '</div>';
    }
    
}
endif;

if( ! function_exists( 'benevolent_pro_logo_helper' ) ) :
/**
 * Helper function for listing stat counter
*/
function benevolent_pro_logo_helper( $title, $content, $cat ){
    $child_theme = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );

    if( $title || $content || $cat ){ ?>
    
        <section id="sponser-section" class="donors">
        	<div class="container">
        		
                <?php 
                
                    if( $title || $content ){
                        echo '<header class="heading">';
                        if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                        if( $content ) echo wpautop( wp_kses_post( $content ) );
                        echo '</header>';      
                    }            
                
                    $args = array(
                        'post_type'     => 'logo', 
                        'post_status'   => 'publish',
                        'posts_per_page'=> -1,
                        'tax_query'     => array(
	                    		array(
	                    			'taxonomy' => 'logo-category',
	                    			'field'    => 'term_id',
	                    			'terms'    => $cat,
	                    		),
	                    	),
                    );
                    
                    $qry = new WP_Query( $args );
                    
                    if( $qry->have_posts() ){
                        if( $child_theme != 'revive-charity' ) echo '<div id="donor-slider" class="owl-carousel">';
                        if( $child_theme == 'revive-charity' ) echo '<div class="row">';
                        
                        while( $qry->have_posts() ){
                            $qry->the_post();
                            $link = get_post_meta( get_the_ID(), '_benevolent_pro_logo_link', true );
                            
                            if( has_post_thumbnail() ){
                                echo '<div class="donor-item">';
                                if( $link ) echo '<a href="' . esc_url( $link ) . '" target="_blank" title="' . esc_html( get_the_title() ) . '">';
                                the_post_thumbnail( 'full', array( 'itemprop' => 'image' ) );
                                if( $link ) echo '</a>';
                                echo '</div>';          
                            }
                            
                        }

                        if( $child_theme == 'revive-charity' ) echo '</div>';
                        if( $child_theme != 'revive-charity' ) echo '</div>';
                        
                        wp_reset_postdata();
                    }
                ?>
        			
        	</div>
        </section>
    <?php }
}
endif;

/**
 * Function to list Custom Pattern
*/
function benevolent_pro_get_patterns(){
    $patterns = array();
    $patterns['nobg'] = get_template_directory_uri() . '/images/patterns_thumb/' . 'nobg.png';
    for( $i=0; $i<38; $i++ ){
        $patterns['pattern'.$i] = get_template_directory_uri() . '/images/patterns_thumb/' . 'pattern' . $i .'.png';
    }
    for( $j=1; $j<26; $j++ ){
        $patterns['hbg'.$j] = get_template_directory_uri() . '/images/patterns_thumb/' . 'hbg' . $j . '.png';
    }
    return $patterns;
}

/**
 * Function to list dynamic sidebar
*/
function benevolent_pro_get_dynamnic_sidebar( $nosidebar = false, $sidebar = false, $default = false ){
    $sidebar_arr = array();
    $sidebars = get_theme_mod( 'benevolent_pro_sidebar' );
    
    if( $default ) $sidebar_arr['default-sidebar'] = __( 'Default Sidebar', 'benevolent-pro' );
    if( $sidebar ) $sidebar_arr['sidebar'] = __( 'Sidebar', 'benevolent-pro' );
    
    if( $sidebars ){
        foreach( $sidebars as $sidebar ){
            $sidebar_arr[$sidebar['id']] = $sidebar['name'];
        }
    }
    
    if( $nosidebar ) $sidebar_arr['no-sidebar'] = __( 'No Sidebar', 'benevolent-pro' );
    
    return $sidebar_arr;
}

if( ! function_exists( 'benevolent_pro_social_icons' ) ) :
/**
 * Function to populate list of social Icons
*/
function benevolent_pro_social_icons(){
    $social_icons = array();
    
	$social_icons['dribbble']      = __( 'Dribbble', 'benevolent-pro' );
	$social_icons['facebook']      = __( 'Facebook', 'benevolent-pro' );
	$social_icons['foursquare']    = __( 'Foursquare', 'benevolent-pro' );
	$social_icons['flickr']        = __( 'Flickr', 'benevolent-pro' );
	$social_icons['google-plus']   = __( 'Google Plus', 'benevolent-pro' );
	$social_icons['instagram']     = __( 'Instagram', 'benevolent-pro' );
	$social_icons['linkedin']      = __( 'LinkedIn', 'benevolent-pro' );
	$social_icons['pinterest']     = __( 'Pinterest', 'benevolent-pro' );
	$social_icons['reddit']        = __( 'Reddit', 'benevolent-pro' );
	$social_icons['skype']         = __( 'Skype', 'benevolent-pro' );
	$social_icons['stumbleupon']   = __( 'StumbleUpon', 'benevolent-pro' );
	$social_icons['tumblr']        = __( 'Tumblr', 'benevolent-pro' );
	$social_icons['twitter']       = __( 'Twitter', 'benevolent-pro' );
	$social_icons['vimeo']         = __( 'Vimeo', 'benevolent-pro' );
	$social_icons['youtube']       = __( 'YouTube', 'benevolent-pro' );
	$social_icons['odnoklassniki'] = __( 'OK', 'benevolent-pro' );
	$social_icons['vk']            = __( 'VK', 'benevolent-pro' );
	$social_icons['xing']          = __( 'Xing', 'benevolent-pro' );
	$social_icons['medium']        = __( 'Medium', 'benevolent-pro' );
	$social_icons['snapchat']      = __( 'Snapchat', 'benevolent-pro' );
	$social_icons['tiktok']        = __( 'Tiktok', 'benevolent-pro' );
	$social_icons['mastodon']      = __( 'Mastodon', 'benevolent-pro' );

    return $social_icons;
}
endif;

/**
 * List out font awesome icon list
*/
function benevolent_pro_get_icon_list(){
    $fontawesome = include get_template_directory() . '/inc/fontawesome.php'; ?>
    <input type="text" class="rrtc-search-icon" placeholder="<?php _e( 'Search Icon','benevolent-pro' );?>">
    <?php
    echo '<div class="rara-font-awesome-list"><ul class="rara-font-group">';
    foreach( $fontawesome as $font ){
        echo '<li><i class="fa ' . esc_attr( $font ) . '"></i></li>';
    }
    echo '</ul></div>';    
}

/**
 * Helper Function for Image widget
*/
function benevolent_pro_get_image_field( $id, $name, $image, $label ){
    
    $output = '';
    
    $output .= '<div class="widget-upload">';
    $output .= '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><br/>';
    $output .= '<input id="' . esc_attr( $id ) . '" class="rara-upload" type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $image ) . '" placeholder="' . __('No file chosen', 'benevolent-pro') . '" />' . "\n";
    if ( function_exists( 'wp_enqueue_media' ) ) {
        if ( $image == '' ) {
            $output .= '<input id="upload-' . esc_attr( $id ) . '" class="rara-upload-button button" type="button" value="' . __('Upload', 'benevolent-pro') . '" />' . "\n";
        } else {
            $output .= '<input id="upload-' . esc_attr( $id ) . '" class="rara-upload-button button" type="button" value="' . __('Change', 'benevolent-pro') . '" />' . "\n";
        }
    } else {
        $output .= '<p><i>' . __('Upgrade your version of WordPress for full media support.', 'benevolent-pro') . '</i></p>';
    }

    $output .= '<div class="rara-screenshot" id="' . esc_attr( $id ) . '-image">' . "\n";
    if ( $image != '' ) {
        $remove = '<a class="rara-remove-image"></a>';
        $attachment_id =  $image;
        $image_array = wp_get_attachment_image_src( $attachment_id, 'full');
        if ( $image_array && $image ) {
            $output .= '<img src="' . esc_url( $image_array[0] ) . '" alt="" />' . $remove;
        } else {
            // Standard generic output if it's not an image.
            $output .= '<small>' . __( 'Please upload valid image file.', 'benevolent-pro' ) . '</small>';
        }     
    }
    $output .= '</div></div>' . "\n";
    
    echo $output;
}

if( ! function_exists( 'benevolent_pro_navigation_menu_primary' ) ) :
/**
 * Primary Menu Navigation
*/
function benevolent_pro_navigation_menu_primary( $schema = true, $primary_nav_id = 'site-navigation' ) {
	$schema_class = '';
    $nav_id       = '';

    if( $schema ){
        $schema_class = ' itemscope itemtype="https://schema.org/SiteNavigationElement"';
    }

    if( $primary_nav_id ){
        $nav_id = ' id="'. $primary_nav_id . '"';
    }
	?>
	<nav<?php echo $nav_id; ?> class="main-navigation" role="navigation"<?php echo $schema_class; ?>>
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
	</nav><!-- #site-navigation -->
	<?php
}
endif;

if( ! function_exists( 'benevolent_pro_navigation_menu_secondary' ) ) :
/**
 * Secondary Menu Navigation
*/
function benevolent_pro_navigation_menu_secondary( $schema = true, $secondary_nav_id = 'top-navigation') { 
	$schema_class = '';
    $nav_id       = '';

    if( $schema ){
        $schema_class = ' itemscope itemtype="https://schema.org/SiteNavigationElement"';
    }

    if( $secondary_nav_id ){
        $nav_id = ' id="'. $secondary_nav_id . '"';
    }
	?>     
    <nav <?php echo $nav_id; ?> class="secondary-navigation" role="navigation"<?php echo $schema_class; ?>>
		<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'secondary-menu', 'fallback_cb' => false ) ); ?>
	</nav><!-- #top-navigation -->
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_header_search' ) ) :
/**
 * Header search
*/
function benevolent_pro_header_search() { ?>     
    <div class="search">
		<button class="search-toggle-btn"><i class="fa fa-search"></i></button>
		<div class="form-holder">
			<?php get_search_form(); ?>
		</div>
	</div>
    <?php
}
endif;

if( ! function_exists( 'benevolent_pro_get_social_links' ) ) :
/**
 * Callback for Social Links  
*/
function benevolent_pro_get_social_links( $contact = false ){
    
    $social_ar = get_theme_mod( 'benevolent_pro_social_contact', array( 'facebook', 'twitter', 'pinterest', 'linkedin', 'google-plus' ) );
    
    $social_icons = get_theme_mod( 'benevolent_pro_social', array(
    		array(
    			'icon' => 'facebook',
    			'link' => 'https://facebook.com',
    		),
    		array(
    			'icon' => 'twitter',
    			'link' => 'https://twitter.com',
    		),
        ) );
        
    if( $contact ){
        $contact_icons = array();
        foreach( $social_ar as $s ){
            foreach( $social_icons as $i ){
                if( $s == $i['icon'] ){
                    array_push( $contact_icons, array( 'icon' => $i['icon'], 'link' => $i['link'] ) );
                }
            }
        }
        $socials = $contact_icons;            
    }else{
        $socials = $social_icons;
    }
    
    if( $socials ){ ?>
        <ul class="social-networks">
        <?php 
        foreach( $socials as $social ){
            if( $social['link'] ){ 
                $parse_url = wp_parse_url( $social['link'] );
                if( $parse_url && isset( $parse_url['host'] ) && ( $parse_url['host'] === 'plus.google.com' ) )
                $social['link'] = str_replace( '%20', '+', $social['link'] ); ?>
                <li><a href="<?php echo esc_url( $social['link'] ); ?>" <?php if( $social['icon'] != 'skype' ) echo 'target="_blank"'; ?> title="<?php echo esc_attr( $social['icon'] ); ?>"><span class="fab fa-<?php echo esc_attr( $social['icon'] );?>"></span></a></li>
            <?php 
            }             
        } ?>
        </ul>
        <?php
    }
}
endif;

/**
 *  Custom Pagination
*/
function benevolent_pro_pagination(){
    
    $pagination = get_theme_mod( 'benevolent_pro_pagination_type', 'default' );
    
    switch( $pagination ){
        case 'default': // Default Pagination
        
        the_posts_navigation();
        
        break;
        
        case 'numbered': // Numbered Pagination
        
        the_posts_pagination( array(
            'prev_text'          => '',
            'next_text'          => '',
            'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'benevolent-pro' ) . ' </span>',
         ) );
        
        break;
        
        case 'load_more': // Load More Button
        case 'infinite_scroll': // Auto Infinite Scroll
        
        echo '<div class="pagination"></div>';
        
        break;
        
        default:
        
        the_posts_navigation();
        
        break;
    }
       
}

if( ! function_exists( 'benevolent_pro_sidebar' ) ) :
/**
 * Function to retrive page specific sidebar and corresponding body class
 * 
 * @param boolean $sidebar
 * @param boolean $class
 * 
 * @return string dynamic sidebar id / classname
*/
function benevolent_pro_sidebar( $sidebar = false, $class = false ){
    
    global $post;
    $return = false;
    
    if( ( is_front_page() && is_home() ) || is_home() ){
        //blog/home page 
        $blog_sidebar = get_theme_mod( 'benevolent_pro_blog_page_sidebar', 'sidebar' );
        $layout       = get_theme_mod( 'benevolent_pro_layout_style', 'right-sidebar' ); //Default Layout Style for Styling Settings
        
        if( is_active_sidebar( $blog_sidebar ) ){            
            if( $sidebar ) $return = $blog_sidebar; //With Sidebar
            if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; 
            if( $class && $layout == 'left-sidebar' )  $return = 'leftsidebar';
        }else{
            if( $sidebar ) $return = false; //Fullwidth
            if( $class ) $return = 'full-width';
        }        
    }
    
    if( is_archive() ){
        //archive page
        $archive_sidebar = get_theme_mod( 'benevolent_pro_archive_page_sidebar', 'sidebar' );
        $cat_sidebar     = get_theme_mod( 'benevolent_pro_cat_archive_page_sidebar', 'default-sidebar' );
        $tag_sidebar     = get_theme_mod( 'benevolent_pro_tag_archive_page_sidebar', 'default-sidebar' );
        $date_sidebar    = get_theme_mod( 'benevolent_pro_date_archive_page_sidebar', 'default-sidebar' );
        $author_sidebar  = get_theme_mod( 'benevolent_pro_author_archive_page_sidebar', 'default-sidebar' );
        $layout          = get_theme_mod( 'benevolent_pro_layout_style', 'right-sidebar' );
        
        if( is_category() ){
            
            if( $cat_sidebar == 'no-sidebar' || ( $cat_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }elseif( $cat_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ){
                if( $sidebar ) $return = $archive_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }elseif( is_active_sidebar( $cat_sidebar ) ){
                if( $sidebar ) $return = $cat_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }
                
        }elseif( is_tag() ){
            
            if( $tag_sidebar == 'no-sidebar' || ( $tag_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }elseif( ( $tag_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                if( $sidebar ) $return = $archive_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }elseif( is_active_sidebar( $tag_sidebar ) ){
                if( $sidebar ) $return = $tag_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';              
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }
            
        }elseif( is_author() ){
            
            if( $author_sidebar == 'no-sidebar' || ( $author_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }elseif( ( $author_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                if( $sidebar ) $return = $archive_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }elseif( is_active_sidebar( $author_sidebar ) ){
                if( $sidebar ) $return = $author_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }
            
        }elseif( is_date() ){
            
            if( $date_sidebar == 'no-sidebar' || ( $date_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }elseif( ( $date_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                if( $sidebar ) $return = $archive_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }elseif( is_active_sidebar( $date_sidebar ) ){
                if( $sidebar ) $return = $date_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }                         
            
        }else{
            if( $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ){
                if( $sidebar ) $return = $archive_sidebar;
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }                      
        }
        
    }
    
    if( is_singular() ){
        $post_sidebar = get_theme_mod( 'benevolent_pro_single_post_sidebar', 'sidebar' );
        $page_sidebar = get_theme_mod( 'benevolent_pro_single_page_sidebar', 'sidebar' );
        $layout       = get_theme_mod( 'benevolent_pro_layout_style', 'right-sidebar' );
        
        if( get_post_meta( $post->ID, '_benevolent_pro_sidebar', true ) ){
            $single_sidebar = get_post_meta( $post->ID, '_benevolent_pro_sidebar', true );
        }else{
            $single_sidebar = 'default-sidebar';
        }

        if( get_post_meta( $post->ID, '_benevolent_pro_sidebar_layout', true ) ){
            $sidebar_layout = get_post_meta( $post->ID, '_benevolent_pro_sidebar_layout', true );
        }else{
            $sidebar_layout = 'default-sidebar';
        }
        
        if( is_give_activated() && is_singular( 'give_forms' ) ){
            
            $sidebar_option = give_get_option( 'disable_form_sidebar' );
    
            if( is_active_sidebar( 'give-forms-sidebar' ) && $sidebar_option !== 'on' ){
                if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar';
                if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
            }else{
                if( $class ) $return = 'full-width';
            }
            
        }elseif( is_page() ){
            
            if( is_page_template( 'templates/template-home.php' ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }else{
                if( ( $single_sidebar == 'no-sidebar' ) || ( ( $single_sidebar == 'default-sidebar' ) && ( $page_sidebar == 'no-sidebar' ) ) ){
                    if( $sidebar ) $return = false; //Fullwidth
                    if( $class ) $return = 'full-width';
                }elseif( $single_sidebar == 'default-sidebar' && $page_sidebar != 'no-sidebar' && is_active_sidebar( $page_sidebar ) ){
                    if( $sidebar ) $return = $page_sidebar;
                    if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ) ) $return = 'rightsidebar';
                    if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ) ) $return = 'leftsidebar';
                }elseif( is_active_sidebar( $single_sidebar ) ){
                    if( $sidebar ) $return = $single_sidebar;
                    if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ) ) $return = 'rightsidebar';
                    if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ) ) $return = 'leftsidebar';
                }else{
                    if( $sidebar ) $return = false; //Fullwidth
                    if( $class ) $return = 'full-width';
                }
            }
        }elseif( is_single() ){
            
            if( ( $single_sidebar == 'no-sidebar' ) || ( ( $single_sidebar == 'default-sidebar' ) && ( $post_sidebar == 'no-sidebar' ) ) ){
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }elseif( $single_sidebar == 'default-sidebar' && $post_sidebar != 'no-sidebar' && is_active_sidebar( $post_sidebar ) ){
                if( $sidebar ) $return = $post_sidebar;
                if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ) ) $return = 'rightsidebar';
                if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ) ) $return = 'leftsidebar';
            }elseif( is_active_sidebar( $single_sidebar ) ){
                if( $sidebar ) $return = $single_sidebar;
                if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ) ) $return = 'rightsidebar';
                if( $class && ( ( $sidebar_layout == 'default-sidebar' && $layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ) ) $return = 'leftsidebar';
            }else{
                if( $sidebar ) $return = false; //Fullwidth
                if( $class ) $return = 'full-width';
            }
        }
    }
    
    if( is_search() ){
        $search_sidebar = get_theme_mod( 'benevolent_pro_search_page_sidebar', 'sidebar' );
        $layout         = get_theme_mod( 'benevolent_pro_layout_style', 'right-sidebar' );
        
        if( $search_sidebar != 'no-sidebar' && is_active_sidebar( $search_sidebar ) ){
            if( $sidebar ) $return = $search_sidebar;
            if( $class && $layout == 'right-sidebar' ) $return = 'rightsidebar'; //With Sidebar
            if( $class && $layout == 'left-sidebar' ) $return = 'leftsidebar';
        }else{
            if( $sidebar ) $return = false; //Fullwidth
            if( $class ) $return = 'full-width';
        }
        
    }
    
    return $return;        
}
endif;

/**
 * Function to get the post view count 
 */
function benevolent_pro_get_views( $post_id ){
    $count_key = '_benevolent_pro_view_count';
    $count = get_post_meta( $post_id, $count_key, true );
    if( $count == '' ){        
        return __( "0 View", 'benevolent-pro' );
    }elseif($count<=1){
        return $count. __(' View', 'benevolent-pro' );
    }else{
        return $count. __(' Views', 'benevolent-pro' );    
    }    
}

/**
 * Function to add the post view count 
 */
function benevolent_pro_set_views( $post_id ) {
    $count_key = '_benevolent_pro_view_count';
    $count = get_post_meta( $post_id, $count_key, true );
    if( $count == '' ){
        $count = 0;
        delete_post_meta( $post_id, $count_key );
        add_post_meta( $post_id, $count_key, '1' );
    }else{
        $count++;
        update_post_meta( $post_id, $count_key, $count );
    }
}

if( ! function_exists( 'benevolent_pro_change_comment_form_default_fields' ) ) :
/**
 * Change Comment form default fields i.e. author, email & url.
 * https://blog.josemcastaneda.com/2016/08/08/copy-paste-hurting-theme/
*/
function benevolent_pro_change_comment_form_default_fields( $fields ){    
    // get the current commenter if available
    $commenter = wp_get_current_commenter();
 
    // core functionality
    $req      = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true'" : '' );
    $required = ( $req ? " required" : '' );
    $author   = ( $req ? __( 'Name*', 'benevolent-pro' ) : __( 'Name', 'benevolent-pro' ) );
    $email    = ( $req ? __( 'Email*', 'benevolent-pro' ) : __( 'Email', 'benevolent-pro' ) );
 
    // Change just the author field
    $fields['author'] = '<p class="comment-form-author"><label class="screen-reader-text" for="author">' . esc_html__( 'Name', 'benevolent-pro' ) . '<span class="required">*</span></label><input id="author" name="author" placeholder="' . esc_attr( $author ) . '" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . $required . ' /></p>';
    
    $fields['email'] = '<p class="comment-form-email"><label class="screen-reader-text" for="email">' . esc_html__( 'Email', 'benevolent-pro' ) . '<span class="required">*</span></label><input id="email" name="email" placeholder="' . esc_attr( $email ) . '" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . $required. ' /></p>';
    
    $fields['url'] = '<p class="comment-form-url"><label class="screen-reader-text" for="url">' . esc_html__( 'Website', 'benevolent-pro' ) . '</label><input id="url" name="url" placeholder="' . esc_attr__( 'Website', 'benevolent-pro' ) . '" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>'; 
    
    return $fields;    
}
endif;
add_filter( 'comment_form_default_fields', 'benevolent_pro_change_comment_form_default_fields' );

if( ! function_exists( 'benevolent_pro_change_comment_form_defaults' ) ) :
/**
 * Change Comment Form defaults
 * https://blog.josemcastaneda.com/2016/08/08/copy-paste-hurting-theme/
*/
function benevolent_pro_change_comment_form_defaults( $defaults ){    
    $defaults['comment_field'] = '<p class="comment-form-comment"><label class="screen-reader-text" for="comment">' . esc_html__( 'Comment', 'benevolent-pro' ) . '</label><textarea id="comment" name="comment" placeholder="' . esc_attr__( 'Comment', 'benevolent-pro' ) . '" cols="45" rows="8" aria-required="true" required></textarea></p>';
    
    return $defaults;    
}
endif;
add_filter( 'comment_form_defaults', 'benevolent_pro_change_comment_form_defaults' );

/**
 * Query WooCommerce activation
 */
function benevolent_pro_is_woocommerce_activated() {
	return class_exists( 'woocommerce' ) ? true : false;
}

/**
 * Query Contact Form 7
 */
function is_cf7_activated() {
	return class_exists( 'WPCF7' ) ? true : false;
}

/**
 * Query Jetpack activation
*/
function is_jetpack_activated( $gallery = false ){
	if( $gallery ){
        return ( class_exists( 'jetpack' ) && Jetpack::is_module_active( 'tiled-gallery' ) ) ? true : false;
	}else{
        return class_exists( 'jetpack' ) ? true : false;
    }           
}

/**
 * Query if GIVE plugin is activate
*/
function is_give_activated(){
    return class_exists( 'Give' ) ? true : false;
}

/**
 * Query if Rara One Click Demo Import id activate
*/
function is_rocdi_activated(){
    return class_exists( 'RDDI_init' ) ? true : false;
}

/**
 * Query if Elementor Page Builder plugin is activated
*/
function benevolent_pro_is_elementor_activated(){
    return class_exists( 'Elementor\\Plugin' ) ? true : false; 
}
/**
 * Query if Current post is edited by Elementor Page Builder plugin 
*/
function benevolent_pro_is_elementor_activated_post(){
    if( benevolent_pro_is_elementor_activated() && is_singular() ){
        global $post;
        $post_id = $post->ID;
        return \Elementor\Plugin::$instance->documents->get( $post_id )->is_built_with_elementor() ? true : false;
    }else{
        return false;
    }
}

if ( ! function_exists( 'benevolent_pro_slider_animation_options' ) ) : 
    function benevolent_pro_slider_animation_options(){
        $slider_animation = array(
            'slide'          => esc_html__( 'Slide' , 'benevolent-pro' ),
            'bounceOut'      => esc_html__( 'Bounce Out', 'benevolent-pro' ),
            'bounceOutLeft'  => esc_html__( 'Bounce Out Left', 'benevolent-pro' ),
            'bounceOutRight' => esc_html__( 'Bounce Out Right', 'benevolent-pro' ),
            'bounceOutUp'    => esc_html__( 'Bounce Out Up', 'benevolent-pro' ),
            'bounceOutDown'  => esc_html__( 'Bounce Out Down', 'benevolent-pro' ),
            'fadeOut'        => esc_html__( 'Fade Out', 'benevolent-pro' ),
            'fadeOutLeft'    => esc_html__( 'Fade Out Left', 'benevolent-pro' ),
            'fadeOutRight'   => esc_html__( 'Fade Out Right', 'benevolent-pro' ),
            'fadeOutUp'      => esc_html__( 'Fade Out Up', 'benevolent-pro' ),
            'fadeOutDown'    => esc_html__( 'Fade Out Down', 'benevolent-pro' ),
            'flipOutX'       => esc_html__( 'Flip OutX', 'benevolent-pro' ),
            'flipOutY'       => esc_html__( 'Flip OutY', 'benevolent-pro' ),
            'hinge'          => esc_html__( 'Hinge', 'benevolent-pro' ),
            'pulse'          => esc_html__( 'Pulse', 'benevolent-pro' ),
            'rollOut'        => esc_html__( 'Roll Out', 'benevolent-pro' ),
            'rotateOut'      => esc_html__( 'Rotate Out', 'benevolent-pro' ),
            'rotateOutLeft'  => esc_html__( 'Rotate Out Left', 'benevolent-pro' ),
            'rotateOutRight' => esc_html__( 'Rotate Out Right', 'benevolent-pro' ),
            'rotateOutUp'    => esc_html__( 'Rotate Out Up', 'benevolent-pro' ),
            'rotateOutDown'  => esc_html__( 'Rotate Out Down', 'benevolent-pro' ),
            'rubberBand'     => esc_html__( 'Rubber Band', 'benevolent-pro' ),
            'shake'          => esc_html__( 'Shake', 'benevolent-pro' ),
            'slideOutLeft'   => esc_html__( 'Slide Out Left', 'benevolent-pro' ),
            'slideOutRight'  => esc_html__( 'Slide Out Right', 'benevolent-pro' ),
            'slideOutUp'     => esc_html__( 'Slide Out Up', 'benevolent-pro' ),
            'slideOutDown'   => esc_html__( 'Slide Out Down', 'benevolent-pro' ),
            'swing'          => esc_html__( 'Swing', 'benevolent-pro' ),
            'tada'           => esc_html__( 'Tada', 'benevolent-pro' ),
            'zoomOut'        => esc_html__( 'Zoom Out', 'benevolent-pro' ),
            'zoomOutLeft'    => esc_html__( 'Zoom Out Left', 'benevolent-pro' ),
            'zoomOutRight'   => esc_html__( 'Zoom Out Right', 'benevolent-pro' ),
            'zoomOutUp'      => esc_html__( 'Zoom Out Up', 'benevolent-pro' ),
            'zoomOutDown'    => esc_html__( 'Zoom Out Down', 'benevolent-pro' ),
        );

        return apply_filters( 'benevolent_pro_slider_animation_options', $slider_animation ); 
    }
endif;

if( ! function_exists( 'benevolent_pro_escape_text_tags' ) ) :
/**
 * Remove new line tags from string
 *
 * @param $text
 * @return string
 */
function benevolent_pro_escape_text_tags( $text ) {
    return (string) str_replace( array( "\r", "\n" ), '', strip_tags( $text ) );
}
endif;

if( ! function_exists( 'benevolent_pro_get_page_template_url' ) ) :
/**
 * Returns page template url if not found returns home page url
*/
function benevolent_pro_get_page_template_url( $page_template ){
    $args = array(
        'meta_key'   => '_wp_page_template',
        'meta_value' => $page_template,
        'post_type'  => 'page',
        'fields'     => 'ids',
    );
    
    $posts_array = get_posts( $args );
        
    $url = ( $posts_array ) ? get_permalink( $posts_array[0] ) : get_home_url();
    return $url;    
}
endif;

if( ! function_exists( 'benevolent_pro_get_blog_page_url' ) ) :
/**
 * Returns page url of static blog page if not found returns home page url
*/
function benevolent_pro_get_blog_page_url(){
	$show_on_front    = get_option( 'show_on_front' );
	$blog_page_id     = get_option( 'page_for_posts' );

	if( $show_on_front = 'page' ){
		if( $blog_page_id ){
	        return get_the_permalink( $blog_page_id );
	    }else{
	        return get_home_url();
	    }	
	}else{
        return get_home_url();
	} 
}
endif;

if( ! function_exists( 'benevolent_pro_site_branding' ) ) :
/**
 * Site Branding
*/
function benevolent_pro_site_branding(){ 
	$site_title = get_bloginfo( 'name' );
    $description = get_bloginfo( 'description', 'display' );
    
    if( has_custom_logo() && ( $site_title || $description ) ) {
        $add_class = 'logo-text';
    }else{
        $add_class = '';
    }?>
    <div class="site-branding <?php echo esc_attr( $add_class ); ?>" itemscope itemtype="https://schema.org/Organization">
    
		<?php if( function_exists( 'has_custom_logo' ) && has_custom_logo() ) {
            echo '<div class="site-logo">';
            the_custom_logo();
            echo '</div>';
        } ?>
			<div class="site-title-wrap">
            <?php if ( is_front_page() ) : ?>
                <h1 class="site-title" itemprop="name"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" itemprop="url"><?php bloginfo( 'name' ); ?></a></h1>
            <?php else : ?>
                <p class="site-title" itemprop="name"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" itemprop="url"><?php bloginfo( 'name' ); ?></a></p>
            <?php endif;  
		
			$description = get_bloginfo( 'description', 'display' );
			if ( $description || is_customize_preview() ) : ?>
				<p class="site-description" itemprop="description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
			<?php endif; ?>
        </div>
        
	</div><!-- .site-branding -->
	<?php
}
endif;

if( ! function_exists( 'wp_body_open' ) ) :
/**
 * Fire the wp_body_open action.
 * Added for backwards compatibility to support pre 5.2.0 WordPress versions.
*/
function wp_body_open() {
	/**
	 * Triggered after the opening <body> tag.
    */
	do_action( 'wp_body_open' );
}
endif;

if( ! function_exists( 'benevolent_pro_apply_footer_shortcode' ) ) :
/**
 * Function to add shortcode in footer content
 */
function benevolent_pro_apply_footer_shortcode( $string ) {
    if ( empty( $string ) ) {
        return $string;
    }
    $search = array( '[the-year]', '[the-site-link]' );
    $replace = array(
        date_i18n( __( 'Y', 'benevolent-pro' ) ),
        '<a href="'. esc_url( home_url( '/' ) ) .'">'. esc_html( get_bloginfo( 'name', 'display' ) ) . '</a>',
    );
    $string = str_replace( $search, $replace, $string );
    return $string;
}
endif;

if ( ! function_exists( 'benevolent_pro_iframe_match' ) ) :    
/**
 * Check whether the input parameter send is iframe or Url
*/
function benevolent_pro_iframe_match( $iframe ){
    return preg_match('/<iframe.*src=\"(.*)\".*><\/iframe>/isU', $iframe ) ? true : false;
}
endif;

if( ! function_exists( 'benevolent_pro_get_image_sizes' ) ) :
/**
 * Get information about available image sizes
 */
function benevolent_pro_get_image_sizes( $size = '' ) {
 
    global $_wp_additional_image_sizes;
 
    $sizes = array();
    $get_intermediate_image_sizes = get_intermediate_image_sizes();
 
    // Create the full array with sizes and crop info
    foreach( $get_intermediate_image_sizes as $_size ) {
        if ( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
            $sizes[ $_size ]['width'] = get_option( $_size . '_size_w' );
            $sizes[ $_size ]['height'] = get_option( $_size . '_size_h' );
            $sizes[ $_size ]['crop'] = (bool) get_option( $_size . '_crop' );
        } elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
            $sizes[ $_size ] = array( 
                'width' => $_wp_additional_image_sizes[ $_size ]['width'],
                'height' => $_wp_additional_image_sizes[ $_size ]['height'],
                'crop' =>  $_wp_additional_image_sizes[ $_size ]['crop']
            );
        }
    } 
    // Get only 1 size if found
    if ( $size ) {
        if( isset( $sizes[ $size ] ) ) {
            return $sizes[ $size ];
        } else {
            return false;
        }
    }
    return $sizes;
}
endif;

if ( ! function_exists( 'benevolent_pro_get_fallback_svg' ) ) :    
/**
 * Get Fallback SVG
*/
function benevolent_pro_get_fallback_svg( $post_thumbnail ) {
    if( ! $post_thumbnail ){
        return;
    }
    
    $image_size = benevolent_pro_get_image_sizes( $post_thumbnail );
     
    if( $image_size ){ ?>
        <div class="svg-holder">
             <svg class="fallback-svg" viewBox="0 0 <?php echo esc_attr( $image_size['width'] ); ?> <?php echo esc_attr( $image_size['height'] ); ?>" preserveAspectRatio="none">
                    <rect width="<?php echo esc_attr( $image_size['width'] ); ?>" height="<?php echo esc_attr( $image_size['height'] ); ?>" style="fill:#e2e2e2;"></rect>
            </svg>
        </div>
        <?php
    }
}
endif;

if( ! function_exists( 'benevolent_pro_create_post' ) ) :
/**
 * A function used to programmatically create a post and assign a page template in WordPress. 
 *
 * @link https://tommcfarlin.com/programmatically-create-a-post-in-wordpress/
 * @link https://tommcfarlin.com/programmatically-set-a-wordpress-template/
 */
function benevolent_pro_create_post( $title, $slug, $template ){

	// Setup the author, page
	$author_id = 1;
    
    // Look for the page by the specified title. Set the ID to -1 if it doesn't exist.
    // Otherwise, set it to the page's ID.
    $page = get_page_by_title( $title, OBJECT, 'page' );
    $page_id = ( null == $page ) ? -1 : $page->ID;
    
	// If the page doesn't already exist, then create it
	if( $page_id == -1 ){

		// Set the post ID so that we know the post was created successfully
		$post_id = wp_insert_post(
			array(
				'comment_status' =>	'closed',
				'ping_status'	 =>	'closed',
				'post_author'	 =>	$author_id,
				'post_name'		 =>	$slug,
				'post_title'	 =>	$title,
				'post_status'	 =>	'publish',
				'post_type'		 =>	'page'
			)
		);
        
        if( $post_id ) update_post_meta( $post_id, '_wp_page_template', $template );

	// Otherwise, we'll stop
	}else{
	   update_post_meta( $page_id, '_wp_page_template', $template );
	} // end if

} // end programmatically_create_post
endif;

/**
 * Get an attachment ID given a URL.
 * 
 * @param string $url
 *
 * @return int Attachment ID on success, 0 on failure
 * @link https://wpscholar.com/blog/get-attachment-id-from-wp-image-url/
 */
function benevolent_pro_get_attachment_id( $url ) {

	$attachment_id = 0;

	$dir = wp_upload_dir();

	if ( false !== strpos( $url, $dir['baseurl'] . '/' ) ) { // Is URL in uploads directory?

		$file = basename( $url );

		$query_args = array(
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'fields'      => 'ids',
			'meta_query'  => array(
				array(
					'value'   => $file,
					'compare' => 'LIKE',
					'key'     => '_wp_attachment_metadata',
				),
			)
		);

		$query = new WP_Query( $query_args );

		if ( $query->have_posts() ) {

			foreach ( $query->posts as $post_id ) {

				$meta = wp_get_attachment_metadata( $post_id );

				$original_file       = basename( $meta['file'] );
				$cropped_image_files = wp_list_pluck( $meta['sizes'], 'file' );

				if ( $original_file === $file || in_array( $file, $cropped_image_files ) ) {
					$attachment_id = $post_id;
					break;
				}

			}

		}

	}

	return $attachment_id;
}

if( ! function_exists( 'benevolent_pro_duplicate_post' ) ) :
/**
 * Duplicate normal post to custom post on theme switch.
 * 
 * @param post id, post type
 * @return post id
*/
function benevolent_pro_duplicate_post_logo( $post_id, $post_type, $attachment = false ){
	
    if( $post_id ){    
        $post         = get_post( absint( $post_id ) );
        $thumbnail_id = $attachment ? $post_id : get_post_meta( $post_id, '_thumbnail_id', true  );
        
        if( isset( $post ) && $post != null ){
            /** new post data array */
    		$args = array(
				'post_author'   => $post->post_author,
				'post_content'  => $post->post_content,
				'post_excerpt'  => $post->post_excerpt,
				'post_name'     => $post->post_name,
				'post_password' => $post->post_password,
				'post_status'   => 'publish',
				'post_title'    => $post->post_title,
				'post_type'     => $post_type,
    		);

    		/** insert the post by wp_insert_post() function */
    		$new_post_id = wp_insert_post( $args );

            if( $new_post_id ){

                /** If post created then set post thumbnail of old post */
                set_post_thumbnail( $new_post_id, $thumbnail_id );

                /** If post created then set post category */
            	wp_set_object_terms( $new_post_id, 'donor', 'logo-category' );

                return $new_post_id;                
            }else{
                return false;
            }
        }else{
    		wp_die( 'Post creation failed, could not find original post: ' . $post_id );
    	}
    }else{
        return false;
    }
}
endif;

if( ! function_exists( 'benevolent_pro_get_posts' ) ) :
/**
 * Fuction to list Custom Post Type
*/
function benevolent_pro_get_posts( $post_type = 'post', $slug = false ){    
    $args = array(
        'posts_per_page'   => -1,
        'post_type'        => $post_type,
        'post_status'      => 'publish',
        'suppress_filters' => true 
    );
    $posts_array = get_posts( $args );
    
    // Initate an empty array
    $post_options = array();
    $post_options[''] = __( ' -- Choose -- ', 'benevolent-pro' );
    if ( ! empty( $posts_array ) ) {
        foreach ( $posts_array as $posts ) {
            if( $slug ){
                $post_options[ $posts->post_title ] = $posts->post_title;
            }else{
                $post_options[ $posts->ID ] = $posts->post_title;    
            }
        }
    }
    return $post_options;
    wp_reset_postdata();
}
endif;

if( ! function_exists( 'benevolent_pro_get_categories' ) ) :
/**
 * Function to list post categories in customizer options
*/
function benevolent_pro_get_categories( $select = true, $taxonomy = 'category', $slug = false ){    
    /* Option list of all categories */
    $categories = array();
    
    $args = array( 
        'hide_empty' => false,
        'taxonomy'   => $taxonomy 
    );
    
    $catlists = get_terms( $args );
    if( $select ) $categories[''] = __( 'Choose Category', 'benevolent-pro' );
    foreach( $catlists as $category ){
        if( $slug ){
            $categories[$category->slug] = $category->name;
        }else{
            $categories[$category->term_id] = $category->name;    
        }        
    }
    
    return $categories;
}
endif;

/**
 * Add filter only if function exists
 */
if (function_exists('DEMO_IMPORTER_PLUS_setup')) {
    add_filter(
        'demo_importer_plus_api_url',
        function () {
            return 'https://rarathemesdemo.com/';
        }
    );
}

/**
 * Add filter only if function exists
 */
if (function_exists('DEMO_IMPORTER_PLUS_setup')) {
    add_filter(
        'demo_importer_plus_api_id',
        function () {
            return array( '511', '480', '492', '710', '719', '2814', '2822' );
        }
    );
}
<?php
/**
 * Benevolent Pro functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Benevolent_Pro 
 */

$theme_data = wp_get_theme();
if( !defined( 'BENEVOLENT_PRO_THEME_VERSION' ) ) define ( 'BENEVOLENT_PRO_THEME_VERSION', $theme_data->get( 'Version' ) );
if( !defined( 'BENEVOLENT_PRO_THEME_NAME' ) ) define( 'BENEVOLENT_PRO_THEME_NAME', $theme_data->get( 'Name' ) );

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/custom-functions.php';

/**
 * Custom template functions for this theme.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * CPT
 */
require get_template_directory() . '/inc/cpt/custom-post.php';

/**
 * Meta Box.
 */
require get_template_directory() . '/inc/cpt/metabox.php';

/**
 * Performance.
 */
require get_template_directory() . '/inc/performance.php';

/**
 * Widgets
 */
require get_template_directory() . '/inc/widgets/widgets.php';

/**
 * Shortcodes
*/
require get_template_directory() . '/inc/shortcodes.php';

/**
 * Add Custom Controls
 */
require get_template_directory() . '/inc/custom-controls/custom-control.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';

/**
 * Give Plugin Related Functions
*/
if( is_give_activated() )
require get_template_directory() . '/inc/give-functions.php';

/**
 * WooCommerce Related funcitons
*/
if( benevolent_pro_is_woocommerce_activated() )
require get_template_directory() . '/inc/woocommerce-functions.php';

/**
 * Typography Functions
*/
require get_template_directory() . '/inc/typography/typography.php';

/**
 * Dynamic Styles
*/
require get_template_directory() . '/css/style.php';

/**
 * Demo Import
*/
require get_template_directory() . '/inc/import-hooks.php';

/**
 * Plugin Recommendation
*/
require get_template_directory() . '/inc/tgmpa/recommended-plugins.php';

/**
 * Getting Started
*/
require get_template_directory() . '/inc/getting-started/getting-started.php';

/**
 * Add theme compatibility function for elementor if active
*/
if( benevolent_pro_is_elementor_activated() ){
	require get_template_directory() . '/inc/elementor-compatibility.php';   
}
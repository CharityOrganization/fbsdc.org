<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Benevolent_Pro
 */

    /**
     * Doctype Hook
     * 
     * @hooked benevolent_pro_doctype_cb
    */
    do_action( 'benevolent_pro_doctype' );
?>
<head itemscope itemtype="https://schema.org/WebSite">
<?php 
    
    /**
     * Before wp_head
     * 
     * @hooked benevolent_pro_head
    */
    do_action( 'benevolent_pro_before_wp_head' );
    
    wp_head(); 
?>
</head>

<body <?php body_class(); ?> itemscope itemtype="https://schema.org/WebPage">

<?php    
    wp_body_open();
        
    /**
     * Before Header
     * 
     * @hooked benevolent_pro_fb_page_box - 15
     * @hooked benevolent_pro_page_start  - 20
     * @hooked benevolent_pro_responsive_menu  - 25
    */
    do_action( 'benevolent_pro_before_header' );
    
    /**
     * benevolent_pro Header
     * 
     * @hooked benevolent_pro_dynamic_header  - 20
    */
    do_action( 'benevolent_pro_header' );
    
    /**
     * After Header
     * 
     * @hooked benevolent_pro_slider - 20 
    */
    do_action( 'benevolent_pro_after_header' );
    
    /**
     * Before Content
     * 
     * @hooked benevolent_pro_breadcrumb - 20
    */
    do_action( 'benevolent_pro_before_content' );
    
    /**
     * benevolent_pro Content
     * 
     * @hooked benevolent_pro_content_start
    */
    do_action( 'benevolent_pro_content' );
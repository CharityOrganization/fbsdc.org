<?php
/**
 * Dynamic Styles
 *
 * @package Benevolent_Pro
 */
if( ! function_exists( 'benevolent_pro_dynamic_css' ) ) :
/**
* Dynamic CSS
*
*/
function benevolent_pro_dynamic_css(){

    $child_theme_support    = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );
    
    $body_font      = get_theme_mod( 'benevolent_pro_body_font', array('font-family'=>'Raleway', 'variant'=>'regular') );    
    $body_fonts     = benevolent_pro_get_fonts( $body_font['font-family'], $body_font['variant'] );
    $body_font_size = get_theme_mod( 'benevolent_pro_body_font_size', '18' );
    $body_line_ht   = get_theme_mod( 'benevolent_pro_body_line_height', '28' );
    $body_color     = get_theme_mod( 'benevolent_pro_body_color', '#777777' );
    
    $hps_title_font      = get_theme_mod( 'benevolent_pro_hps_title_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $hps_title_fonts     = benevolent_pro_get_fonts( $hps_title_font['font-family'], $hps_title_font['variant'] );
    $hps_title_font_size = get_theme_mod( 'benevolent_pro_hps_title_font_size', '40' );
    $hps_title_line_ht   = get_theme_mod( 'benevolent_pro_hps_title_line_height', '48' );
    
    $page_title_font      = get_theme_mod( 'benevolent_pro_page_title_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $page_title_fonts     = benevolent_pro_get_fonts( $page_title_font['font-family'], $page_title_font['variant'] );
    $page_title_font_size = get_theme_mod( 'benevolent_pro_page_title_font_size', '38' );
    $page_title_line_ht   = get_theme_mod( 'benevolent_pro_page_title_line_height', '48' );
    $page_title_color     = get_theme_mod( 'benevolent_pro_page_title_color', '#000000' );
    
    $post_title_font      = get_theme_mod( 'benevolent_pro_post_title_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $post_title_fonts     = benevolent_pro_get_fonts( $post_title_font['font-family'], $post_title_font['variant'] );
    $post_title_font_size = get_theme_mod( 'benevolent_pro_post_title_font_size', '30' );
    $post_title_line_ht   = get_theme_mod( 'benevolent_pro_post_title_line_height', '36' );
    $post_title_color     = get_theme_mod( 'benevolent_pro_post_title_color', '#121212' );
    
    $h1_font      = get_theme_mod( 'benevolent_pro_h1_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h1_fonts     = benevolent_pro_get_fonts( $h1_font['font-family'], $h1_font['variant'] );
    $h1_font_size = get_theme_mod( 'benevolent_pro_h1_font_size', '48' );
    $h1_line_ht   = get_theme_mod( 'benevolent_pro_h1_line_height', '57' );
    $h1_color     = get_theme_mod( 'benevolent_pro_h1_color', '#121212' );
    
    $h2_font      = get_theme_mod( 'benevolent_pro_h2_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h2_fonts     = benevolent_pro_get_fonts( $h2_font['font-family'], $h2_font['variant'] );
    $h2_font_size = get_theme_mod( 'benevolent_pro_h2_font_size', '40' );
    $h2_line_ht   = get_theme_mod( 'benevolent_pro_h2_line_height', '48' );
    $h2_color     = get_theme_mod( 'benevolent_pro_h2_color', '#121212' );
    
    $h3_font      = get_theme_mod( 'benevolent_pro_h3_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h3_fonts     = benevolent_pro_get_fonts( $h3_font['font-family'], $h3_font['variant'] );
    $h3_font_size = get_theme_mod( 'benevolent_pro_h3_font_size', '30' );
    $h3_line_ht   = get_theme_mod( 'benevolent_pro_h3_line_height', '36' );
    $h3_color     = get_theme_mod( 'benevolent_pro_h3_color', '#121212' );
    
    $h4_font      = get_theme_mod( 'benevolent_pro_h4_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h4_fonts     = benevolent_pro_get_fonts( $h4_font['font-family'], $h4_font['variant'] );
    $h4_font_size = get_theme_mod( 'benevolent_pro_h4_font_size', '24' );
    $h4_line_ht   = get_theme_mod( 'benevolent_pro_h4_line_height', '28' );
    $h4_color     = get_theme_mod( 'benevolent_pro_h4_color', '#121212' );
    
    $h5_font      = get_theme_mod( 'benevolent_pro_h5_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h5_fonts     = benevolent_pro_get_fonts( $h5_font['font-family'], $h5_font['variant'] );
    $h5_font_size = get_theme_mod( 'benevolent_pro_h5_font_size', '20' );
    $h5_line_ht   = get_theme_mod( 'benevolent_pro_h5_line_height', '24' );
    $h5_color     = get_theme_mod( 'benevolent_pro_h5_color', '#121212' );
    
    $h6_font      = get_theme_mod( 'benevolent_pro_h6_font', array('font-family'=>'Raleway', 'variant'=>'regular') );
    $h6_fonts     = benevolent_pro_get_fonts( $h6_font['font-family'], $h6_font['variant'] );
    $h6_font_size = get_theme_mod( 'benevolent_pro_h6_font_size', '18' );
    $h6_line_ht   = get_theme_mod( 'benevolent_pro_h6_line_height', '22' );
    $h6_color     = get_theme_mod( 'benevolent_pro_h6_color', '#121212' );
    
    $widget_title_font      = get_theme_mod( 'benevolent_pro_widget_title_font', array('font-family'=>'Raleway', 'variant'=>'700') );
    $widget_title_fonts     = benevolent_pro_get_fonts( $widget_title_font['font-family'], $widget_title_font['variant'] );    
    $widget_title_font_size = get_theme_mod( 'benevolent_pro_widget_title_font_size', '20' );
    $widget_title_line_ht   = get_theme_mod( 'benevolent_pro_widget_title_line_height', '35' );
        
    $bg_color        = get_theme_mod( 'benevolent_pro_bg_color', '#ffffff' );
    $body_bg         = get_theme_mod( 'benevolent_pro_body_bg', 'image' );
    $bg_image        = get_theme_mod( 'benevolent_pro_bg_image' );
    $bg_pattern      = get_theme_mod( 'benevolent_pro_bg_pattern', 'nobg' );
    $ed_auth_comment = get_theme_mod( 'benevolent_pro_ed_auth_comments' );
    $comunity_bg     = get_theme_mod( 'benevolent_pro_community_bg', '#0f907f' ); 
    $give_bg         = get_theme_mod( 'benevolent_pro_give_bg', '#0f907f' );
    if( $child_theme_support == 'charity-care' ){
        $s_color_scheme  = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
        $color_scheme  = get_theme_mod( 'benevolent_pro_secondary_color_scheme_charity_care', '#2dc08d' );
        $give_bg         = get_theme_mod( 'benevolent_pro_give_bg_charity_care', '#5890ff' );
    }elseif( $child_theme_support == 'revive-charity' ){
        $color_scheme  = get_theme_mod( 'benevolent_pro_primary_color_scheme_revive_charity', '#45c267' );
        $s_color_scheme  = get_theme_mod( 'benevolent_pro_secondary_color_scheme_revive_charity', '#f8b016' );
        $body_font      = get_theme_mod( 'benevolent_pro_body_font_rc', array('font-family'=>'Lexend Deca', 'variant'=>'regular') ); 
        $body_fonts     = benevolent_pro_get_fonts( $body_font['font-family'], $body_font['variant'] );
    }else{
        $color_scheme    = get_theme_mod( 'benevolent_pro_color_scheme', '#45c267' );
        $s_color_scheme  = get_theme_mod( 'benevolent_pro_secondary_color_scheme', '#F8B016' );
    }
    
    $image = '';
    if( $body_bg == 'image' && $bg_image ){
        $image = $bg_image;    
    }elseif( $body_bg == 'pattern' && $bg_pattern != 'nobg' ){
        $image = get_template_directory_uri() . '/images/patterns/' . $bg_pattern . '.png';
    }

    $rgb  = benevolent_pro_hex2rgb( benevolent_pro_sanitize_hex_color( $color_scheme ) );
    $rgb1 = benevolent_pro_hex2rgb( benevolent_pro_sanitize_hex_color( $s_color_scheme ) );
    $rgb2 = benevolent_pro_hex2rgb( benevolent_pro_sanitize_hex_color( $body_color ) );

    echo "<style type='text/css' media='all'>"; ?>
        :root {
            --primary-color: <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
            --primary-color-rgb: <?php printf('%1$s, %2$s, %3$s', $rgb[0], $rgb[1], $rgb[2] ); ?>;
            --secondary-color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
            --secondary-color-rgb: <?php printf('%1$s, %2$s, %3$s', $rgb1[0], $rgb1[1], $rgb1[2] ); ?>;
            --font-color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
            --font-color-rgb: <?php printf('%1$s, %2$s, %3$s', $rgb2[0], $rgb2[1], $rgb2[2] ); ?>;
        }
    <?php
    if( benevolent_pro_is_elementor_activated_post() ){
        ?>
        :root {
            --e-global-color-benevolent_pro_primary_color  : <?php echo benevolent_pro_sanitize_hex_color( $color_scheme ); ?>;
            --e-global-color-benevolent_pro_secondary_color: <?php echo benevolent_pro_sanitize_hex_color( $s_color_scheme ); ?>;
            --e-global-color-benevolent_pro_body_color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
        }
    <?php } ?>

    body{
    	font-size: <?php echo absint( $body_font_size ); ?>px;
    	line-height: <?php echo absint( $body_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $body_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $body_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $body_fonts['style'] ); ?>;
        background: url(<?php echo esc_url( $image ); ?>) <?php echo benevolent_pro_sanitize_hex_color( $bg_color ); ?>;
    }

    body,
    button,
    input,
    select,
    textarea{
        font-family: <?php echo $body_fonts['font']; ?>;
    }

    .site-header .site-branding .site-description{
        font-family: <?php echo $body_fonts['font']; ?>; 
    }
    

    /* home page section title style */
    
    .intro .header .main-title,
    .blog-section .header .main-title,
    .our-community .header .main-title,
    .give-section .main-title,
    .donors .heading .main-title,
    .promotional-block .widget_benevolent_pro_cta_widget .widget-title  {
        font-size: <?php echo absint( $hps_title_font_size ); ?>px;
    	line-height: <?php echo absint( $hps_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $hps_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $hps_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $hps_title_fonts['style'] ); ?>;        
    }

    .give-section .main-title,
    .our-community .header .main-title {
        color: #fff;
    }
    
    .promotional-block .widget_benevolent_pro_cta_widget .widget-title {
        color: #fff;
    }
    
    /*inner pages title style*/
    .about-us .main-title,
    .page-template-template-about .our-works .heading .main-title,
    .page-template-template-about .our-believe .heading .main-title,
    .page-template-template-about .current-project .heading .main-title,
    .page-template-template-service .services-intro .main-title,
    .page-template-template-service .our-works .heading .main-title,
    .page-template-template-team .main-title,
    .page-template-template-testimonial .main-title {
        font-size: <?php echo absint( $page_title_font_size ); ?>px;
    	line-height: <?php echo absint( $page_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $page_title_color ); ?>;
    	font-family: <?php echo $page_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $page_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $page_title_fonts['style'] ); ?>;
    }
    
    /*page entry-title*/
    #primary .page .entry-header .entry-title {
        font-size: <?php echo absint( $page_title_font_size ); ?>px;
    	line-height: <?php echo absint( $page_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $page_title_color ); ?>;
    	font-family: <?php echo $page_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $page_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $page_title_fonts['style'] ); ?>;
    }
    
    /*blog post title*/
    #primary .post .entry-header .entry-title {
        font-size: <?php echo absint( $post_title_font_size ); ?>px;
    	line-height: <?php echo absint( $post_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $post_title_color ); ?>;
    	font-family: <?php echo $post_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $post_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $post_title_fonts['style'] ); ?>;        
    }
    
    /*sidebar widget title*/
    #secondary .widget-title {
        font-size: <?php echo absint( $widget_title_font_size ); ?>px;
    	line-height: <?php echo absint( $widget_title_line_ht ); ?>px;
    	color: <?php echo benevolent_pro_sanitize_hex_color( $body_color ); ?>;
    	font-family: <?php echo $widget_title_fonts['font']; ?>;
        font-weight: <?php echo esc_attr( $widget_title_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $widget_title_fonts['style'] ); ?>;
    }
    
    /*sidebar ul font*/
    #secondary .widget ul {
        font-size: 16px;
    }
    
    /*footer widget title*/
    .site-footer .widget .widget-title {
        font-size: 18px;
        font-weight: 700;
        line-height: 36px;
    }

    /*footer widget title*/
    .revive-charity-style .site-footer .widget .widget-title {
        font-size: 20px;
        line-height: 32px;
        font-weight: 600;
        text-transform: none;
}

    .revive-charity-style .promotional-block .widget_benevolent_pro_cta_widget .widget-title {
        line-height: 56px;
}

.revive-charity-style .site-header .btn-donate,
.revive-charity-style #primary .post .entry-footer .btn-donate {
  border: 1px solid #fcb216;
  background: #fcb216;
  color: #fff;
  border-radius: 4px;
  padding: 15px 25px;
}

.revive-charity-style .site-header .btn-donate:hover {
  border: 1px solid #fcb216;
  background: none;
  color: #000;
}

    
    /* H1 content */
    .post .entry-content h1,
    .page .entry-content h1,
    .elementor-template-full-width .site-content h1,
    #primary .post .entry-content h1,
    #primary .page .entry-content h1{
        font-family: <?php echo $h1_fonts['font']; ?>;
        font-size: <?php echo absint( $h1_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h1_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h1_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h1_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h1_color ); ?>;
    }
    
    /* H2 content */
    .post .entry-content h2,
    .page .entry-content h2,
    .elementor-template-full-width .site-content h2,
    #primary .post .entry-content h2,
    #primary .page .entry-content h2{
        font-family: <?php echo $h2_fonts['font']; ?>;
        font-size: <?php echo absint( $h2_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h2_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h2_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h2_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h2_color ); ?>;
    }
    
    /* H3 content */
    .post .entry-content h3,
    .page .entry-content h3,
    .elementor-template-full-width .site-content h3,
    #primary .post .entry-content h3,
    #primary .page .entry-content h3{
        font-family: <?php echo $h3_fonts['font']; ?>;
        font-size: <?php echo absint( $h3_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h3_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h3_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h3_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h3_color ); ?>;
    }
    
    /* H4 content */
    .post .entry-content h4,
    .page .entry-content h4,
    .elementor-template-full-width .site-content h4,
    #primary .post .entry-content h4,
    #primary .page .entry-content h4{
        font-family: <?php echo $h4_fonts['font']; ?>;
        font-size: <?php echo absint( $h4_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h4_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h4_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h4_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h4_color ); ?>;
    }
    
    /* H5 content */
    .post .entry-content h5,
    .page .entry-content h5,
    .elementor-template-full-width .site-content h5,
    #primary .post .entry-content h5,
    #primary .page .entry-content h5{
        font-family: <?php echo $h5_fonts['font']; ?>;
        font-size: <?php echo absint( $h5_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h5_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h5_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h5_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h5_color ); ?>;
    }
    
    /* H6 content */
    .post .entry-content h6,
    .page .entry-content h6,
    .elementor-template-full-width .site-content h6,
    #primary .post .entry-content h6,
    #primary .page .entry-content h6{
        font-family: <?php echo $h6_fonts['font']; ?>;
        font-size: <?php echo absint( $h6_font_size ); ?>px;
        font-weight: <?php echo esc_attr( $h6_fonts['weight'] ); ?>;
        font-style: <?php echo esc_attr( $h6_fonts['style'] ); ?>;
        line-height: <?php echo absint( $h6_line_ht ); ?>px;
        color: <?php echo benevolent_pro_sanitize_hex_color( $h6_color ); ?>;
    }

    .site-header .btn-donate:hover,
    .site-header .btn-donate:focus{
        color: #fff;
    }

    .site-info a:hover,
    .site-info a:focus{
        color: #fff;
    }

    #secondary .widget.widget_give_forms_widget .give-btn:hover{
        color: #fff !important; 
        opacity: 0.8;
    }

    .our-community .header::after{
        border-top-color: <?php echo benevolent_pro_sanitize_hex_color( $comunity_bg ); ?>;
    }
    .our-community .header{
        background: <?php echo benevolent_pro_sanitize_hex_color( $comunity_bg ); ?>;
    }
    .give-section{
        background: <?php echo benevolent_pro_sanitize_hex_color( $give_bg ); ?>;
    }

    #primary .post .entry-meta .posted-on a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 448 512'%3E%3Cpath d='M400 64h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48zm-6 400H54c-3.3 0-6-2.7-6-6V160h352v298c0 3.3-2.7 6-6 6z'/%3E%3C/svg%3E") center center no-repeat;
    }

    #primary .post .entry-meta .byline a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 512 512'%3E%3Cpath d='M497.9 142.1l-46.1 46.1c-4.7 4.7-12.3 4.7-17 0l-111-111c-4.7-4.7-4.7-12.3 0-17l46.1-46.1c18.7-18.7 49.1-18.7 67.9 0l60.1 60.1c18.8 18.7 18.8 49.1 0 67.9zM284.2 99.8L21.6 362.4.4 483.9c-2.9 16.4 11.4 30.6 27.8 27.8l121.5-21.3 262.6-262.6c4.7-4.7 4.7-12.3 0-17l-111-111c-4.8-4.7-12.4-4.7-17.1 0zM124.1 339.9c-5.5-5.5-5.5-14.3 0-19.8l154-154c5.5-5.5 14.3-5.5 19.8 0s5.5 14.3 0 19.8l-154 154c-5.5 5.5-14.3 5.5-19.8 0zM88 424h48v36.3l-64.5 11.3-31.1-31.1L51.7 376H88v48z'/%3E%3C/svg%3E") center center no-repeat;
    }

    #primary .post .entry-meta .comments-link a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 512 512'%3E%3Cpath d='M256 32C114.6 32 0 125.1 0 240c0 49.6 21.4 95 57 130.7C44.5 421.1 2.7 466 2.2 466.5c-2.2 2.3-2.8 5.7-1.5 8.7S4.8 480 8 480c66.3 0 116-31.8 140.6-51.4 32.7 12.3 69 19.4 107.4 19.4 141.4 0 256-93.1 256-208S397.4 32 256 32z'/%3E%3C/svg%3E") center center no-repeat;
    }

    #primary .post .entry-footer .readmore:after {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 192 512'%3E%3Cpath d='M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .page-template-template-about .our-believe ul li:before{
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 512 512'%3E%3Cpath d='M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .comment-list .comment-metadata a:before{
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 448 512'%3E%3Cpath d='M400 64h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48zm-6 400H54c-3.3 0-6-2.7-6-6V160h352v298c0 3.3-2.7 6-6 6z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .comment-list .reply a:after{
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $color_scheme ) ); ?>' viewBox='0 0 192 512'%3E%3Cpath d='M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .chariti-care-style #primary .post .entry-meta .posted-on a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $s_color_scheme ) ); ?>' viewBox='0 0 448 512'%3E%3Cpath d='M400 64h-48V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H160V12c0-6.6-5.4-12-12-12h-40c-6.6 0-12 5.4-12 12v52H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48zm-6 400H54c-3.3 0-6-2.7-6-6V160h352v298c0 3.3-2.7 6-6 6z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .chariti-care-style #primary .post .entry-meta .byline a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $s_color_scheme ) ); ?>' viewBox='0 0 512 512'%3E%3Cpath d='M497.9 142.1l-46.1 46.1c-4.7 4.7-12.3 4.7-17 0l-111-111c-4.7-4.7-4.7-12.3 0-17l46.1-46.1c18.7-18.7 49.1-18.7 67.9 0l60.1 60.1c18.8 18.7 18.8 49.1 0 67.9zM284.2 99.8L21.6 362.4.4 483.9c-2.9 16.4 11.4 30.6 27.8 27.8l121.5-21.3 262.6-262.6c4.7-4.7 4.7-12.3 0-17l-111-111c-4.8-4.7-12.4-4.7-17.1 0zM124.1 339.9c-5.5-5.5-5.5-14.3 0-19.8l154-154c5.5-5.5 14.3-5.5 19.8 0s5.5 14.3 0 19.8l-154 154c-5.5 5.5-14.3 5.5-19.8 0zM88 424h48v36.3l-64.5 11.3-31.1-31.1L51.7 376H88v48z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .chariti-care-style #primary .post .entry-meta .comments-link a:before {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $s_color_scheme ) ); ?>' viewBox='0 0 512 512'%3E%3Cpath d='M256 32C114.6 32 0 125.1 0 240c0 49.6 21.4 95 57 130.7C44.5 421.1 2.7 466 2.2 466.5c-2.2 2.3-2.8 5.7-1.5 8.7S4.8 480 8 480c66.3 0 116-31.8 140.6-51.4 32.7 12.3 69 19.4 107.4 19.4 141.4 0 256-93.1 256-208S397.4 32 256 32z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .chariti-care-style #primary .post .entry-footer .readmore:after {
        background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $s_color_scheme ) ); ?>' viewBox='0 0 192 512'%3E%3Cpath d='M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z'/%3E%3C/svg%3E") center center no-repeat;
    }

    .revive-charity-style .give-section .owl-carousel .owl-nav .owl-next::after{
        background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' fill='<?php echo benevolent_pro_hash_to_percent23( benevolent_pro_sanitize_hex_color( $s_color_scheme ) ); ?>' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M10.3572 19.4062L18.0035 12.8541C18.1267 12.7484 18.2256 12.6174 18.2933 12.47C18.3611 12.3226 18.3962 12.1623 18.3962 12C18.3962 11.8377 18.3611 11.6774 18.2933 11.53C18.2256 11.3826 18.1267 11.2515 18.0035 11.1459L10.3572 4.59374C9.6274 3.96842 8.50006 4.48686 8.50006 5.4478L8.50006 18.5541C8.50006 19.515 9.62741 20.0334 10.3572 19.4062Z' /%3E%3C/svg%3E%0A");
    }

    .revive-charity-style .intro .header .main-title,
    .revive-charity-style .our-community .header .main-title, 
    .revive-charity-style .blog-section .header .main-title, 
    .revive-charity-style .sponsors .main-title, 
    .revive-charity-style .give-section .main-title, 
    .revive-charity-style .donors .heading .main-title, 
    .page-template-template-about .our-works .heading .main-title,{
        font-family: <?php echo $body_fonts ['font']; ?>;
    }

    <?php if( $ed_auth_comment ){ ?>
        /* Author Comment Style */
        .comment-list .bypostauthor .comment-body{
            background: #f4f4f4;
            border-radius: 3px;
            padding: 10px;
        }
    <?php } ?>

    <?php echo "</style>";  
}
endif;
add_action( 'wp_head', 'benevolent_pro_dynamic_css', 100 );

/**
 * Function for sanitizing Hex color 
 */
function benevolent_pro_sanitize_hex_color( $color ){
	if ( '' === $color )
		return '';

    // 3 or 6 hex digits, or the empty string.
	if ( preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) )
		return $color;
}

/**
 * Convert '#' to '%23'
*/
function benevolent_pro_hash_to_percent23( $color_code ){
    $color_code = str_replace( "#", "%23", $color_code );
    return $color_code;
}

if( ! function_exists( 'benevolent_pro_hex2rgb' ) ) :
    /**
     * convert hex to rgb
     * @link http://bavotasan.com/2011/convert-hex-color-to-rgb-using-php/
    */
    function benevolent_pro_hex2rgb($hex) {
       $hex = str_replace("#", "", $hex);
    
       if(strlen($hex) == 3) {
          $r = hexdec(substr($hex,0,1).substr($hex,0,1));
          $g = hexdec(substr($hex,1,1).substr($hex,1,1));
          $b = hexdec(substr($hex,2,1).substr($hex,2,1));
       } else {
          $r = hexdec(substr($hex,0,2));
          $g = hexdec(substr($hex,2,2));
          $b = hexdec(substr($hex,4,2));
       }
       $rgb = array($r, $g, $b);
       //return implode(",", $rgb); // returns the rgb values separated by commas
       return $rgb; // returns an array with the rgb values
    }
    endif;
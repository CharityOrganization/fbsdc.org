<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */

$ed_crop_single_post_image = get_theme_mod( 'ed_crop_single_post_image' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
    <header class="entry-header">
		<?php
				
        the_title( '<h1 class="entry-title" itemprop="headline">', '</h1>' );
			
		if ( 'post' === get_post_type() ) benevolent_pro_posted_on(); 
        
        ?>
	</header><!-- .entry-header -->
        
    <?php 
        if( has_post_thumbnail() && get_theme_mod( 'benevolent_pro_ed_featured_image', '1' ) ){
            echo '<div class="post-thumbnail">';
	            if ( $ed_crop_single_post_image ) {
	            	the_post_thumbnail();
	            }else{
	            	benevolent_pro_sidebar( true ) ? the_post_thumbnail( 'benevolent-pro-with-sidebar', array( 'itemprop' => 'image' ) ) : the_post_thumbnail( 'benevolent-pro-without-sidebar', array( 'itemprop' => 'image' ) );
	            }
            echo '</div>'; 
        }
    ?>
    
	<div class="entry-content" itemprop="text">
		<?php
			
            the_content( sprintf(
				/* translators: %s: Name of current post. */
				wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'benevolent-pro' ), array( 'span' => array( 'class' => array() ) ) ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			) );
            
			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'benevolent-pro' ),
				'after'  => '</div>',
			) );
            
		?>
	</div><!-- .entry-content -->
	
    <footer class="entry-footer">
		<?php 
            benevolent_pro_cat_tag();
            benevolent_pro_entry_footer();
        ?>
	</footer><!-- .entry-footer -->
    
</article><!-- #post-## -->
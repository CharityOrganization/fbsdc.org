<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */

$excerpt_words = get_theme_mod( 'benevolent_pro_post_excerpt_words', 30 );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( sprintf( '<h2 class="entry-title" itemprop="headline"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-summary">
		<?php 
            if( has_excerpt() ){
                the_excerpt();        
            }else{
                echo wpautop( wp_kses_post( wp_trim_words( strip_shortcodes( get_the_content() ), $excerpt_words ) ) );         
            }
        ?>
	</div><!-- .entry-summary -->

</article><!-- #post-## -->
<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent_Pro
 */

$blog_layout   = get_theme_mod( 'benevolent_pro_blog_layout', 'default' ); //From Customizer
$excerpt_words = get_theme_mod( 'benevolent_pro_post_excerpt_words', 30 ); //From Customizer
$read_more     = get_theme_mod( 'benevolent_pro_post_read_more', __( 'Read More', 'benevolent-pro' ) ); //From Customizer
$img_size      = '';
$ed_crop_archive_page_image = get_theme_mod( 'ed_crop_archive_page_image' );

if( $blog_layout == 'round' || $blog_layout == 'square' ){
    $img_size = 'benevolent-pro-featured-post';
}else{
    $img_size = benevolent_pro_sidebar( true ) ? 'benevolent-pro-with-sidebar' : 'benevolent-pro-without-sidebar';
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
    <?php 
        echo '<a href="' . esc_url( get_the_permalink() ) . '" class="post-thumbnail">';
            if( has_post_thumbnail() ){
                if( $ed_crop_archive_page_image && $blog_layout !== 'round' ){
                    the_post_thumbnail();
                }else{
                    the_post_thumbnail( $img_size, array( 'itemprop' => 'image' ) );
                }
            }elseif( ! has_post_thumbnail() && $blog_layout !== 'default' ){
                benevolent_pro_get_fallback_svg( $img_size );
            }
        echo '</a>' ; 
    ?>
    
    <div class="text-holder">
        <header class="entry-header">
    		<?php
    			
            the_title( '<h2 class="entry-title" itemprop="headline"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
    		
    		if ( 'post' === get_post_type() ) benevolent_pro_posted_on(); 
            
            ?>
    	</header><!-- .entry-header -->
        
        
    	<div class="entry-content" itemprop="text">
    		<?php
    		
                if( false === get_post_format() ){
                    if( has_excerpt() ){
                        the_excerpt();    
                    }else{
                        echo wpautop( wp_kses_post( wp_trim_words( strip_shortcodes( get_the_content() ), $excerpt_words ) ) );  
                    }
                }else{
                    the_content( sprintf(
        				/* translators: %s: Name of current post. */
        				wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'benevolent-pro' ), array( 'span' => array( 'class' => array() ) ) ),
        				the_title( '<span class="screen-reader-text">"', '"</span>', false )
        			) );
                }
                
    			wp_link_pages( array(
    				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'benevolent-pro' ),
    				'after'  => '</div>',
    			) );
    		?>
    	</div><!-- .entry-content -->
    
    	
        <footer class="entry-footer">
    		<a href="<?php the_permalink(); ?>" class="readmore"><?php echo esc_html( $read_more ); ?></a>
            <?php benevolent_pro_entry_footer(); ?>
    	</footer><!-- .entry-footer -->
        
    </div>
</article><!-- #post-## -->
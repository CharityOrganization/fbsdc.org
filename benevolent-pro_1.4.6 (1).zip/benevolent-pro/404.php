<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Benevolent_Pro
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
            
            <div class="error-holder">				
				<h1><?php esc_html_e( 'Error 404', 'benevolent-pro' ); ?></h1>
				<h2><?php esc_html_e( 'Page Not Found', 'benevolent-pro' ); ?></h2>
				<p><?php esc_html_e( 'This page could not be found on the server.', 'benevolent-pro' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return to Homepage', 'benevolent-pro' ); ?></a>
			</div>
            
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();

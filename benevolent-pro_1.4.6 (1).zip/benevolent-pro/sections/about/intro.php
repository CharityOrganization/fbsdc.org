<?php
/**
 * Intro Section About Page
 * 
 * @package Benevolent_Pro
 */

$iframe  = get_theme_mod( 'benevolent_pro_about_video_iframe' );
$caption = get_theme_mod( 'benevolent_pro_about_video_caption' );
?>


<section id="about-intro" class="about-us">
	<div class="container">
		
        <h2 class="main-title"><?php the_title(); ?></h2>
		<div class="entry-content"><?php the_content(); ?></div>
        
        <?php if( $iframe || $caption ){ ?>
        <div class="video-holder">
			<?php if( $iframe ){ ?>
            <div class="video">
				<?php 
                    if( benevolent_pro_iframe_match( $iframe ) ){
    				    echo benevolent_pro_sanitize_code( $iframe );    
    				}else{
    				    echo wp_oembed_get( $iframe );
    				} 
                ?>
			</div>
			<?php } 
            
            if( $caption ) echo wpautop( wp_kses_post( $caption ) ); ?>
		</div>
        <?php } ?>
        
	</div>
</section>
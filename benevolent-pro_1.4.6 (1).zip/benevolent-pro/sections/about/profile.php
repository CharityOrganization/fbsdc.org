<?php
/**
 * Our Work Section
 * 
 * @package Benevolent_Pro
 */

$title   = get_theme_mod( 'benevolent_pro_profile_section_title' );
$content = get_theme_mod( 'benevolent_pro_profile_section_content' );

if( $title || $content || is_active_sidebar( 'about-profile' ) ){ 
?>

<section id="about-profile" class="our-works">
	<div class="container">
		
        <?php
        
            if( $title || $content ){
                echo '<header class="heading">';
                if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                if( $content ) echo wpautop( wp_kses_post( $content ) );
                echo '</header>'; 
            }
            
        ?>
        
        <?php if( is_active_sidebar( 'about-profile' ) ) { ?>
        <div class="row">
			<?php dynamic_sidebar( 'about-profile' ); ?>			
		</div>
        <?php } ?>
        
	</div>
</section>

<?php 
}
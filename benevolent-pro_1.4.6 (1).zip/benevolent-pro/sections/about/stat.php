<?php
/**
 * Stat Counter Section
 * 
 * @package Benevolent_Pro
 */

$bg = get_theme_mod( 'benevolent_pro_about_stat_counter_bg' );

if( $bg ){
    $style = ' style="background: url(' . esc_url( $bg ) . '); background-size: cover; background-position: center;"';    
}else{
    $style = '';
}

if( is_active_sidebar( 'about-counter' ) ){
?>

<div id="about-stat" class="stats"<?php echo $style; ?>>
	<div class="container">
		<div class="row">
            <?php dynamic_sidebar( 'about-counter' ); ?>
		</div>
	</div>
</div>

<?php
}
<?php
/**
 * Community Section
 * 
 * @package Benevolent_Pro
 */
 
$title       = get_theme_mod( 'benevolent_pro_community_section_title' );
$post_one    = get_theme_mod( 'benevolent_pro_community_post_one' );
$post_two    = get_theme_mod( 'benevolent_pro_community_post_two' );
$post_three  = get_theme_mod( 'benevolent_pro_community_post_three' );
$post_four   = get_theme_mod( 'benevolent_pro_community_post_four' );
$child_theme = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );
$read_more   = get_theme_mod( 'benevolent_pro_community_readmore', __( 'LEARN MORE', 'benevolent-pro' ) );

$posts = array( $post_one, $post_two, $post_three, $post_four );
$posts = array_diff( array_unique( $posts ), array('') );

if( $title || $posts ){ ?>

<section id="community-section" class="our-community">
    
    <?php
        
        if( $title ) echo '<header class="header"><h2 class="main-title">' . esc_html( $title ) . '</h2></header>'; 
        
        $qry = new WP_Query( array( 
            'post_type'           => array( 'post', 'page' ),
            'posts_per_page'      => -1,
            'post__in'            => $posts,
            'orderby'             => 'post__in',
            'ignore_sticky_posts' => true
        ) );

        if( $posts && $qry->have_posts() ){
            echo '<div class="community-holder">';
            while( $qry->have_posts() ){
                $qry->the_post();
                if( has_post_thumbnail() ){
                ?>
                <div class="columns-2">
    				<?php the_post_thumbnail( 'benevolent-pro-community', array( 'itemprop' => 'image' ) ); ?>
    				<div class="text-holder">
                        <div class="table">
                            <div class="table-row">
                                <div class="table-cell">				
                                <strong class="title"><?php the_title(); ?></strong>
    				            <?php 
                                if( has_excerpt() ){ 
    				                the_excerpt();                                
                                }else{
                                    echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );    
                                } ?>
                                </div>
                            </div>
                        </div>
                    </div>
        			<div class="hover-state">
                        <div class="table">
                            <div class="table-row">
                                <div class="table-cell">
    				                <strong class="title"><?php the_title(); ?></strong>
    				                <?php 
                                    if( has_excerpt() ){ 
        				                the_excerpt();
                                    }else{
                                        echo wpautop( wp_kses_post( force_balance_tags( benevolent_pro_excerpt( get_the_content(), 50, '...', false, false ) ) ) );    
                                    } 
                                    if( $child_theme == 'revive-charity' ){
                                        if( $read_more ) echo '<a href="' . esc_url( get_permalink() ) . '" class="btn-learn">' . esc_html( $read_more ) . '</a>';
                                    }else{ ?>
                                        <div class="btn-holder">
                                            <a href="<?php the_permalink(); ?>"><span class="fa fa-angle-right"></span></a>
                                        </div>
                                    <?php }
                                    if(get_theme_mod('benevolent_pro_ed_child_style') != 'charity-care'){ ?>
                                        <div class="text-content">
                                        <?php 
                                            if( has_excerpt() ){
                                                the_excerpt();     
                                            }else{
                                                echo wpautop( benevolent_pro_excerpt( get_the_content(), 150, '...', false, false ) );
                                            }
                                        ?>
                                        </div>
                                    <?php } ?>

    				            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
            }
            wp_reset_postdata(); 
            echo '</div>';
        }
    ?>
    
    </section>
    
<?php
}			
<?php
/**
 * Blog Section
 * 
 * @package Benevolent_Pro
 */
 
$ed_bdate = get_theme_mod( 'benevolent_pro_ed_blog_date', '1' );
$title    = get_theme_mod( 'benevolent_pro_blog_section_title' );
$content  = get_theme_mod( 'benevolent_pro_blog_section_content' );
$readmore = get_theme_mod( 'benevolent_pro_blog_section_readmore', __( 'Read More', 'benevolent-pro' ) );
$cat      = get_theme_mod( 'benevolent_pro_exclude_categories' );
$ed_crop_archive_page_image = get_theme_mod( 'ed_crop_archive_page_image' );
$blog_section_viewall       = get_theme_mod( 'benevolent_pro_blog_section_viewall', __( 'READ ALL BLOG', 'benevolent-pro' ) );
$blog_section_viewall_link  = get_theme_mod( 'benevolent_pro_blog_section_viewall_link' );
$child_theme                = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );

if( $cat ) $cat = array_diff( array_unique( $cat ), array('') );
 
$qry = new WP_Query( array( 
    'post_type'           => 'post',
    'post_status'         => 'publish',
    'posts_per_page'      => 3,
    'ignore_sticky_posts' => true,
    'category__not_in'    => $cat    
) );

if( $title || $content || $qry->have_posts() ){ ?>

    <section id="blog-section" class="blog-section">
        <?php
        if( $title || $content ){
        ?>
        <header class="header">
        	<div class="container">
        		<div class="text">
        			<?php 
                        if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                        if( $content ) echo wpautop( wp_kses_post( $content ) );
                    ?>
        		</div>
        	</div>
        </header>
        <?php } 
    
    
        if( $qry->have_posts() ){
        ?>    
        <div class="blog-holder">
        	<div class="container">
        		<div class="row">
        			<?php
                    while( $qry->have_posts() ){
                        $qry->the_post();
                    ?>
                    <div class="columns-3">
        				<div class="post">
                            <a href="<?php the_permalink(); ?>" class="post-thumbnail">
                            <?php 
                                if( has_post_thumbnail() ){ 
                                    $ed_crop_archive_page_image ? the_post_thumbnail() : the_post_thumbnail( 'benevolent-pro-blog', array( 'itemprop' => 'image' ) );
                                }else{
                                    benevolent_pro_get_fallback_svg( 'benevolent-pro-blog' );
                                } 
                            ?>
                            </a>
        					<div class="text-holder">
        						<header class="entry-header">
        							<h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        							<?php if( $ed_bdate ){ ?>
                                    <div class="entry-meta">
        								<span class="posted-on"><span class="fa fa-calendar-o"></span><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_date() ); ?></a></span>
        							</div>
                                    <?php } ?>
        						</header>
        						<div class="entry-content">
        							<?php 
                                        if( has_excerpt() ){
                                            the_excerpt();        
                                        }else{
                                            echo wpautop( wp_kses_post( wp_trim_words( get_the_content(),10,'...' ) ) );
                                        }
                                    ?>
        						</div>
        						<a href="<?php the_permalink(); ?>" class="readmore"><?php echo esc_html( $readmore ); ?></a>
        					</div>
        				</div>
        			</div>
        			<?php
                    }
                    wp_reset_postdata();
                    ?>    			
        		</div>
        	</div>
            <?php if( $child_theme == 'revive-charity' ){
                if( $blog_section_viewall && $blog_section_viewall_link ) echo '<a href="'. esc_url( $blog_section_viewall_link ) .'" class="btn-learn">'. esc_html( $blog_section_viewall ) .'</a>';
            } ?>
        </div>
        <?php 
        }
    ?>
    </section>
<?php    
}
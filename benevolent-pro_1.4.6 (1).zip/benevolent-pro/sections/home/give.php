<?php
/**
 * Give Section
 * 
 * @package Benevolent_Pro
 */
 
$title          = get_theme_mod( 'benevolent_pro_give_section_title' );
$content        = get_theme_mod( 'benevolent_pro_give_section_content' );
$readmore       = get_theme_mod( 'benevolent_pro_give_button_label', __( 'Donate Now', 'benevolent-pro' ) );// From Customizer
$excerpt_words  = get_theme_mod( 'benevolent_pro_give_excerpt_words', 25 ); //From Customizer
$excerpt_option = give_get_option( 'disable_forms_excerpt' );
$child_theme    = get_theme_mod( 'benevolent_pro_ed_child_style', 'default' );
 
$give_query = new WP_Query( array( 
    'post_type'           => 'give_forms',
    'post_status'         => 'publish',
    'posts_per_page'      => -1,
    'ignore_sticky_posts' => true,   
) );

if( $title || $content || $give_query->have_posts() ){ ?>

    <section id="give-section" class="give-section">
        <?php
        if( $title || $content ){
        ?>
        <header class="header">
        	<div class="container">
        		<div class="heading">
        			<?php 
                        if( $title ) echo '<h2 class="main-title">' . esc_html( $title ) . '</h2>';
                        if( $content ) echo wpautop( wp_kses_post( $content ) ); 
                    ?>
        		</div>
        	</div>
        </header>
        <?php } 
        
        $total_posts = $give_query->found_posts;
    
        if( $give_query->have_posts() ){
        ?>    
        <div class="give-holder">
        	<div class="container">
        		<?php 
                    echo ( $total_posts > 3 ) ? '<div class="give-slider owl-carousel">' : '<div class="row">'; 
                    
                    while( $give_query->have_posts() ){
                        $give_query->the_post();
                        $form_id = get_the_ID();
                        
                        echo ( $total_posts > 3 ) ? '<div>' : '<div class="columns-3">'; ?>
                
                        <div class="post">
                            <?php if( has_post_thumbnail() ){ ?>
                            <a href="<?php the_permalink(); ?>" class="post-thumbnail"><?php the_post_thumbnail( 'benevolent-pro-give', array( 'itemprop' => 'image' ) ); ?></a>
                            <?php } ?>
                            <div class="text-holder">
                                <header class="entry-header">
                                    <h3 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                </header>
                                <div class="entry-content">
                                    <?php                                       
 
                                        if( $excerpt_option !== 'on' ){
                                            if( has_excerpt() ){
                                                the_excerpt();    
                                            }else{
                                                //Output the content
                                                $content_option = get_post_meta( $form_id, '_give_content_option', true );
                                                if ( $content_option != 'none' ) {
                                                    $content = get_post_meta( $form_id, '_give_form_content', true );
                                                    echo wpautop( wp_kses_post( wp_trim_words( strip_shortcodes( $content ), $excerpt_words ) ) ); 
                                                }
                                            }
                                        }
                                        
                                        $goal_stats = give_goal_progress_stats( $form_id );
                                        //Output the goal
                                        $goal_option = get_post_meta( $form_id, '_give_goal_option', true );
                                        $goal_format = get_post_meta( $form_id, '_give_goal_format', true );
                                        $currency_symbol = give_currency_symbol();
                                        if ( $goal_option == 'enabled' ) {

                                            if($goal_format == 'percentage' && ( $child_theme == 'charity-care' || $child_theme == 'revive-charity' ) ){
                                                $shortcode = '[give_goal id="' . $form_id . '"]';
                                                echo do_shortcode( $shortcode );
                                            }

                                            if( ( $child_theme == 'charity-care' || $child_theme == 'revive-charity' ) && ( $goal_stats['raw_actual'] || $goal_stats['raw_goal'] ) ){ ?>
                                                <div class="cc-goal-raise">
                                                    <?php if( $child_theme == 'revive-charity' ) echo '<div class="goal-wrapper">'; ?>
                                                        <div class="cc-goal"><?php echo esc_html__('Goal: ','benevolent-pro'); ?><span><?php echo esc_html( $currency_symbol .$goal_stats['raw_goal']); ?></span></div>
                                                        <div class="cc-raise"><?php echo esc_html__('Raised: ','benevolent-pro'); ?><span><?php echo esc_html( $currency_symbol .$goal_stats['raw_actual']); ?></span></div>
                                                    <?php if( $child_theme == 'revive-charity' ) echo '</div>'; ?>
                                                </div>
                                            <?php }
                                        } ?>
                                        
                                </div>
                                <a href="<?php the_permalink(); ?>" class="btn-donate"><?php echo esc_html( $readmore ); ?></a>
                            </div>
                        </div>
                        <?php
                        echo ( $total_posts > 3 ) ? '</div>' : '</div>';
                        
                    }
                    wp_reset_postdata();
                    
                echo ( $total_posts > 3 ) ? '</div>' : '</div>'; 
                ?>    			
        	</div>
        </div>
        <?php 
        }
    ?>
    </section>
<?php    
}

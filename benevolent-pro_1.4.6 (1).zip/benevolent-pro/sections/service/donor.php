<?php
/**
 * Donor Section
 * 
 * @package Benevolent_Pro
 */

$title   = get_theme_mod( 'benevolent_pro_service_donor_title' );
$content = get_theme_mod( 'benevolent_pro_service_donor_content' );
$cat     = get_theme_mod( 'benevolent_pro_service_donor_cat' );

benevolent_pro_logo_helper( $title, $content, $cat );
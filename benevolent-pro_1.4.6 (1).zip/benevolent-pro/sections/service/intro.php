<?php
/**
 * Intro Section Service Page
 * 
 * @package Benevolent_Pro
 */

$iframe = get_theme_mod( 'benevolent_pro_service_video_iframe' );
?>

<section id="service-intro" class="services-intro">
	<div class="container">
		<h2 class="main-title"><?php the_title(); ?></h2>
		<div class="intro-content">
		
        	<div class="row">
				<?php if( $iframe ){ ?>
                <div class="video-holder">
                    <?php 
                        if( benevolent_pro_iframe_match( $iframe ) ){
        				    echo benevolent_pro_sanitize_code( $iframe );    
        				}else{
        				    echo wp_oembed_get( $iframe );
        				} 
                    ?>
                </div>
				<?php } ?>
                <div class="text-holder">
					<?php the_content(); ?>
				</div>
                
			</div>
		</div>
	</div>
</section>
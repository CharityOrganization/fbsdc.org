<?php
/**
 * CTA Section
 * 
 * @package Benevolent_Pro
 */

if( is_active_sidebar( 'service-cta' ) ) {
?>

<section id="service-promotional" class="promotional-block">
	<?php dynamic_sidebar( 'service-cta' ); ?>    
</section>

<?php
}